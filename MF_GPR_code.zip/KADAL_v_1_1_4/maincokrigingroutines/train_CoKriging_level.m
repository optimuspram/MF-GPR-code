function [myKriging] = train_CoKriging_level(KrigInfo,intopts)
%
% Create Kriging model based on the information from KrigInfo.
%
% Input:
%   KrigInfo - Containing necessary information to create a Kriging model
%
% Output:
%   myKriging - Trained Kriging model

% Details of KrigInfo:
%   REQUIRED PARAMETERS. These parameters need to be specified manually by
%   the user. Otherwise, the process cannot continue.
%       KrigInfo.lb - Variables' lower bounds.
%       KrigInfo.ub - Variables' upper bounds.
%       KrigInfo.nvar - Number of variables.
%       KrigInfo.nsamp - Number of samples.
%
%   EXTRA PARAMETERS. These parameters can be set by the user. If not
%   specified, default values will be used (or computed for the experimetntal design and responses)
%       KrigInfo.display - Set to 1 for displaying parameter settings, set to otherwise for no display.
%       KrigInfo.X - Experimental design (note that the experimental design will be normalized to [-1,1].
%       KrigInfo.Y - Responses of the experimental design.
%       KrigInfo.problem - Function name to evaluate responses (No need to specify this if KrigInfo.X and KrigInfo.Y are specified).
%       KrigInfo.nugget - Nugget (noise factor). Default: 1e-6
%       KrigInfo.TrendOrder - Polynomial trend function order (note that this code uses polynomial chaos expansion). Default: 0 (ordinary Kriging).
%       KrigInfo.RegrOrder - Polynomial regression function order (note that this code uses polynomial chaos expansion). Default: 0. (only for levels > 1)
%       KrigInfo.lbls - Lower bounds for hyperparameters optimization.  Default: 1e-3 for each variable (in a logarithmic scale).
%       KrigInfo.ubls - Upper bounds for hyperparameters optimization.  Default: 1e2 for each variable (in a logarithmic scale).
%       KrigInfo.kernel - Kernel function. Available kernels are 'gaussian', 'exponential','matern32', 'matern52', and 'cubic'. Default: 'Gaussian'.
%       KrigInfo.nrestart - Number of restarts for hyperparameters optimization. Default: 1.
%       KrigInfo.LOOCVtype - Type of cross validation error. Default: 'rmse'.
%       KrigInfo.optimizer - Optimizer for hyperparameters optimization. Default: 'cmaes'.
%
%  Author: Lucia Parussini (lparussini@units.it)
%
%% Set up the CoKriging level
cokriging_level_setup % Call the cokriging_level_setup subroutine 

%% Hyperparameters optimization
% Optimize hyperparameters 

% Prepare the settings for internal optimizer
if nargin < 3
    switch KrigInfo.optimizer
        case 'cmaes'
            % Set parameters for CMA-ES
            intopts = cmaes;
            intopts.LBounds = KrigInfo.lbhyp';
            intopts.UBounds = KrigInfo.ubhyp';
            intopts.LogModulo = 0; % Do not show CMA-ES output
            intopts.SaveVariables = 0; % Do not show CMA-ES output
            intopts.DispFinal = 'off';
            intopts.DispModulo = inf;
        case 'fmincon'
            intopts.Display = 'off';
        case 'ga'
            intopts.Display = 'off';
    end
elseif nargin == 3
    if KrigInfo.display == 1; disp('The internal optimizer setting is specified by the user'); end
end

if (isfield(KrigInfo,'optstartpoint') == 0)
    X0hyp = rlh(KrigInfo.nrestart-2,KrigInfo.nbhyp); X0hyp = variabletransf(X0hyp,[KrigInfo.lbhyp;KrigInfo.ubhyp]');  % Initialize starting points for CMA-ES based hyperparameters search
    X0hyp(end+1,:) = KrigInfo.ubhyp; % Sometimes upper bound is a good start
    X0hyp(end+1,:) = KrigInfo.lbhyp; % So does the lower bound
else
    X0hyp = KrigInfo.optstartpoint; % Take the initial hyperparameters
    KrigInfo.nrestart = size(X0hyp,1); % Change the number of restarts according to the given initial hyperparameters
end

Xhypcand = zeros(KrigInfo.nrestart,KrigInfo.nbhyp); % Initialize global optimum candidates
NegLnLikeCand = zeros(1,KrigInfo.nrestart); % Initialize likelihood values of the global optimum candidates
if KrigInfo.display == 1; disp(['Begin hyperparameters optimization using ''',KrigInfo.optimizer,'''']); end

tic % Start the timer
for im = 1:KrigInfo.nrestart
    switch KrigInfo.optimizer % Use the specified optimizer
        case 'fmincon' % MATLAB's fmincon (available with global optimization toolbox)
            [Xhypcand(im,:),NegLnLikeCand(im)]=feval(KrigInfo.optimizer, @(hyperparam) likelihood_fun_computation(hyperparam,KrigInfo),X0hyp(im,:),[],[],[],[],KrigInfo.lbhyp,KrigInfo.ubhyp,[],intopts);
        case 'cmaes' % CMA-ES, the default optimizer
            [Xhypcand(im,:),NegLnLikeCand(im)]=feval(KrigInfo.optimizer, @(hyperparam) likelihood_fun_computation(hyperparam,KrigInfo),X0hyp(im,:),[],intopts);
        case 'ga' % MATLAB's genetic algorithm (available with global optimization toolbox)
            [Xhypcand(im,:),NegLnLikeCand(im)]=feval(KrigInfo.optimizer, @(hyperparam) likelihood_fun_computation(hyperparam,KrigInfo), length(X0hyp(im,:)),[],[],[],[],KrigInfo.lbhyp,KrigInfo.ubhyp,[],[],intopts);
    end
end

[~,I] = min(NegLnLikeCand); % Find the solution with the best likelihood value
KrigInfo.Xhyp = Xhypcand(I,:); % Put the solution with the test likelihood value to KrigInfo

[KrigInfo.NegLnLike,KrigInfo.Psi,KrigInfo.U,KrigInfo.beta.value,KrigInfo.kernvar.value, KrigInfo.F, KrigInfo.wgkf, KrigInfo.noisevar.value, KrigInfo.lengthscale.value]= likelihood_fun_computation(KrigInfo.Xhyp,KrigInfo);
[KrigInfo.LOOCVerror, KrigInfo.LOOCVpred, KrigInfo.LOOCVSSqr, KrigInfo.LOOCVMSLL] = krigloocv(KrigInfo,KrigInfo.LOOCVtype); % Compute leave-one-out cross-validation error

if KrigInfo.display == 1; disp('Finished building the Kriging model'); end

%% Output the final model
KrigInfo.noisevar.value = undoNormalize(KrigInfo.noisevar.value,0.*KrigInfo.meanY,KrigInfo.stdY.^2);
myKriging = KrigInfo; % Output the final model
myKriging.time = toc;
