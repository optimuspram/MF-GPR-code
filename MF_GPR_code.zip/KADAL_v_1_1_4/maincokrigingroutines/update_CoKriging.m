function [myCoKriging] = update_CoKriging(lev, CoKrigInfo, intopts)
%
% Create CoKriging model based on the information from CoKrigInfo.
%
% Input:
%   lev - number of level from which the CoKriging model has to be updated
%   CoKrigInfo - Containing necessary information to create a CoKriging model
%
% Output:
%   myCoKriging - Trained CoKriging model

% Details of CoKrigInfo:
%
%   Except nlev, the other parameters, when they are set, will be assigned to
%   those levels for which they are not specifically set
%
%   REQUIRED PARAMETERS. These parameters need to be specified manually by
%   the user. Otherwise, the process cannot continue.
%       CoKrigInfo.lb - Variables' lower bounds.
%       CoKrigInfo.ub - Variables' upper bounds.
%       CoKrigInfo.nvar - Number of variables.
%       CoKrigInfo.level{:}.nsamp - Number of samples at each level.
%
%   EXTRA PARAMETERS. These parameters can be set by the user. If not
%   specified, default values will be used (or computed for the experimental design and responses)
%       CoKrigInfo.display - Set to 1 for displaying parameter settings, set to otherwise for no display.
%       CoKrigInfo.nlev - Number of fidelity levels.
%       CoKrigInfo.noisefree - true = noise free case; false = noisy case
%       CoKrigInfo.kernvar - kernel variance: for noisy case give fields: 'lb' and 'ub' (logarithmic scale) or 'value' (linear scale)
%       CoKrigInfo.noisevar - noise variance: for noisy case give fields: 'lb' and 'ub' (logarithmic scale) or 'value' (linear scale)
%       CoKrigInfo.TrendFunction - Polynomial trend function. Default: 1 (ordinary Kriging).
%       CoKrigInfo.kernel - Kernel function. Available kernels are 'gaussian', 'exponential','matern32', 'matern52', and 'cubic'. Default: 'Gaussian'.
%       CoKrigInfo.nrestart - Number of restarts for hyperparameters optimization. Default: 1.
%       CoKrigInfo.LOOCVtype - Type of cross validation error. Default: 'rmse'.
%       CoKrigInfo.optimizer - Optimizer for hyperparameters optimization. Default: 'fmincon'.
%
%       CoKrigInfo.level{:}.display - Set to 1 for displaying parameter settings, set to otherwise for no display.
%       CoKrigInfo.level{:}.X - Experimental design (note that the experimental design will be normalized to [-1,1].
%       CoKrigInfo.level{:}.Y - Responses of the experimental design.
%       CoKrigInfo.level{:}.problem - Function name to evaluate responses (No need to specify this if KrigInfo.X and KrigInfo.Y are specified).
%       CoKrigInfo.level{:}.noisefree - true = noise free case; false = noisy case
%       CoKrigInfo.level{:}.kernvar - kernel variance: for noisy case give fields: 'lb' and 'ub' (logarithmic scale) or 'value' (linear scale)
%       CoKrigInfo.level{:}.noisevar - noise variance: for noisy case give fields: 'lb' and 'ub' (logarithmic scale) or 'value' (linear scale)
%       CoKrigInfo.level{:}.TrendFunction - Polynomial trend function. Default: 1 (ordinary Kriging).
%       CoKrigInfo.level{:}.RegFunction - Polynomial regression function. Default: 1 (only for levels > 1)
%       CoKrigInfo.level{:}.kernel - Kernel function. Available kernels are 'gaussian', 'exponential','matern32', 'matern52', and 'cubic'. Default: 'matern52'.
%       CoKrigInfo.level{:}.nrestart - Number of restarts for hyperparameters optimization. Default: 3.
%       CoKrigInfo.level{:}.LOOCVtype - Type of cross validation error. Default: 'rmse'.
%       CoKrigInfo.level{:}.optimizer - Optimizer for hyperparameters optimization. Default: 'fmincon'.
%
%  Author: Lucia Parussini (lparussini@units.it)
%
%% Set up the CoKriging
cokriging_setup % Call the cokriging_setup subroutine
Ypred = cell(CoKrigInfo.nlev-1,CoKrigInfo.nlev-1);
S2pred = cell(CoKrigInfo.nlev-1,CoKrigInfo.nlev-1);

%% LEVEL 1 (low fidelity model)
if lev == 1
    if CoKrigInfo.level{1}.display == 1; fprintf('--- LEVEL 1 ---\n'); end
    % train the Kriging model
    if nargin < 3
        CoKrigInfo.level{1}= train_Kriging(CoKrigInfo.level{1});
    else
        CoKrigInfo.level{1}= train_Kriging(CoKrigInfo.level{1}, intopts);
    end
end

for i = 1 : CoKrigInfo.nlev-1
    [Y,S2] = krigprediction(CoKrigInfo.level{i+1}.X, CoKrigInfo.level{1}, 'pred');
    Ypred(1,i) = {Y};
    S2pred(1,i) = {S2};
    clear Y S2;
end
if lev > 2
    for k = 2 : lev-1
        for i = k : CoKrigInfo.nlev-1
            KrigInfo = CoKrigInfo.level{k};
            KrigInfo.Ypred = Ypred{k-1,i};
            KrigInfo.S2pred = S2pred{k-1,i};
            [Y,S2] = cokriglevprediction(CoKrigInfo.level{i+1}.X, KrigInfo, 'pred'); % prediction
            Ypred(k,i) = {Y};
            S2pred(k,i) = {S2};
            clear Y S2;
        end
    end
end

%% LEVEL k (k-th fidelity model)
for k = max(2,lev) : CoKrigInfo.nlev
    if CoKrigInfo.level{k}.display == 1; fprintf('--- LEVEL %d ---\n', k); end

    % train cokriging level model
    KrigInfo = CoKrigInfo.level{k};
    KrigInfo.Ypred = Ypred{k-1,k-1};
    KrigInfo.S2pred = S2pred{k-1,k-1};
    if nargin < 3
        CoKrigInfo.level{k} = train_CoKriging_level(KrigInfo); 
    else
        CoKrigInfo.level{k} = train_CoKriging_level(KrigInfo, intopts); 
    end
    % prediction of level k model on sampled point of higher levels
    if( k < CoKrigInfo.nlev )
        for i = k : CoKrigInfo.nlev - 1
            KrigInfo = CoKrigInfo.level{k};
            KrigInfo.Ypred = Ypred{k-1,i};
            KrigInfo.S2pred = S2pred{k-1,i};
            [Y,S2] = cokriglevprediction(CoKrigInfo.level{i+1}.X, KrigInfo, 'pred'); % prediction
            Ypred(k,i) = {Y};
            S2pred(k,i) = {S2};
            clear Y S2;
        end
    end
end

myCoKriging = CoKrigInfo;

