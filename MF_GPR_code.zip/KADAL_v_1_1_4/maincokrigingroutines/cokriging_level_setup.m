%%
%  Author: Lucia Parussini (lparussini@units.it)
%%
% For displaying the parameter settings
if (isfield(KrigInfo,'display') == 0)
    KrigInfo.display = 1; % By default, the program shows the parameter settings
end
%% Check the existence of necessary parameters
if (isfield(KrigInfo,'lb') == 0) % Check the existence of variables' lower bound
    error('Lower bounds of variables, KrigInfo.lb, are not specified'); % Display error
end

if (isfield(KrigInfo,'ub') == 0) % Check the existence of variables' lower bound
    error('Upper bounds of variables, KrigInfo.lb, are not specified'); % Display error
end

if (isfield(KrigInfo,'nvar') == 0) % Check the existence of the number of variables
    error('The number of variables, KrigInfo.nvar, is not specified'); % Display error
end

if (isfield(KrigInfo,'nsamp') == 0) % Check the existence of the number of samples
    error('The number of samples, KrigInfo.nsamp, is not specified'); % Display error
end

% Check the lower and upper bounds.
if min(KrigInfo.ub>KrigInfo.lb) == 0
    error('The upper bounds should be higher than the lower bounds')
end

%% Set default values
% If KrigInfo.X (experimental design) is not specified, generate the sampling points using random latin hypercube sampling
if (isfield(KrigInfo,'X') == 0)
    KrigInfo.X = variabletransf(rlh(KrigInfo.nsamp,KrigInfo.nvar),[KrigInfo.lb;KrigInfo.ub]');
    if KrigInfo.display == 1; disp('The experimental design is not specified, generating sampling point using latin hypercube sampling.'); end
else
    if KrigInfo.display == 1; disp('The experimental design is specified by the user.'); end
end

% If KrigInfo.Y (vector of response values) is not specified, evaluate the function
if (isfield(KrigInfo,'Y') == 0)
    KrigInfo.Y = zeros(size(KrigInfo.X,1),1);
    if KrigInfo.display == 1; disp('The function responses are not specified, now evaluating sampling points.'); end
    if isfield(KrigInfo,'problem') == 0
        error('The problem is not specified. Please specify either sampling points or the problem.')
    end
    for ii = 1:size(KrigInfo.Y)
        KrigInfo.Y(ii,1) = feval(KrigInfo.problem,KrigInfo.X(ii,:));
    end
else
    if KrigInfo.display == 1; disp('The function responses are specified by the user.'); end
end

% Throw away samples that do not yield any value (please assign NaN to such samples, if there is any)
[~,I] = find(isnan(KrigInfo.Y)==1);
KrigInfo.X(I,:) = []; % Throw away failed sampling points
KrigInfo.Y(I,:) = []; % Throw away failed responses
KrigInfo.nsamp = size(KrigInfo.X,1); % Re-compute the sample size

% If the polynomial term is not specified, set the default value to 1 (ordinary Kriging)
if (isfield(KrigInfo,'TrendFunction') == 0)
    KrigInfo.TrendFunction = @(x)[1];
    if KrigInfo.display == 1; disp('The trend function is not specified, setting the function to 1 (ordinary Kriging).'); end
end
KrigInfo.nTrendCoeff = length(KrigInfo.TrendFunction(ones(1,KrigInfo.nvar)));

% If the expression function of autoregressive part is not specified, set the default value to 1 
if (isfield(KrigInfo,'RegrFunction') == 0)
    KrigInfo.RegrFunction = @(x)[1];
    if KrigInfo.display == 1; disp('The regression function is not specified, setting the function to 1.'); end
end
KrigInfo.nRegrCoeff = length(KrigInfo.RegrFunction(ones(1,KrigInfo.nvar)));

% check noise free case or noisy case
if (isfield(KrigInfo,'noisefree') == 0)
    if (isfield(KrigInfo,'kernvar') == 0 && isfield(KrigInfo,'noisevar') == 0) || ...
            (isfield(KrigInfo,'kernvar') == 0 && isfield(KrigInfo,'noisevar') == 1 && isfield(KrigInfo.noisevar,'userdefined_value') == 1)
        KrigInfo.noisefree = 1; % NOISE FREE
    elseif (isfield(KrigInfo,'kernvar') == 1 &&  isfield(KrigInfo,'noisevar') == 1)
        if ( isfield(KrigInfo.kernvar,'userdefined_value')==1 || ( isfield(KrigInfo.kernvar,'lb') == 1 && isfield(KrigInfo.kernvar,'ub')== 1 ) )&&...
                ( isfield(KrigInfo.noisevar,'userdefined_value')==1 || ( isfield(KrigInfo.noisevar,'lb') == 1 && isfield(KrigInfo.noisevar,'ub')== 1 ) )
            KrigInfo.noisefree = 0; % NOISY
        end
    end
end

if (KrigInfo.noisefree == 1) % FREE NOISE
    if (isfield(KrigInfo,'kernvar') == 1)
        if KrigInfo.display == 1; disp('If noise free case, the kernel variance has closed formulation and must not be specified.'); end
    end
    if (isfield(KrigInfo,'noisevar') == 0)
        % If the white noise variance is not specified, set the default value to -10 for the normalized model (not tunable)
        KrigInfo.noisevar.value = undoNormalize(1e-10,0.*mean(KrigInfo.Y),std(KrigInfo.Y).^2);
        KrigInfo.noisevar.tuned = 0;
        if KrigInfo.display == 1; disp('The white noise variance is not specified, setting the value to 1e-10.'); end
    else
        if (isfield(KrigInfo.noisevar,'userdefined_value') == 1)
            KrigInfo.noisevar.value = KrigInfo.noisevar.userdefined_value;
            KrigInfo.noisevar.tuned = 0;
            if KrigInfo.display == 1; disp('The white noise variance is specified by user.'); end
        else
            if KrigInfo.display == 1; disp('If noise free case, the white noise variance must not be tuned.'); end
        end
    end
else % NOISY
    % The kernel variance has not closed formulation, it must be user defined or tuned
    if (isfield(KrigInfo,'kernvar') == 0)
        KrigInfo.kernvar.lb = -8; % kernel variance, lower bound (log scale)
        KrigInfo.kernvar.ub = 8;  % kernel variance, upper bound (log scale)
        KrigInfo.kernvar.tuned = 1;
        if KrigInfo.display == 1; disp('The kernel variance should have a value or an interval where to be tuned, setting the value to [-8,8].'); end
    else
        if (isfield(KrigInfo.kernvar,'userdefined_value') == 1)
            KrigInfo.kernvar.value =  KrigInfo.kernvar.userdefined_value;
            KrigInfo.kernvar.tuned = 0;
            if KrigInfo.display == 1; disp(['The kernel variance is fixed by the user to ',num2str(KrigInfo.kernvar.value),'.']); end
        elseif (isfield(KrigInfo.kernvar,'lb') == 1 && isfield(KrigInfo.kernvar,'ub') == 1)
            KrigInfo.kernvar.tuned = 1;
            if KrigInfo.display == 1; disp('The kernel variance is tunable.'); end
            if KrigInfo.kernvar.lb > KrigInfo.kernvar.ub
                error('The lower bound of the kernel variance should be lower than the upper bound.')
            end
        else
            error('Something wrong with kernel variance definition.')
        end
    end
    % The noise variance must be user defined or tuned
    if (isfield(KrigInfo,'noisevar') == 0)
        KrigInfo.noisevar.lb = -6; % white noise variance, lower bound (log scale)
        KrigInfo.noisevar.ub = 1;  % white noise variance, upper bound (log scale)
        KrigInfo.noisevar.tuned = 1;
        if KrigInfo.display == 1;  disp('The white noise variance should have a value or an interval where to be tuned, setting the value to [-6,1].'); end
    else
        if (isfield(KrigInfo.noisevar,'userdefined_value') == 1)
            KrigInfo.noisevar.value =  KrigInfo.noisevar.userdefined_value;
            KrigInfo.noisevar.tuned = 0;
            if KrigInfo.display == 1; disp(['The white noise variance is fixed by the user to ',num2str(KrigInfo.noisevar.value),'.']); end
        elseif (isfield(KrigInfo.noisevar,'lb') == 1 && isfield(KrigInfo.noisevar,'ub') == 1)
            KrigInfo.noisevar.tuned = 1;
            if KrigInfo.display == 1; disp('The white noise variance is set to be tunable by the user.'); end
            if KrigInfo.noisevar.lb > KrigInfo.noisevar.ub
                error('The lower bound of the white noise variance should be lower than the upper bound.')
            end
        else
            error('Something wrong with white noise variance definition.')
        end
    end
end

% check nested case or no nested case
if (KrigInfo.nested == 0)
    % The kernel variance has not closed formulation, it must be user defined or tuned
    if (isfield(KrigInfo,'kernvar') == 0)
        KrigInfo.kernvar.lb = -8; % kernel variance, lower bound (log scale)
        KrigInfo.kernvar.ub = 8;  % kernel variance, upper bound (log scale)
        KrigInfo.kernvar.tuned = 1;
        if KrigInfo.display == 1;  disp('The kernel variance should have a value or an interval where to be tuned, setting the value to [-8,8].'); end
    else
        if (isfield(KrigInfo.kernvar,'userdefined_value') == 1)
            KrigInfo.kernvar.value =  KrigInfo.kernvar.userdefined_value;
            KrigInfo.kernvar.tuned = 0;
            if KrigInfo.display == 1; disp(['The kernel variance is fixed by the user to ',num2str(KrigInfo.kernvar.value),'.']); end
        elseif (isfield(KrigInfo.kernvar,'lb') == 1 && isfield(KrigInfo.kernvar,'ub') == 1)
            KrigInfo.kernvar.tuned = 1;
            if KrigInfo.display == 1; disp('The kernel variance is tunable.'); end
            if KrigInfo.kernvar.lb > KrigInfo.kernvar.ub
                error('The lower bound of the kernel variance should be lower than the upper bound.')
            end
        else
            error('Something wrong with kernel variance definition.')
        end
    end
    % The beta coefficients have not closed formulation, they must be fixed or tuned
    if (isfield(KrigInfo,'beta') == 0)
        KrigInfo.beta.lb = repmat(-3,1,KrigInfo.nRegrCoeff + KrigInfo.nTrendCoeff); % beta coefficients, lower bound (log scale)
        KrigInfo.beta.ub = repmat( 3,1,KrigInfo.nRegrCoeff + KrigInfo.nTrendCoeff); % beta coefficients, upper bound (log scale)
        KrigInfo.beta.tuned = 1;
        if KrigInfo.display == 1;  disp('The beta coefficients should have a value or an interval where to be tuned, setting the value to [-3,3].'); end
    else
        if (isfield(KrigInfo.beta,'userdefined_value') == 1)
            KrigInfo.beta.value =  KrigInfo.beta.userdefined_value;
            KrigInfo.beta.tuned = 0;
            if KrigInfo.display == 1; disp(['The beta coefficients are fixed by the user to ',num2str(KrigInfo.beta.value),'.']); end
        elseif (isfield(KrigInfo.beta,'lb') == 1 && isfield(KrigInfo.beta,'ub') == 1)
            KrigInfo.beta.tuned = 1;
            if KrigInfo.display == 1; disp('The kernel variance is tunable.'); end
            if min(KrigInfo.beta.ub > KrigInfo.beta.lb) == 0
                error('The lower bound of the beta coefficients should be lower than the upper bound.')
            end
        else
            error('Something wrong with beta coefficients definition.')
        end
    end
end

% If the bounds of length scales are not specified, set the default value
if (isfield(KrigInfo,'lengthscale') == 0)
    KrigInfo.lengthscale.lb = ones(1,KrigInfo.nvar)*-3; % Lower bound for lengthscale optimization; [1 x nvar] (log scale)
    KrigInfo.lengthscale.ub = ones(1,KrigInfo.nvar)* 2; % Upper bound for lengthscale optimization; [1 x nvar] (log scale)
    KrigInfo.lengthscale.tuned = 1;
    if KrigInfo.display == 1; disp('The bounds for the length scales are not specified, setting the default lengthscales bounds.'); end
else
    if (isfield(KrigInfo.lengthscale,'userdefined_value') == 1)
        KrigInfo.lengthscale.value =  KrigInfo.lengthscale.userdefined_value;
        KrigInfo.lengthscale.tuned = 0;
        if KrigInfo.display == 1; disp(['The length scales are defined by the user to ',num2str(KrigInfo.lengthscale.value),'.']); end
    elseif (isfield(KrigInfo.lengthscale,'lb') == 1 && isfield(KrigInfo.lengthscale,'ub') == 1)
        KrigInfo.lengthscale.tuned = 1;
        if KrigInfo.display == 1; disp('The length scales are set to be tunable by the user.'); end
        if min(KrigInfo.lengthscale.ub > KrigInfo.lengthscale.lb) == 0
            error('The lower bound of the length scales should be lower than the upper bound.')
        end
    else
        error('Something wrong with length scales definition.')
    end
end

% If the kernel is not specified, set to matern-5/2
if (isfield(KrigInfo,'kernel') == 0)
    KrigInfo.kernel   = {'matern52'}; % Set Matern-5/2 as the default kernel
    if KrigInfo.display == 1; disp('The kernel is not specified, setting Matern-5/2 as the default kernel.'); end
else
    availablekernels = {'gaussian','exponential','matern32','matern52','cubic1','cubic2'};
    tcomp = zeros(1,length(KrigInfo.kernel));
    for jj = 1:length(KrigInfo.kernel)
        tcomp(jj) = max(strcmp(KrigInfo.kernel(jj),availablekernels));
        if tcomp(jj) == 0
            warning([char(KrigInfo.kernel(jj)),' is not a valid kernel.'])
        end
    end
    if min(tcomp) == 0
        error('Cannot continue because one/more kernels are not valid.')
    end
end
KrigInfo.nkrnl = length(KrigInfo.kernel); % Number of kernel functions

% If KrigInfo.nrestart (number of restart for internal optimization) is not specified, set KrigInfo.nrestart to 3.
if (isfield(KrigInfo,'nrestart') == 0)
    KrigInfo.nrestart = 3;
    if KrigInfo.display == 1; disp('The number of restart for internal optimization is not specified, setting KrigInfo.nrestart to 3 .'); end
    if KrigInfo.nrestart < 1
        error('KrigInfo.nrestart should be a positive value');
    end
else
    if KrigInfo.display == 1; disp('The number of restart for CMA-ES is specified by the user'); end
end

% If KrigInfo.startpoint (starting point(s) for internal optimization) is not specified, generate starting points using latin hypercube sampling
if (isfield(KrigInfo,'startpoint') == 0)
    if KrigInfo.display == 1; disp('The starting point for internal optimization is not specified, latin hypercube sampling will be used.'); end
else
    if KrigInfo.startpoint == 1; disp('The starting point for internal optimization is specified by the user'); end  
end

% If KrigInfo.LOOCVtype (type of cross validation error) is not specified, set KrigInfo.LOOCVtype to 'rmse' (root-mean-squared error).
if (isfield(KrigInfo,'LOOCVtype') == 0)
    KrigInfo.LOOCVtype = 'rmse';
    if KrigInfo.display == 1; disp('The type of LOOCV error is not specified, setting KrigInfo.LOOCVtype to RMSE.'); end
    availabletypes = {'mae','mse','rmse','mare','rmsre','mape','mspe','rmspe'};
    if max(strcmp(KrigInfo.LOOCVtype,availabletypes)) == 0
        error([KrigInfo.LOOCVtype ' is not a valid type of LOOCV.'])
    end
else
    if KrigInfo.display == 1; disp(['The type of LOOCV error is specified by the user: ',KrigInfo.LOOCVtype]); end
end

% If KrigInfo.optimizer (optimizer for inner optimization problem) is not specified, set KrigInfo.optimizer to fmincon.
if (isfield(KrigInfo,'optimizer') == 0)
    KrigInfo.optimizer = 'fmincon';
    if KrigInfo.display == 1; disp('The inner problem optimizer is not specified, setting KrigInfo.optimizer to ''fmincon'''); end
else
    availableoptimizer = {'cmaes','fmincon','ga'};
    if max(strcmp(KrigInfo.optimizer,availableoptimizer)) == 0
        error(['''',KrigInfo.optimizer, ''' is not a valid optimizer.'])
    end
    if KrigInfo.display == 1; disp(['The inner problem optimizer is specified to ''',KrigInfo.optimizer ,''' by the user']); end
end

%% Pre-hyperparameter optimization
if isfield(KrigInfo,'meanX') == 1 KrigInfo = rmfield(KrigInfo,'meanX'); end
if isfield(KrigInfo,'stdX') == 1 KrigInfo = rmfield(KrigInfo,'stdX'); end
if isfield(KrigInfo,'Xnorm') == 1 KrigInfo = rmfield(KrigInfo,'Xnorm'); end
if isfield(KrigInfo,'meanY') == 1 KrigInfo = rmfield(KrigInfo,'meanY'); end
if isfield(KrigInfo,'stdY') == 1 KrigInfo = rmfield(KrigInfo,'stdY'); end
if isfield(KrigInfo,'Ynorm') == 1 KrigInfo = rmfield(KrigInfo,'Ynorm'); end
if isfield(KrigInfo,'F') == 1 KrigInfo = rmfield(KrigInfo,'F'); end
if isfield(KrigInfo,'lbhyp') == 1 KrigInfo = rmfield(KrigInfo,'lbhyp'); end
if isfield(KrigInfo,'ubhyp') == 1 KrigInfo = rmfield(KrigInfo,'ubhyp'); end

% normalization
KrigInfo.meanX = mean(KrigInfo.X);
KrigInfo.stdX = std(KrigInfo.X); 
KrigInfo.Xnorm = doNormalize(KrigInfo.X,KrigInfo.meanX,KrigInfo.stdX);
KrigInfo.meanY = mean(KrigInfo.Y); %0; %
KrigInfo.stdY = std(KrigInfo.Y); %1; %
KrigInfo.Ynorm = doNormalize(KrigInfo.Y,KrigInfo.meanY,KrigInfo.stdY);
if isfield(KrigInfo,'noisevar') == 1 && (isfield(KrigInfo.noisevar,'value') == 1)    
    KrigInfo.noisevar.value = doNormalize(KrigInfo.noisevar.value,0.*KrigInfo.meanY,KrigInfo.stdY.^2);
end

% compute trend matrix
for i=1:KrigInfo.nsamp
    KrigInfo.F(i,:) = KrigInfo.TrendFunction(KrigInfo.Xnorm(i,:));
end

% If there is an autoregressive part
if isfield(KrigInfo,'Yprednorm') == 1 KrigInfo = rmfield(KrigInfo,'Yprednorm'); end
if isfield(KrigInfo,'S2prednorm') == 1 KrigInfo = rmfield(KrigInfo,'S2prednorm'); end
if isfield(KrigInfo,'AR') == 1 KrigInfo = rmfield(KrigInfo,'AR'); end
% compute autoregressive matrix
KrigInfo.Yprednorm = doNormalize(KrigInfo.Ypred,KrigInfo.meanY,KrigInfo.stdY);
KrigInfo.S2prednorm = doNormalize(KrigInfo.S2pred,KrigInfo.meanY.*0,KrigInfo.stdY.^2);
KrigInfo.AR.Ypred = KrigInfo.Yprednorm;
for i=1:KrigInfo.nsamp
    KrigInfo.AR.F(i,:) = KrigInfo.RegrFunction(KrigInfo.Xnorm(i,:));
end
KrigInfo.F = [KrigInfo.AR.F .* repmat(KrigInfo.AR.Ypred, 1, KrigInfo.nRegrCoeff), KrigInfo.F];

% interval search for hyperparameters to be tuned
KrigInfo.lbhyp = [];
KrigInfo.ubhyp = [];
if isfield(KrigInfo,'lengthscale') == 1 && isfield(KrigInfo.lengthscale,'tuned') == 1 && KrigInfo.lengthscale.tuned == 1
    KrigInfo.lbhyp = KrigInfo.lengthscale.lb;
    KrigInfo.ubhyp = KrigInfo.lengthscale.ub;
end
% If the regression factor and/or Kriging variance are tunable and/or multiple kernels are set, set them as extra hyperparameters
if isfield(KrigInfo,'kernvar') == 1 && isfield(KrigInfo.kernvar,'tuned') == 1 && KrigInfo.kernvar.tuned == 1
    KrigInfo.lbhyp = [KrigInfo.lbhyp KrigInfo.kernvar.lb];
    KrigInfo.ubhyp = [KrigInfo.ubhyp KrigInfo.kernvar.ub];
end
if isfield(KrigInfo,'noisevar') == 1 && isfield(KrigInfo.noisevar,'tuned') == 1 && KrigInfo.noisevar.tuned == 1
    KrigInfo.lbhyp = [KrigInfo.lbhyp KrigInfo.noisevar.lb];
    KrigInfo.ubhyp = [KrigInfo.ubhyp KrigInfo.noisevar.ub];
end
if isfield(KrigInfo,'beta') == 1 && isfield(KrigInfo.beta,'tuned') == 1 && KrigInfo.beta.tuned == 1
    KrigInfo.lbhyp = [KrigInfo.lbhyp KrigInfo.beta.lb];
    KrigInfo.ubhyp = [KrigInfo.ubhyp KrigInfo.beta.ub];
end
if KrigInfo.nkrnl > 1
    KrigInfo.lbhyp = [KrigInfo.lbhyp zeros(1,KrigInfo.nkrnl)+eps];
    KrigInfo.ubhyp = [KrigInfo.ubhyp  ones(1,KrigInfo.nkrnl)];
end
KrigInfo.nbhyp = length(KrigInfo.lbhyp);  % Number of hyperparameters




