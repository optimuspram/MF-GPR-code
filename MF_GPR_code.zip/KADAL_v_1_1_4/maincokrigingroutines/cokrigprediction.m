
function [output, SSqr, y_hat, trend] = cokrigprediction(XP,CoKriging,predictiontype)
% Calculates expected improvement (for optimization), SSqr, Kriging prediction, and prediction from regression function
%
% Information: This function is a modification from "Forrester, A., Sobester, A., & Keane, A. (2008). Engineering design via surrogate modelling:  a practical guide. John Wiley & Sons."
%
% Inputs:
%   XP - Prediction site 
%   CoKriging - A structure containing necessary information of a constructed COKriging model
%
% Outputs:
%   output - The output is a CoKriging.nlev cell of structures with these  fields:
%   'pred' % Kriging prediction (this can also be used as acquisition function)
%   'SSqr' % Kriging sigma-squared error
%   'trend' % Trend function
%   'EI' % Expected improvement acquisition function
%
% Information:
%  - Note that the output can be vectorized.
%
%  Author: Lucia Parussini (lparussini@units.it)
%
%%

nlevel = CoKriging.nlev;
output = cell(1, nlevel);
SSqr = cell(1, nlevel); 
y_hat = cell(1, nlevel); 
trend = cell(1, nlevel);

KrigInfo1 = CoKriging.level{1};
[output{1}, SSqr{1}, y_hat{1}, trend{1}] = krigprediction(XP, KrigInfo1, predictiontype);
for k = 2 : CoKriging.nlev
    KrigInfok = CoKriging.level{k};
    KrigInfok.Ypred = y_hat{k-1}; 
    KrigInfok.S2pred =SSqr{k-1};
    [output{k}, SSqr{k}, y_hat{k}, trend{k}]  = cokriglevprediction(XP, KrigInfok ,predictiontype);
end


  

    


