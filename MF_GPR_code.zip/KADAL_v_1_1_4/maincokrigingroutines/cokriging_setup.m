%%
%  Author: Lucia Parussini (lparussini@units.it)
%%
% For displaying the parameter settings
if (isfield(CoKrigInfo,'display') == 0)
    CoKrigInfo.display = 1; % By default, the program shows the parameter settings
end
%% Check the existence of necessary parameters
if (isfield(CoKrigInfo,'level') == 0) % Check the existence of KrigInfo
    error('The level field of CoKrigInfo (cell array containing the infos of each fidelity level to train the model) is not specified'); % Display error
else
    for k = 1 : length(CoKrigInfo.level)
        if (isfield(CoKrigInfo,'lb') == 0) && (isfield(CoKrigInfo.level{k},'lb') == 0)% Check the existence of variables' lower bound
            error('Lower bounds of variables, CoKrigInfo.level{%d}.lb, is not specified at fidelity level %d, nor in CoKrigInfo.lb', k); % Display error
        end
        if (isfield(CoKrigInfo,'ub') == 0) && (isfield(CoKrigInfo.level{k},'ub') == 0) % Check the existence of variables' upper bound
            error('Upper bounds of variables, CoKrigInfo.level{%d}.ub, is not specified at fidelity level %d, nor in CoKrigInfo.ub', k); % Display error
        end
        if (isfield(CoKrigInfo,'nvar') == 0) && (isfield(CoKrigInfo.level{k},'nvar') == 0) %  Check the existence of the number of variables
            error('The number of variables, CoKrigInfo.level{%d}.nvar, is not specified at fidelity level %d, nor in CoKrigInfo.nvar', k); % Display error
        end
        if (isfield(CoKrigInfo.level{k},'nsamp') == 0)  %  Check the existence of the number of samples
            error('The number of samples, CoKrigInfo.level{%d}.nsamp, is not specified at fidelity level %d', k); % Display error
        end
    end
end

% Check the lower and upper bounds.
if (isfield(CoKrigInfo.level{k},'lb') == 1) && (isfield(CoKrigInfo.level{k},'ub') == 1)
    if min(CoKrigInfo.ub > CoKrigInfo.lb) == 0
        error('The upper bounds should be higher than the lower bounds')
    end
end

%% Fill empty level fields
if (isfield(CoKrigInfo,'nlev') == 0) % Check the existence of the number of levels
    CoKrigInfo.nlev = length(CoKrigInfo.level);
end

for k = 1 : CoKrigInfo.nlev
    if (isfield(CoKrigInfo,'display') == 1 && isfield(CoKrigInfo.level{k},'display') == 0)
        CoKrigInfo.level{k}.display = CoKrigInfo.display;
    end
    if (isfield(CoKrigInfo,'noisefree') == 1 && isfield(CoKrigInfo.level{k},'noisefree') == 0)
        CoKrigInfo.level{k}.noisefree = CoKrigInfo.noisefree;
    end
    if (isfield(CoKrigInfo.level{k},'lb') == 0) 
        CoKrigInfo.level{k}.lb = CoKrigInfo.lb;
    end
    if (isfield(CoKrigInfo.level{k},'ub') == 0) 
        CoKrigInfo.level{k}.ub = CoKrigInfo.ub;
    end
    if (isfield(CoKrigInfo.level{k},'nvar') == 0) 
        CoKrigInfo.level{k}.nvar = CoKrigInfo.nvar;
    end
    if (isfield(CoKrigInfo,'noisevar') == 1 && isfield(CoKrigInfo.level{k},'noisevar') == 0)
        CoKrigInfo.level{k}.noisevar = CoKrigInfo.noisevar;
    end
    if (isfield(CoKrigInfo,'kernvar') == 1 && isfield(CoKrigInfo.level{k},'kernvar') == 0)
        CoKrigInfo.level{k}.kernvar = CoKrigInfo.kernvar;
    end
    if (isfield(CoKrigInfo,'beta') == 1 && isfield(CoKrigInfo.level{k},'beta') == 0)
        CoKrigInfo.level{k}.beta = CoKrigInfo.beta;
    end
    if (isfield(CoKrigInfo,'lengthscale') == 1 && isfield(CoKrigInfo.level{k},'lengthscale') == 0)
        CoKrigInfo.level{k}.lengthscale = CoKrigInfo.lengthscale;
    end
    if (isfield(CoKrigInfo,'wgkf') == 1 && isfield(CoKrigInfo.level{k},'wgkf') == 0)
        CoKrigInfo.level{k}.wgkf = CoKrigInfo.wgkf;
    end    
    if (isfield(CoKrigInfo,'TrendFunction') == 1 && isfield(CoKrigInfo.level{k},'TrendFunction') == 0)
        CoKrigInfo.level{k}.TrendFunction = CoKrigInfo.TrendFunction;
    end
    if (k > 1 && isfield(CoKrigInfo,'RegrFunction') == 1 && isfield(CoKrigInfo.level{k},'RegrFunction') == 0)
        CoKrigInfo.level{k}.RegrFunction = CoKrigInfo.RegrFunction;
    end    
    if (isfield(CoKrigInfo,'kernel') == 1 && isfield(CoKrigInfo.level{k},'kernel') == 0)
        CoKrigInfo.level{k}.kernel = CoKrigInfo.kernel;
    end
    if (isfield(CoKrigInfo,'nrestart') == 1 && isfield(CoKrigInfo.level{k},'nrestart') == 0)
        CoKrigInfo.level{k}.nrestart = CoKrigInfo.nrestart;
    end
    if (isfield(CoKrigInfo,'LOOCVtype') == 1 && isfield(CoKrigInfo.level{k},'LOOCVtype') == 0)
        CoKrigInfo.level{k}.LOOCVtype = CoKrigInfo.LOOCVtype;
    end
    if (isfield(CoKrigInfo,'optimizer') == 1 && isfield(CoKrigInfo.level{k},'optimizer') == 0)
        CoKrigInfo.level{k}.optimizer = CoKrigInfo.optimizer;
    end
end

%% Set default values
for k = 1 : CoKrigInfo.nlev
    if CoKrigInfo.level{k}.display == 1; fprintf('--- LEVEL %d ---\n', k); end
    % If CoKrigInfo.level{k}.X (experimental design) is not specified, generate the sampling points using random latin hypercube sampling
    if (isfield(CoKrigInfo.level{k},'X') == 0)
        if (k > 1 && isfield(CoKrigInfo,'nested') == 1 && CoKrigInfo.nested == 1)
            CoKrigInfo.KrigInfo{k}.X = CoKrigInfo.KrigInfo{k-1}.X(sort(randperm(CoKrigInfo.KrigInfo{k-1}.nsamp, CoKrigInfo.KrigInfo{k}.nsamp)), 1 : CoKrigInfo.nvar); % Set the experimental design.
            if CoKrigInfo.level{k}.display == 1; disp('The experimental design is not specified, generating sampling point using random nested selection from lower fidelity samples.'); end
        else
            CoKrigInfo.level{k}.X = variabletransf(rlh(CoKrigInfo.level{k}.nsamp,CoKrigInfo.level{k}.nvar),[CoKrigInfo.level{k}.lb;CoKrigInfo.level{k}.ub]');
            if CoKrigInfo.level{k}.display == 1; disp('The experimental design is not specified, generating sampling point using latin hypercube sampling.'); end
        end
    else
        if CoKrigInfo.level{k}.display == 1; disp('The experimental design is specified by the user.'); end
    end

    % If CoKrigInfo.level{k}.Y (vector of response values) is not specified, evaluate the function
    if (isfield(CoKrigInfo.level{k},'Y') == 0)
        CoKrigInfo.level{k}.Y = zeros(size(CoKrigInfo.level{k}.X,1),1);
        if CoKrigInfo.level{k}.display == 1; disp('The function responses are not specified, now evaluating sampling points.'); end
        if isfield(CoKrigInfo.level{k},'problem') == 0
            error('The problem is not specified. Please specify either sampling points or the problem.')
        end
        for ii = 1:size(CoKrigInfo.level{k}.Y)
            CoKrigInfo.level{k}.Y(ii,1) = feval(CoKrigInfo.level{k}.problem,CoKrigInfo.level{k}.X(ii,:));
        end
    else
        if CoKrigInfo.level{k}.display == 1; disp('The function responses are specified by the user.'); end
    end
    
end

%% Check if designs are nested
if (isfield(CoKrigInfo,'nested') == 0)
    for k = 2 : CoKrigInfo.nlev
        if (isfield(CoKrigInfo.level{k},'nested') == 0)
            if all(ismembertol(CoKrigInfo.level{k}.X,CoKrigInfo.level{k-1}.X,1e-2,'ByRows',true))
                CoKrigInfo.level{k}.nested = 1;
            else
                CoKrigInfo.level{k}.nested = 0;
            end
        end
    end
else
    for k = 2 : CoKrigInfo.nlev
        if (isfield(CoKrigInfo.level{k},'nested') == 0)
            CoKrigInfo.level{k}.nested = CoKrigInfo.nested;
        end
    end
end

for k = 2 : CoKrigInfo.nlev
    if all(ismembertol(CoKrigInfo.level{k}.X,CoKrigInfo.level{k-1}.X,1e-2,'ByRows',true))
        if CoKrigInfo.level{k}.nested == 0
            disp(sprintf('Level %d is NESTED, but user definition is NOT NESTED .',k));
        end
    else
        if CoKrigInfo.level{k}.nested == 1
            disp(sprintf('Level %d is NOT NESTED, but user definition is NESTED .',k));
        end
    end
end


