clc
clear all
close all

% This script demonstrates unconstrained single-objective Bayesian
% optimization using Kriging for solving the SASENA function with automatic
% update disactivated
addpath(genpath(pwd)); % Add the MATLAB path
nvar = 2; % Number of variables
nsamp= 10; % Number of initial samples

%% Set Kriging Info
KrigInfo.problem = 'SASENA'; % Function to call
KrigInfo.nvar    = nvar; % Set the number of variables
KrigInfo.nsamp   = nsamp; % Set the number of initial samples
KrigInfo.lb      = zeros(1,nvar); % Lower bounds, size 1 X nvar
KrigInfo.ub      = ones(1,nvar)*5; % Upper bounds, size 1 x nvar
KrigInfo.X       = variabletransf(rand(nsamp,nvar),[KrigInfo.lb;KrigInfo.ub]'); % Set the experimental design
KrigInfo.Y       = feval(KrigInfo.problem,KrigInfo.X); % Evaluate the experimental design
KrigInfo.nrestart = 5; % Number of restart for hyperparameters optimization (using CMA-ES by default)
KrigInfo.kernel  = {'gaussian'}; % single kernel function
KrigInfo.display = 0;

%% Set Bayesian optimization info
BayesInfo.nrestart = 10; % Number of restart for optimization of acquisition function.
BayesInfo.display = 1; % Set to 0 for suppressing the output, set to 1 for otherwise.
BayesInfo.acquifunc = 'pred'; % Type of acquisition function
BayesInfo.acquifuncopt = 'cmaes'; % Optimizer for the acquisition function ('sampling+CMAES' by default)
BayesInfo.problem = KrigInfo.problem;

BayesInfo.autoupdate = 0; % Set to zero to disactivate automatic update and suggest next sample instead
%% Train Kriging model
myKriging = train_Kriging(KrigInfo);

%% Suggest next sample based on the initial Kriging model
[xnext] = singleobjbayesianoptunc(BayesInfo,myKriging); 

disp(['The suggested next sample is ',num2str(xnext)]);
