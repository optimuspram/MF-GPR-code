clc
clear all
close all

% This script demonstrates unconstrained multi-objective Bayesian optimization using Kriging
addpath(genpath(pwd)); % Add the MATLAB path
nvar = 2; % Number of variables
nsamp= 20; % Number of initial samples
nobj = 2; % Number of objectives
%% Construct Kriging for multiple objective functions
lb = [-ones(1,nvar)]; % Lower bounds of the problem
ub = [ones(1,nvar)]; % Upper bounds of the problem
X = variabletransf(rlh(nsamp,nvar),[lb;ub]'); % Create experimental design
Y = schaffer(X);

% Construct Kriging for objective 1 and 2
for ii = 1:nobj
    KrigInfo.nvar    = nvar; % Set the number of variables
    KrigInfo.nsamp   = nsamp; % Set the number of initial samples
    KrigInfo.lb      = lb; % Lower bounds, size 1 X nvar
    KrigInfo.ub      = ub; % Upper bounds, size 1 x nvar
    KrigInfo.X       = X; % Set the experimental design
    KrigInfo.Y       = Y(:,ii); % Use the responses of the first objective.
    KrigInfo.nrestart = 5; % Number of restart for hyperparameters optimization (using CMA-ES by default)
    KrigInfo.kernel  = {'gaussian'}; % single kernel function (Gaussian);
    KrigInfo.display = 0; % Suppress output.
    KrigInfoBayesMulti{ii} = train_Kriging(KrigInfo); % Create Kriging for objective 1.
end

%% Set Bayesian optimization info
BayesMultiInfo.nrestart = 30; % Number of restart for optimization of acquisition function.
BayesMultiInfo.display = 1; % Set to 0 for suppressing the output, set to 1 for otherwise.
BayesMultiInfo.acquifunc = 'EHVI'; % Type of acquisition function, set to EHVI
BayesMultiInfo.acquifuncopt = 'cmaes'; % Optimizer for the acquisition function ('cmaes' for multi-Kriging acquisition function, and 'sampling+CMAES' for single-Kriging acquisition function)

BayesMultiInfo.autoupdate = 0; % Set to zero to disactivate automatic update and suggest next sample instead
%% Suggest next sample based on the initial Kriging models
[xnext] = multiobjbayesianoptunc(BayesMultiInfo,KrigInfoBayesMulti);
