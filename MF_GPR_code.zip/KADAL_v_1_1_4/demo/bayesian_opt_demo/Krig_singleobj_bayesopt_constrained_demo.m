clc
clear all
close all

% This script demonstrates constrained single-objective Bayesian optimization using Kriging
addpath(genpath(pwd)); % Add the MATLAB path
nvar = 2; % Number of variables
nsamp= 20; % Number of initial samples

%% Set Kriging Info
KrigInfo.problem  = 'BRANINmodcon'; % Define the optimization prolem
KrigInfo.nvar     = nvar; % Set the number of variables
KrigInfo.nsamp    = nsamp; % Set the number of initial samples
KrigInfo.lb       = zeros(1,nvar); % Lower bounds, size (1 X nvar)
KrigInfo.ub       = ones(1,nvar)*1; % Upper bounds, size (1 x nvar)
KrigInfo.X        = variabletransf(rlh(nsamp,nvar),[KrigInfo.lb;KrigInfo.ub]'); % Generate the experimental design
KrigInfo.nrestart = 5; % Number of restart for hyperparameters optimization (using CMA-ES by default)
KrigInfo.display  = 0; % Set to 0 for displaying no report, set to 1 for otherwise
KrigInfo.kernel   = {'gaussian'}; % Define the kernel function

DefaultKrig       = KrigInfo; % Set the default KrigInfo to be used for the objective and constraint function later.
[Y, G]            = feval(KrigInfo.problem,KrigInfo.X); % Evaluate functions to obtain the objective and the constraints

% return
%% Build initial Kriging for the objective function
KrigInfo.Y        = Y; % Set the objective responses to KrigInfo
myKriging = train_Kriging(KrigInfo); % Train Kriging model for the objective function

%% Build initial Kriging for the constraint function
KrigConInfo       = KrigInfo; 
KrigConInfo.Y     = G; % Set the constraint responses to KrigInfo
myKrigingCon{1}   = train_Kriging(KrigConInfo); % Train Kriging model for the constraint function
myKrigingCon{1}.limit = -0.2; % Set the limit for the inequality constraints 

%% Set Bayesian optimization info
BayesInfo.problem = KrigInfo.problem; 
BayesInfo.nup = 80; % Number of updates for Bayesian optimization
BayesInfo.nrestart = 5; % Number of restart for acquisition function optimization (only for CMAES and fmincon)
BayesInfo.display = 1; % Set to 0 for displaying no report of optimization progress, set to 1 for otherwise
BayesInfo.acquifunc = 'EI'; % Set the acquisition function to EI
BayesInfo.feasfunc = 'SOCU'; % Set the feasibility function to SOCU
BayesInfo.acquifuncopt = 'sampling+cmaes'; % Set the acquisition function optimizer to 'sampling+cmaes'

%% Our bayesian optimization procedure start from a constructed Kriging model
[xbest, ybest, outputhist, KrigNewInfo, KrigNewConInfo, BayesNewInfo]  = singleobjbayesianoptcon(BayesInfo,myKriging, myKrigingCon); 

disp(['The best feasible value is ',num2str(ybest)]);
plot(outputhist.ybesthist,'bo-'); % Plot the convergence of best feasible solution

