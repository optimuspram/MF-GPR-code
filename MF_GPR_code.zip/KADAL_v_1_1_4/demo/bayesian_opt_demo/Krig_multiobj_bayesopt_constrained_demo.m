clc
clear all
close all

% This script demonstrates unconstrained multi-objective Bayesian optimization using Kriging
addpath(genpath(pwd)); % Add the MATLAB path
nvar = 2; % Number of variables
nsamp= 20; % Number of initial samples
nobj = 2; % Number of objectives
ncon = 2; % Number of constraints

%% Construct Kriging for multiple objective functions
lb = [-20 -20]; % Lower bounds of the problem
ub = [20 20]; % Upper bounds of the problem
X = variabletransf(rlh(nsamp,nvar),[lb;ub]'); % Create experimental design
[Y, G] = SRN(X); % Evaluate the objective functions at the initial sampling points

KrigInfo.nvar    = nvar; % Set the number of variables
KrigInfo.nsamp   = nsamp; % Set the number of initial samples
KrigInfo.lb      = lb; % Lower bounds, size 1 X nvar
KrigInfo.ub      = ub; % Upper bounds, size 1 x nvar
KrigInfo.X       = X; % Set the experimental design
KrigInfo.nrestart = 5; % Number of restart for hyperparameters optimization (using CMA-ES by default)
KrigInfo.kernel  = {'gaussian'}; % single kernel function (Gaussian);
KrigInfo.display = 0; % Suppress output.

% Build initial Kriging model for objective function 1 and 2
for ii = 1:nobj
    KrigInfo.Y       = Y(:,ii); % Use the responses of the first objective.
    myKriging{ii}    = train_Kriging(KrigInfo); % Create Kriging for objective ii.
end

%% Build initial Kriging model for constraint function 1 and 2
for ii = 1:nobj
    KrigInfo.Y       = G(:,ii); % Use the responses of the first objective.
    myKrigingCon{ii} = train_Kriging(KrigInfo); % Create Kriging for objective ii.
    myKrigingCon{ii}.limit = 0;
end


%% Set Bayesian optimization info
BayesMultiInfo.problem = 'SRN'; % Set the problem/function to optimize
BayesMultiInfo.nup = 80; % Number of updates for multi-objective Bayesian optimization
BayesMultiInfo.nrestart = 10; % Number of restart for optimization of acquisition function.
BayesMultiInfo.display = 1; % Set to 0 for suppressing the output, set to 1 for otherwise.
BayesMultiInfo.acquifunc = 'EHVI'; % Type of acquisition function, set to EHVI
BayesMultiInfo.acquifuncopt = 'cmaes'; % Optimizer for the acquisition function ('cmaes' for multi-Kriging acquisition function, and 'sampling+CMAES' for single-Kriging acquisition function)

%% Run bayesian optimization procedure from the initial Kriging model
[Xbest, Ybest, outputhist, KrigNewMultiInfo, KrigNewConMultiInfo, BayesNewInfo] = multiobjbayesianoptcon(BayesMultiInfo,myKriging,myKrigingCon);
