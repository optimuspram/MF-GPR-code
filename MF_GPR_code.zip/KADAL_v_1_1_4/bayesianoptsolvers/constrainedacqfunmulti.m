function  conacquifuncval=constrainedacqfunmulti(XP,BayesMultiInfo,Ypar,KrigNewMultiInfo,KrigNewConInfo, acquifunc, feasfunc)

% Calculate unconstrained acquisition function
switch acquifunc
    case 'EHVI'
        acquifuncval = EHVIcomputation(XP,Ypar,BayesMultiInfo,KrigNewMultiInfo);
end
% Calculate probability of feasibility for each constraint
ncon =length(KrigNewConInfo);
PoF  = zeros(1,ncon);

for ii=1:ncon
    PoF(1,ii)=krigprediction(XP,KrigNewConInfo{ii},feasfunc);
end

% Calculate acquisition function with constraint
conacquifuncval = acquifuncval*prod(PoF,2);
