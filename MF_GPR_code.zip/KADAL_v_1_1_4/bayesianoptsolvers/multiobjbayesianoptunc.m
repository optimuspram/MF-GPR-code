function [Xbest, Ybest, outputhist, KrigNewMultiInfo, BayesNewMultiInfo] = multiobjbayesianoptunc(BayesMultiInfo,KrigInfoBayesMulti)
%
% Perform unconstrained multi-objective Bayesian optimization
%
% Inputs:
%   BayesMultiInfo - Structure containing necessary information for multi-objective Bayesian optimization.
%   KrigInfoBayesMulti - Nested Structure containing information of the constructed initial Kriging of the objective function.
%
% Outputs:
%   Xbest - Matrix of final non-dominated solutions observed after optimization.
%   Ybest - Matrix of responses of final non-dominated solutions after optimization.
%   outputhist - history of the optimization process
%   KrigNewMultiInfo - Nested structure containing information of final Kriging models after optimization.
%   KrigConNewMultiInfo - A nested structure containing information of final Kriging models of constraints after optimization.
%   BayesNewInfo - New updated info of Bayesian optimization

%% Setting up
nsamp = KrigInfoBayesMulti{1}.nsamp; % Number of samples.
bayes_multi_setup
%% Run Bayesian optimization
nup = 1;
KrigNewMultiInfo = KrigInfoBayesMulti; % Initialize Kriging model

Xall = KrigNewMultiInfo{1}.X; Yall = zeros(size(KrigNewMultiInfo{1}.Y,1),length(KrigNewMultiInfo));
for ii = 1:length(KrigNewMultiInfo)
    Yall(:,ii) = KrigNewMultiInfo{ii}.Y;
end
Ypar = paretopoint(Yall); % Find the current non-dominated solutions

if BayesMultiInfo.autoupdate == 1
    if BayesMultiInfo.display == 1
        disp('Begin multi-objective Bayesian optimization process.')
        disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewMultiInfo{1}.X,1)),', Maximum number of updates ',num2str(BayesMultiInfo.nup)]);
    end
end

if BayesMultiInfo.krignum == 1 % Scalarized the objective function for ParEGO
    KrigScalarizedInfo = KrigInfoBayesMulti{1}; % Take the structure from one objective function
    KrigScalarizedInfo.Y = paregopre(Yall); % Normalized and scalarized objective functions
    KrigScalarizedInfo = train_Kriging(KrigScalarizedInfo); % Create the Kriging for scalarized responses
end

% Bayesian optimization main loop
total_simulation_time = tic;
while nup <= BayesMultiInfo.nup
    simulation_time = tic;
    % Iteratively update the reference point for hypervolume computation if EHVI is used as the acquisition function
    if isfield(BayesMultiInfo,'refpointtype') == 1
        if strcmp(BayesMultiInfo.refpointtype,'dynamic') % Set a dynamic reference point
            BayesMultiInfo.refpoint = max(Yall)+(max(Yall)-min(Yall))*0.5;
        end
    end
    
    % Perform one iteration of multi-objective Bayesian optimization
    if BayesMultiInfo.krignum == 1
        [xnext, fnext] = run_acquifun_opt(BayesMultiInfo, KrigScalarizedInfo); % Find the next sample to evaluate
    else
        [xnext, fnext] = run_multi_acquifun_opt(BayesMultiInfo, KrigNewMultiInfo, Ypar); % Find the next sample to evaluate
    end
    fnext
    % If automatic update is not set, directly output xnext instead of xbest
    if BayesMultiInfo.autoupdate == 0
        Xbest = xnext;
        Ybest = [];
        BayesNewMultiInfo = BayesMultiInfo;
        outputhist = [];
        return
    end
    
    % Evaluate the new sample
    ynext = feval(BayesMultiInfo.problem,xnext);
    
    % Enrich the experimental design
    for jj = 1:length(KrigInfoBayesMulti)
        KrigNewMultiInfo{jj}.X = [KrigNewMultiInfo{jj}.X;xnext];
        KrigNewMultiInfo{jj}.Y = [KrigNewMultiInfo{jj}.Y;ynext(jj)];
        % Re-create Kriging models if multiple Kriging methods are used.
        if BayesMultiInfo.krignum > 1
            KrigNewMultiInfo{jj} = train_Kriging(KrigNewMultiInfo{jj});
        end
    end
    
    Yall(end+1,:) = ynext;
    Xall(end+1,:) = xnext;
    Ypar = paretopoint(Yall); % Recompute non-dominated solutions
    
    % For ParEGO, pre-process the solution
    if BayesMultiInfo.krignum == 1
        KrigScalarizedInfo.X = [KrigScalarizedInfo.X;xnext];
        KrigScalarizedInfo.Y = paregopre(Yall); % Normalized and scalarized objective functions
        KrigScalarizedInfo = train_Kriging(KrigScalarizedInfo); % Re-train the Kriging of the scalarized functions
    end
    
    % Compute simulation time
    simulation_time_end(nsamp+nup,1) = toc(simulation_time);
    total_simulation_time_end(nsamp+nup,1) = toc(total_simulation_time);
    
    nup = nup+1; % Update the number of iterations
    % Show the optimization progress.
    if BayesMultiInfo.display == 1
        disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewMultiInfo{1}.X,1)),', Maximum number of updates ',num2str(BayesMultiInfo.nup)]);
    end
    
    % Save the results
    [Ybest,I] = paretopoint(Yall); % Find temporary non-dominated values.
    Xbest = Xall(I,:); % Temporary non-dominated solutions.
    save(BayesMultiInfo.filename,'Xbest','Ybest','KrigNewMultiInfo');
end

if BayesMultiInfo.krignum ==1 % Train individual Kriging models after ParEGO finish.
    if BayesMultiInfo.display == 1
        disp('ParEGO finished. Now retraining the Kriging models for each individual models .')
    end
    for jj = 1:length(KrigInfoBayesMulti)
        KrigNewMultiInfo{jj} = train_Kriging(KrigNewMultiInfo{jj});
    end
end

if BayesMultiInfo.display == 1
    disp('Optimization finished, now creating the final outputs.')
end

%% Write to solutions history
[Ybest,I] = paretopoint(Yall); % Find the non-dominated values.
Xbest = Xall(I,:); % Final non-dominated solutions.

% Create outputhist
for ii = 1:length(KrigNewMultiInfo)
    outputhist.Y(:,ii) = KrigNewMultiInfo{ii}.Y;
end

outputhist.Ybest = Ybest;
outputhist.X = KrigNewMultiInfo{1}.X;
outputhist.simulation_time_end = simulation_time_end;
outputhist.total_simulation_time_end = total_simulation_time_end;

% Output the new updated BayesMultiInfo
BayesNewMultiInfo = BayesMultiInfo;
