%% Check the existence of necessary parameters for Bayesian optimization
if (isfield(BayesInfo,'display') == 0) % For displaying Bayesian optimization setting and progress
    BayesInfo.display = 1; % By default, the program shows the parameter settings
end

%% Set default values

% If BayesInfo.acquifunc (the acquisition function) is not specified set to 'EI'
if (isfield(BayesInfo,'acquifunc') == 0)
    BayesInfo.acquifunc = 'EI';
    if BayesInfo.display == 1; disp('The acquisition function is not specified, set to ''ei''.'); end
else
    availableacqfunc = {'EI','SSqr','pred','LCB','PoI','EBE','WB2'};
    if max(strcmp(BayesInfo.acquifunc ,availableacqfunc)) == 0
        error(['''',BayesInfo.acquifunc , ''' is not a valid acquisition function.'])
    end
    if BayesInfo.display == 1; disp(['The acquisition function is specified to ''', BayesInfo.acquifunc ,''' by the user']); end
    
    % If BayesInfo.sigmalcb (sigma for LCB acquisition function) is not specified, set BayesInfo.sigmalcb to 3 (note that this only applies for LCB)
    if strcmp(BayesInfo.acquifunc,'LCB')
        if (isfield(BayesInfo,'sigmalcb') == 0) % Onl
            BayesInfo.sigmalcb = 3;
            if BayesInfo.display == 1; disp('The sigma for lower confidence bound is not specified, set to 3.'); end
        else
            if BayesInfo.display == 1; disp(['The sigma for lower confidence bound is specified to ', num2str(BayesInfo.sigmalcb) ,' by the user']); end
        end
    end
end

% If BayesInfo.feasfunc (the feasibility function) is not specified set to 'PoF'
if (isfield(BayesInfo,'feasfunc') == 0)
    BayesInfo.feasfunc = 'PoF';
    if BayesInfo.display == 1; disp('The feasibility function is not specified, set to ''PoF''.'); end
else
    availablefeasfunc = {'PoF','SOCU'};
    if max(strcmp(BayesInfo.feasfunc ,availablefeasfunc)) == 0
        error(['''',BayesInfo.feasfunc , ''' is not a valid feasibility function.'])
    end
    if BayesInfo.display == 1; disp(['The feasibility function is specified to ''', BayesInfo.feasfunc ,''' by the user']); end
end

% If BayesInfo.acquifuncopt (optimizer for the acquisition function) is not specified set to 'sampling+cmaes'
if (isfield(BayesInfo,'acquifuncopt') == 0)
    BayesInfo.acquifuncopt = 'sampling+cmaes';
    if BayesInfo.display == 1; disp('The acquisition function optimizer is not specified, set to ''sampling+cmaes''.'); end
else
    availableacqoptimizer = {'sampling+cmaes','sampling+fmincon','cmaes','fmincon'};
    if max(strcmp(BayesInfo.acquifuncopt,availableacqoptimizer)) == 0
        error(['''',BayesInfo.acquifuncopt, ''' is not a valid acquisition function optimizer.'])
    end
    if BayesInfo.display == 1; disp(['The acquisition function optimizer is specified to ''', BayesInfo.acquifuncopt ,''' by the user']); end
end

% If BayesInfo.nrestart (number of restart for internal optimization) is not specified, set BayesInfo.nrestart to 1.
if (isfield(BayesInfo,'nrestart') == 0)
    BayesInfo.nrestart = 1;
    if BayesInfo.display == 1; disp('The number of restart for acquisition function optimization is not specified, setting BayesInfo.nrestart to 1 .'); end
    if BayesInfo.nrestart < 1
        error('BayesInfo.nrestart should be a positive value');
    end
else
    if BayesInfo.display == 1; disp(['The number of restart for acquisition function optimization is specified by the user to ',num2str(BayesInfo.nrestart)]); end
end


% If BayesInfo.filename (file name for saving the results) is not specified, set BayesInfo.filename to 'temporarydata.mat'.
if (isfield(BayesInfo,'filename') == 0)
    BayesInfo.filename = 'temporarydata';
    if BayesInfo.display == 1; disp('The file name for saving the results is not specified, set the name to ''temporarydata.mat'''); end
else
    if BayesInfo.display == 1; disp(['The file name for saving the results is specified by the user to ''',BayesInfo.filename,''' by the user']); end
end

% If BayesInfo.update is not specified, perform automatic update.
if (isfield(BayesInfo,'autoupdate') == 0)
    BayesInfo.autoupdate = 1;
    if BayesInfo.display == 1; disp('The program will automatically update the solutions until the specified number of iterations'); end
else
    if BayesInfo.display == 1; disp(['The user set automatic update to ',num2str(BayesInfo.autoupdate)]); end
end

if BayesInfo.autoupdate == 1
    if (isfield(BayesInfo,'nup') == 0) % Check the existence of the number of updates
        error('Number of updates for single-objective Bayesian optimization, BayesInfo.nup, is not specified'); % Display error
    end
else
    BayesInfo.nup = 1;
end

if BayesInfo.autoupdate == 1
    if (isfield(BayesInfo,'problem') == 0) % Check the existence of the function to be optimized.
        error('The function for the optimization is not defined, please set ''BayesInfo.problem''')
    end
end

% If BayesInfo.stalliteration (stopping criterion using stall iteration) is not specified, set the default value to BayesInfo.nup
if (isfield(BayesInfo,'stalliteration') == 0)
    BayesInfo.stalliteration = BayesInfo.nup;
    if BayesInfo.display == 1; disp('The number of stall iteration is not specified, set to BayesInfo.nup.'); end
else
    if BayesInfo.display == 1; disp(['The number of stall iteration is specified to ',num2str(BayesInfo.stalliteration) ,' by the user.']); end
end


if exist('ncon') == 1 % If constraint exist, check the feasibility function
    % If BayesInfo.feasfunc (the feasibility function) is not specified set to 'PoF'
    if (isfield(BayesInfo,'feasfunc') == 0)
        BayesInfo.feasfunc = 'PoF';
        if BayesInfo.display == 1; disp('The feasibility function is not specified, set to ''PoF''.'); end
    else
        availablefeasfunc = {'PoF','SOCU'};
        if max(strcmp(BayesInfo.feasfunc ,availablefeasfunc)) == 0
            error(['''',BayesInfo.feasfunc , ''' is not a valid feasibility function.'])
        end
        if BayesInfo.display == 1; disp(['The feasibility function is specified to ''', BayesInfo.feasfunc ,''' by the user']); end
    end
end