function [Xbest, Ybest, outputhist, KrigNewMultiInfo, KrigNewConMultiInfo, BayesNewMultiInfo] = multiobjbayesianoptunc(BayesMultiInfo,KrigInfoBayesMulti,KrigConInfoBayesMulti)
%
% Perform unconstrained multi-objective Bayesian optimization
%
% Inputs:
%   BayesMultiInfo - Structure containing necessary information for multi-objective Bayesian optimization.
%   KrigInfoBayesMulti - Nested Structure containing information of the constructed initial Kriging of the objective function.
%   KrigConInfoBayesMulti - The nested structure containing information of the constructed initial Kriging of constraint functions.

% Outputs:
%   Xbest - Matrix of final non-dominated solutions observed after optimization.
%   Ybest - Matrix of responses of final non-dominated solutions after optimization.
%   outputhist - history of the optimization process
%   KrigNewMultiInfo - Nested structure containing information of final Kriging models after optimization.
%   KrigConNewMultiInfo - A nested structure containing information of final Kriging models of constraints after optimization.
%   BayesNewInfo - New updated info of Bayesian optimization
nsamp = KrigInfoBayesMulti{1}.nsamp; % Number of samples.
nobj = length(KrigInfoBayesMulti); % Number of objectives
ncon  = length(KrigConInfoBayesMulti); % Number of constraints


%% Setting up
bayes_multi_setup

%% Run Bayesian optimization
nup = 1;
KrigNewMultiInfo = KrigInfoBayesMulti; % Initialize Kriging model
KrigNewConMultiInfo = KrigConInfoBayesMulti; % Initialize Kriging models of the constraint functions

% Check feasible non-dominated solutions;
feasind = zeros(nsamp,ncon); % initialize feasibility index
Gall = zeros(nsamp,ncon); % Inequality constraint
for ii = 1:ncon % Loop over the number of constraint
    limits(ii,1) = KrigNewConMultiInfo{ii}.limit; % Extract the limit of constraint.
    Gall(:,ii) = KrigNewConMultiInfo{ii}.Y; % Extract the constraint values at sampling points
    feasind(:,ii) = (Gall(:,ii) <= limits(ii)); % Check feasibility, 0 for infeasible and 1 for feasible.
end

feas = zeros(nsamp,1); % Check the feasibility according to all constraints
for jj = 1:nsamp
    if sum(feasind(jj,:)) == ncon
        feas(jj,1) = 1; % Feasible solution is assigned a value of one
    end
end

Xall = KrigNewMultiInfo{1}.X; Yall = zeros(size(KrigNewMultiInfo{1}.Y,1),length(KrigNewMultiInfo));
for ii = 1:length(KrigNewMultiInfo)
    Yall(:,ii) = KrigNewMultiInfo{ii}.Y;
end
ifeas = find(feas==1); % Index of feasible solutions
Yfeas = Yall(ifeas,:); % All feasible solutions
Ypar = paretopoint(Yall); % Find the current non-dominated solutions (including infeasible solutions)
Yparf = paretopoint(Yfeas);  % Find the current feasible non-dominated solutions.

if BayesMultiInfo.display == 1
    disp('Begin multi-objective Bayesian optimization process.')
    disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewMultiInfo{1}.X,1)),', Maximum number of updates ',num2str(BayesMultiInfo.nup)]);
end

if BayesMultiInfo.krignum == 1 % (Only for ParEGO) Scalarized the objective function for ParEGO
    KrigScalarizedInfo = KrigInfoBayesMulti{1}; % Take the structure from one objective function
    KrigScalarizedInfo.Y = paregopre(Yall); % Normalized and scalarized objective functions
    KrigScalarizedInfo = train_Kriging(KrigScalarizedInfo); % Create the Kriging for scalarized responses
end

% Bayesian optimization main loop
total_simulation_time = tic;
while nup <= BayesMultiInfo.nup
    simulation_time = tic;
    % Iteratively update the reference point for hypervolume computation if EHVI is used as the acquisition function
    if isfield(BayesMultiInfo,'refpointtype') == 1
        if strcmp(BayesMultiInfo.refpointtype,'dynamic') % Set a dynamic reference point
            BayesMultiInfo.refpoint = max(Yall)+(max(Yall)-min(Yall))*2; % Use all solutions (including infeasible ones)
        end
    end
    
    % Perform one iteration of multi-objective Bayesian optimization
    if BayesMultiInfo.krignum == 1
        xnext = run_acquifun_opt(BayesMultiInfo, KrigScalarizedInfo); % Find the next sample to evaluate
    else
        xnext = run_multi_acquifun_opt(BayesMultiInfo, KrigNewMultiInfo, Yparf, KrigNewConMultiInfo); % Find the next sample to evaluate
    end
    
    % Evaluate the new sample
    [ynext, cnext] = feval(BayesMultiInfo.problem,xnext);
    
    % Enrich the experimental design (objectives)
    for jj = 1:nobj
        KrigNewMultiInfo{jj}.X = [KrigNewMultiInfo{jj}.X;xnext];
        KrigNewMultiInfo{jj}.Y = [KrigNewMultiInfo{jj}.Y;ynext(jj)];
        KrigNewMultiInfo{jj}.nsamp = length(KrigNewMultiInfo{jj}.Y);
        % Re-create Kriging models if multiple Kriging methods are used.
        if BayesMultiInfo.krignum > 1
            KrigNewMultiInfo{jj} = train_Kriging(KrigNewMultiInfo{jj});
        end
    end
    
    % Enrich the experimental design (constraint)
    for ii = 1:ncon
        KrigNewConMultiInfo{ii}.X =  [KrigNewConMultiInfo{ii}.X;xnext];
        KrigNewConMultiInfo{ii}.Y =  [KrigNewConMultiInfo{ii}.Y;cnext(ii)];
        KrigNewConMultiInfo{ii}.nsamp = length(KrigNewConMultiInfo{ii}.Y);
        KrigNewConMultiInfo{ii} =  train_Kriging(KrigNewConMultiInfo{ii});
    end
    
    % Check the minimum feasible solution
    for ii = 1:ncon % Loop over the number of constraint
        Galltemp(1, ii) = KrigNewConMultiInfo{ii}.Y(end); % Extract the constraint values at the new sampling point
        feasindtemp(1, ii) = (Galltemp(1,ii) <= limits(ii)); % Check feasibility, 0 for infeasible and 1 for feasible.
    end
    
    Gall(end+1,:) = Galltemp;
    feasind(end+1,:) = feasindtemp;
    
    if sum(feasind(end,:)) == ncon
        feas(end+1,1) = 1; % Feasible solution
    else
        feas(end+1,1) = 0;  % Infeasible solution
    end
  
    Yall(end+1,:) = ynext;
    Xall(end+1,:) = xnext;
    ifeas = find(feas==1); % Index of feasible solutions
    Yfeas = Yall(ifeas,:); % All feasible solutions
    Xfeas = Xall(ifeas,:);
    
    Ypar = paretopoint(Yall); % Recompute non-dominated solutions
    [Yparf, ifeasp] = paretopoint(Yfeas); % Recompute non-dominated solutions (feasible only)
    
    % For ParEGO, pre-process the solution
    if BayesMultiInfo.krignum == 1
        KrigScalarizedInfo.X = [KrigScalarizedInfo.X;xnext];
        KrigScalarizedInfo.Y = paregopre(Yall); % Normalized and scalarized objective functions
        KrigScalarizedInfo = train_Kriging(KrigScalarizedInfo); % Re-train the Kriging of the scalarized functions
    end
    
    % Compute simulation time
    simulation_time_end(nsamp+nup,1) = toc(simulation_time);
    total_simulation_time_end(nsamp+nup,1) = toc(total_simulation_time);
    
    nup = nup+1; % Update the number of iterations
    % Show the optimization progress.
    if BayesMultiInfo.display == 1
        disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewMultiInfo{1}.X,1)),', Maximum number of updates ',num2str(BayesMultiInfo.nup)]);
    end
    
    % Save the results
    Ybest = Yparf; % Find temporary non-dominated feasible values.
    Xbest = Xfeas(ifeasp,:); % Temporary non-dominated feasible solutions.
    save(BayesMultiInfo.filename,'Xbest','Ybest','KrigNewMultiInfo');
end

if BayesMultiInfo.krignum ==1 % Train individual Kriging models after ParEGO finish.
    if BayesMultiInfo.display == 1
        disp('ParEGO finished. Now retraining the Kriging models for each individual models .')
    end
    for jj = 1:length(KrigInfoBayesMulti)
        KrigNewMultiInfo{jj} = train_Kriging(KrigNewMultiInfo{jj});
    end
end

if BayesMultiInfo.display == 1
    disp('Optimization finished, now returning the final outputs.')
end

%% Write to solutions history
% Create outputhist
for ii = 1:length(KrigNewMultiInfo)
   outputhist.Y(:,ii) = KrigNewMultiInfo{ii}.Y ;
   outputhist.G(:,ii) = KrigNewConMultiInfo{jj}.Y;
end

outputhist.Ybest = Ybest;
outputhist.X = KrigNewMultiInfo{1}.X;
outputhist.simulation_time_end = simulation_time_end;
outputhist.total_simulation_time_end = total_simulation_time_end;
outputhist.feas = feas;

% Output the new updated BayesMultiInfo
BayesNewMultiInfo = BayesMultiInfo;