function [xnext, fnext] = run_multi_acquifun_opt(BayesMultiInfo, KrigNewMultiInfo, Ypar, KrigNewConInfo)
%
% Run the optimization of multi-objective acquisition function to find the next sampling point.
%
% Inputs:
%   BayesMultiInfo - A structure containing necessary information for Bayesian optimization.
%   KrigNewMultiInfo - A structure containing information of the constructed Kriging of the objective function.
%   KrigNewConInfo -A nested structure containing information of the constructed Kriging of the constraint function.
%
% Output:
%   xnext - Suggested next sampling point as discovered by the optimization of the acquisition function
%   fnext - Optimized acquisition function
%
% The available optimizers for the acquisition function are 'sampling+fmincon', 'sampling+cmaes', 'cmaes', 'fmincon'.
% Note that this function runs for both unconstrained and constrained single-objective Bayesian optimization.

acquifuncopt = BayesMultiInfo.acquifuncopt; % Acquisition function optimizer.
acquifunc    = BayesMultiInfo.acquifunc; % Type of acquisition function.

if nargin < 4 % For unconstrained optimization
    probtype = 1; % Unconstrained problem
else
    probtype = 2; % Constrained problem
    ncon = length(KrigNewConInfo); % Number of constraints
%      KrigNewMultiInfo
%     KrigNewMultiInfo.probtype = probtype; 
    feasfunc = BayesMultiInfo.feasfunc; % Type of feasibility function
end

switch acquifunc
    case 'EHVI'
        acqfunhandle = @(x)EHVIcomputation(x,Ypar,BayesMultiInfo,KrigNewMultiInfo);
end

switch  acquifuncopt
    case 'cmaes'
        intopts = cmaes;
        intopts.LBounds = KrigNewMultiInfo{1}.lb'; intopts.UBounds = KrigNewMultiInfo{1}.ub'; intopts.LogModulo = 0; intopts.SaveVariables = 0;  intopts.DispFinal = 'off'; intopts.DispModulo = inf;% Do not show CMA-ES output
        Xrand = variabletransf(rand(BayesMultiInfo.nrestart,KrigNewMultiInfo{1}.nvar),[KrigNewMultiInfo{1}.lb;KrigNewMultiInfo{1}.ub]'); % Create random sampling
        xnextcand = zeros(BayesMultiInfo.nrestart,KrigNewMultiInfo{1}.nvar); fnextcand = zeros(BayesMultiInfo.nrestart,1);
        for im = 1:BayesMultiInfo.nrestart
            if probtype == 1 % For unconstrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) feval(acqfunhandle,x'),Xrand(im,:),[],intopts);
            elseif probtype == 2 % For constrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) constrainedacqfunmulti(x',BayesMultiInfo,Ypar,KrigNewMultiInfo,KrigNewConInfo, acquifunc, feasfunc),Xrand(im,:),[],intopts);
            end
        end
        [~,I] = min(fnextcand); % Find the best acquisition function among the candidates.
        xnext = xnextcand(I,:); % Extract the solution with the best acquisition function.
        fnext = fnextcand(I); % Extract the best acquisition function value
        
    case 'fmincon'
        intopts.Display = 'off'; % Turn off the report
        Xrand = variabletransf(rand(BayesMultiInfo.nrestart,KrigNewMultiInfo.nvar),[KrigNewMultiInfo.lb;KrigNewMultiInfo.ub]'); % Create random sampling
          for im = 1:BayesMultiInfo.nrestart
            if probtype == 1 % For unconstrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) feval(acqfunhandle,x'),Xrand(im,:),[],intopts);
            elseif probtype == 2 % For constrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) constrainedacqfunmulti(x',BayesMultiInfo,Ypar,KrigNewMultiInfo,KrigNewConInfo, acquifunc, feasfunc),Xrand(im,:),[],intopts);
            end
        end
        
        [~,I] = min(fnextcand); % Find the best acquisition function among the candidates.
        xnext = xnextcand(I,:); % Extract the solution with the best acquisition function.
        fnext = fnextcand(I); % Extract the best acquisition function value
end