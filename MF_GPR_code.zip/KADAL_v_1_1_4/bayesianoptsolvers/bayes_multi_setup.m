%% Check the existence of necessary parameters
% For displaying Bayesian optimization setting and progress
if (isfield(BayesMultiInfo,'display') == 0)
    BayesMultiInfo.display = 1; % By default, the program shows the parameter settings
end

% Check consistensies of lower and upper bounds
for ii = 1:length(KrigInfoBayesMulti)
    % Check the lower bound
    if min(KrigInfoBayesMulti{1}.lb == KrigInfoBayesMulti{ii}.lb) == 0
        error('The lower bounds of the objective functions are not consistent. They should be the same for all objective functions.')
    end
    % Check the upper bound
    if min(KrigInfoBayesMulti{1}.ub == KrigInfoBayesMulti{ii}.ub) == 0
        error('The lower bounds of the objective functions are not consistent. They should be the same for all objective functions.')
    end
end


%% Set default values

% If BayesMultiInfo.acquifunc (the acquisition function) is not specified set to 'EHVI'
if (isfield(BayesMultiInfo,'acquifunc') == 0)
    BayesMultiInfo.acquifunc = 'EHVI';
    if BayesMultiInfo.display == 1; disp('The acquisition function is not specified, set to ''EHVI''.'); end
else
    availableacqfunc = {'EHVI','parego'};
    if max(strcmp(BayesMultiInfo.acquifunc ,availableacqfunc)) == 0
        error(['''',BayesMultiInfo.acquifunc , ''' is not a valid acquisition function.'])
    end
    if BayesMultiInfo.display == 1; disp(['The acquisition function is specified to ''', BayesMultiInfo.acquifunc ,''' by the user']); end
end

% Set necessary parameters for the multi-objective acquisition function.
if strcmp(BayesMultiInfo.acquifunc,'EHVI')
    BayesMultiInfo.krignum =  length(KrigInfoBayesMulti); % Multiple Kriging models
    if (isfield(BayesMultiInfo,'refpoint') == 0) % Reference point for hypervolume calculation, if not set, set a dynamic reference point
        BayesMultiInfo.refpointtype = 'dynamic';
    end
elseif strcmp(BayesMultiInfo.acquifunc,'parego')
    BayesMultiInfo.krignum = 1; % Single Kriging model
    if (isfield(BayesMultiInfo,'paregoacquifunc') == 0) % Set the optimizer for ParEGO (note that acquisition function here is in the context of optimizing ParEGO)
        BayesMultiInfo.paregoacquifunc = 'EI'; % By default, set to EI
    end
end

% If BayesMultiInfo.acquifuncopt (optimizer for the acquisition function) is not specified set to 'sampling+cmaes'
if (isfield(BayesMultiInfo,'acquifuncopt') == 0)
    BayesMultiInfo.acquifuncopt = 'sampling+cmaes';
    if BayesMultiInfo.display == 1; disp('The acquisition function optimizer is not specified, set to ''sampling+cmaes''.'); end
else
    availableacqoptimizer = {'sampling+cmaes','sampling+fmincon','cmaes','fmincon'};
    if max(strcmp(BayesMultiInfo.acquifuncopt,availableacqoptimizer)) == 0
        error(['''',BayesMultiInfo.acquifuncopt, ''' is not a valid acquisition function optimizer.'])
    end
    if BayesMultiInfo.display == 1; disp(['The acquisition function optimizer is specified to ''', BayesMultiInfo.acquifuncopt ,''' by the user']); end
end

% If BayesMultiInfo.nrestart (number of restart for internal optimization) is not specified, set BayesMultiInfo.nrestart to 1.
if (isfield(BayesMultiInfo,'nrestart') == 0)
    BayesMultiInfo.nrestart = 1;
    if BayesMultiInfo.display == 1; disp('The number of restart for acquisition function optimization is not specified, setting BayesMultiInfo.nrestart to 1 .'); end
    if BayesMultiInfo.nrestart < 1
        error('BayesMultiInfo.nrestart should be a positive value');
    end
else
    if BayesMultiInfo.display == 1; disp(['The number of restart for acquisition function optimization is specified by the user to ',num2str(BayesMultiInfo.nrestart)]); end
end

% If BayesMultiInfo.filename (file name for saving the results) is not specified, set BayesMultiInfo.filename to 'temporarydata.mat'.
if (isfield(BayesMultiInfo,'filename') == 0)
    BayesMultiInfo.filename = 'temporarydata';
    if BayesMultiInfo.display == 1; disp('The file name for saving the results is not specified, set the name to ''temporarydata.mat'''); end
else
    if BayesMultiInfo.display == 1; disp(['The file name for saving the results is specified by the user to ''',BayesMultiInfo.filename,''' by the user']); end
end

% If BayesMultiInfo.update is not specified, perform automatic update.
if (isfield(BayesMultiInfo,'autoupdate') == 0)
    BayesMultiInfo.autoupdate = 1;
    if BayesMultiInfo.display == 1; disp('The program will automatically update the solutions until the specified number of iterations'); end
else
    if BayesMultiInfo.display == 1; disp(['The user set automatic update to ',num2str(BayesMultiInfo.autoupdate)]); end
end

if BayesMultiInfo.autoupdate == 1
    if (isfield(BayesMultiInfo,'nup') == 0) % Check the existence of the number of updates
        error('Number of updates for multi-objective Bayesian optimization, BayesMultiInfo.nup, is not specified'); % Display error
    end
else
    BayesMultiInfo.nup = 1;
end

% Define the problem if automatic update is on
if BayesMultiInfo.autoupdate == 1
    if (isfield(BayesMultiInfo,'problem') == 0) % Check the existence of the function to be optimized.
        error('The function for the optimization is not defined, please set ''BayesMultiInfo.problem''')
    end
end

if exist('ncon') == 1 % If constraint exist, check the feasibility function
    % If BayesMultiInfo.feasfunc (the feasibility function) is not specified set to 'PoF'
    if (isfield(BayesMultiInfo,'feasfunc') == 0)
        BayesMultiInfo.feasfunc = 'PoF';
        if BayesMultiInfo.display == 1; disp('The feasibility function is not specified, set to ''PoF''.'); end
    else
        availablefeasfunc = {'PoF','SOCU'};
        if max(strcmp(BayesMultiInfo.feasfunc ,availablefeasfunc)) == 0
            error(['''',BayesMultiInfo.feasfunc , ''' is not a valid feasibility function.'])
        end
        if BayesMultiInfo.display == 1; disp(['The feasibility function is specified to ''', BayesMultiInfo.feasfunc ,''' by the user']); end
    end
end