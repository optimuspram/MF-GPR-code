function [xbest, ybest, outputhist, KrigNewInfo, KrigNewConInfo, BayesNewInfo] = singleobjbayesianoptcon(BayesInfo,KrigInfoBayes,KrigConInfoBayes)
%
% Perform constrained single-objective Bayesian optimization
%
% Inputs:
%   BayesInfo - The structure containing necessary information for Bayesian optimization.
%   KrigInfoBayes - The structure containing information of the constructed initial Kriging of the objective function.
%   KrigConInfoBayes - The nested structure containing information of the constructed initial Kriging of constraint functions
%
% Outputs:
%   xbest - The best feasible solution observed after optimization.
%   ybest - The best feasible response after optimization.
%   outputhist - history of the optimization process
%   KrigNewInfo - A structure containing information of final Kriging after optimization.
%   KrigConNewInfo - A nested structure containing information of final Kriging models of constraints after optimization.
%   BayesNewInfo - New updated info of Bayesian optimization

nsamp = KrigInfoBayes.nsamp; % Number of samples.
ncon  = length(KrigConInfoBayes); % Number of constraints

%% Setting up Bayesian optimization formulation
bayes_single_setup

%% Run Bayesian optimization
nup = 1;
KrigNewInfo    = KrigInfoBayes; % Initialize Kriging model of the objective.
KrigNewConInfo = KrigConInfoBayes; % Initialize Kriging models of the constraint functions

% Check the minimum feasible solution;
feasind = zeros(nsamp,ncon); % initialize feasibility index
Gall = zeros(nsamp,ncon); % Inequality constraint
for ii = 1:ncon % Loop over the number of constraint
    limits(ii,1) = KrigNewConInfo{ii}.limit; % Extract the limit of constraint.
    Gall(:,ii) = KrigNewConInfo{ii}.Y; % Extract the constraint values at sampling points
    feasind(:,ii) = (Gall(:,ii) <= limits(ii)); % Check feasibility, 0 for infeasible and 1 for feasible.
end

feas = zeros(nsamp,1); % Check the feasibility according to all constraints
for jj = 1:nsamp
    if sum(feasind(jj,:)) == ncon
        feas(jj,1) = 1; % Feasible solution is assigned a value of one
    end
end

ybesthist(1,1) = min(KrigNewInfo.Y(feas==1)); % Extract the best feasible solution observed
ybest = ybesthist;

istall = 0; % Counter for stall iteration.
if BayesInfo.display == 1
    disp('Begin constrained Bayesian optimization process.')
    disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewInfo.X,1)),', Best f(x): ',num2str(ybesthist(nup)),', Stall counter: ',num2str(istall)]);
end

% Bayesian optimization main loop
total_simulation_time = tic;
while nup <= BayesInfo.nup
    simulation_time = tic;
    % Perform one iteration of single-objective Bayesian optimization
     KrigNewInfo.ybest = ybest; % Save best feasible solution
     
    [xnext] = run_acquifun_opt(BayesInfo, KrigNewInfo, KrigNewConInfo); % Find the next sample to evaluate
    
    % If automatic update is not set, directly output xnext instead of xbest
    if BayesInfo.autoupdate == 0
        xbest = xnext;
        return
    end
    % Evaluate the new sample
    [ynext, cnext] = feval(BayesInfo.problem,xnext);
    
    % Enrich the experimental design
    KrigNewInfo.X = [KrigNewInfo.X;xnext];
    KrigNewInfo.Y = [KrigNewInfo.Y;ynext];
    for ii = 1:ncon
        KrigNewConInfo{ii}.X =  [KrigNewConInfo{ii}.X;xnext];
        KrigNewConInfo{ii}.Y =  [KrigNewConInfo{ii}.Y;cnext(ii)];
    end
    
    % Re-create Kriging model of the objective
    KrigNewInfo = train_Kriging(KrigNewInfo);
    
    % Re-create Kriging model of the constraints
    for ii = 1:ncon
        KrigNewConInfo{ii} =  train_Kriging(KrigNewConInfo{ii});
    end
    
    % Compute simulation time
    simulation_time_end(nsamp+nup,1) = toc(simulation_time);
    total_simulation_time_end(nsamp+nup,1) = toc(total_simulation_time);
    
    nup = nup+1; % Update the number of iteration
     
    % Check the minimum feasible solution
    for ii = 1:ncon % Loop over the number of constraint
        Galltemp(1, ii) = KrigNewConInfo{ii}.Y(end); % Extract the constraint values at the new sampling point
        feasindtemp(1, ii) = (Galltemp(1,ii) <= limits(ii)); % Check feasibility, 0 for infeasible and 1 for feasible.
    end
    Gall(end+1,:) = Galltemp;
    feasind(end+1,:) = feasindtemp;

    if sum(feasind(end,:)) == ncon
        feas(end+1,1) = 1; % Feasible solution
    else
        feas(end+1,1) = 0;  % Infeasible solution
    end

    ybesthist(nup,1) = min(KrigNewInfo.Y(feas==1)); % Extract the best feasible solution
    
    % Check the stall iteration
    if ybesthist(nup) == ybesthist(nup-1)
        istall = istall + 1;
        if istall == BayesInfo.stalliteration
            break % Break from the while loop
        end
    else
        istall = 0; % Restart the counter of stall iteration
    end

    % Show the optimization progress.
    if BayesInfo.display == 1
        if feas(end) == 1; feasstat = 'feasible'; else; feasstat = 'infeasible'; end % Feasibility status of the new solution
        disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewInfo.X,1)),', f(x): ',num2str(ynext),', ',feasstat,', Best f(x): ',num2str(ybesthist(nup)),', Stall counter: ',num2str(istall)]);
    end
    
    % Save the results
    Xfeas = KrigNewInfo.X(feas==1,:); % All feasible solution
    Yfeas = KrigNewInfo.Y(feas==1,:); % All feasible responses
    [ybest,I] = min(Yfeas); % Best value
    xbest = Xfeas(I,:); % Best sampling point
    save(BayesInfo.filename,'xbest','ybest','KrigNewInfo','KrigNewConInfo');
    
   
end

if BayesInfo.display == 1
    disp('Optimization finished, now creating the final outputs.')
end

%% Write to solutions history
Xfeas = KrigNewInfo.X(feas==1,:); % All feasible solution
Yfeas = KrigNewInfo.Y(feas==1,:); % All feasible responses
[ybest,I] = min(Yfeas); % Best value
xbest = Xfeas(I,:); % Best observed point

% Create outputhist
outputhist.Y = [KrigNewInfo.Y];
for ii = 1:ncon
    outputhist.G(:,ii) = [KrigNewConInfo{ii}.Y];
end
outputhist.ybesthist = [repmat(ybesthist(1),nsamp-1,1) ; ybesthist];
outputhist.X = KrigNewInfo.X;
outputhist.simulation_time_end = simulation_time_end;
outputhist.total_simulation_time_end = total_simulation_time_end;
outputhist.feas = feas;

% Output the new updated BayesInfo
BayesNewInfo = BayesInfo;
