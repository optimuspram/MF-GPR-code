function [xnext, fnext] = run_acquifun_opt(BayesInfo, KrigNewInfo, KrigNewConInfo)
%
% Run the optimization of single-objective acquisition function to find the next sampling point.
%
% Inputs:
%   BayesInfo - A structure containing necessary information for Bayesian optimization.
%   KrigNewInfo - A structure containing information of the constructed Kriging of the objective function.
%   KrigNewConInfo -A nested structure containing information of the constructed Kriging of the constraint function.
%
% Output:
%   xnext - Suggested next sampling point as discovered by the optimization of the acquisition function
%   fnext - Optimized acquisition function
%
% The available optimizers for the acquisition function are 'sampling+fmincon', 'sampling+cmaes', 'cmaes', 'fmincon'.
% Note that this function runs for both unconstrained and constrained single-objective Bayesian optimization.

acquifuncopt = BayesInfo.acquifuncopt; % Acquisition function optimizer.
acquifunc    = BayesInfo.acquifunc; % Type of acquisition function.

if strcmp(acquifunc,'LCB')
    KrigNewInfo.sigmalcb = BayesInfo.sigmalcb; % Sigma for LCB acquisition function (only for LCB).
end

if nargin < 3 % For unconstrained optimization
    probtype = 1; % Unconstrained problem
    KrigNewInfo.probtype = probtype; 
else % For constrained optimization
    probtype = 2; % Constrained problem
    ncon = length(KrigNewConInfo); % Number of constraints
    KrigNewInfo.probtype = probtype; 
    feasfunc = BayesInfo.feasfunc; % Type of feasibility function
end

% For ParEGO based multi-objective optimization, set the acquisition function to BayesInfo.paregoacquifunc
if (isfield(BayesInfo,'paregoacquifunc') == 1)
    acquifunc = BayesInfo.paregoacquifunc;
end


switch  acquifuncopt
    case 'sampling+fmincon' % Note that fmincon is available only with Global Optimization toolbox
        nmcs = 2e5; % Random sampling 
        Xrand = variabletransf(rand(nmcs,KrigNewInfo.nvar),[KrigNewInfo.lb;KrigNewInfo.ub]'); % Create random sampling
        acquifuncval = krigprediction(Xrand,KrigNewInfo,acquifunc); % Evaluate the acquisition function
        intopts.Display = 'off'; % Turn off the report
        if probtype == 1 % For unconstrained acquisition function
            [~,I] = min(acquifuncval); % Find the minimum of acquisition function from the sampling
            [xnext, fnext] = fmincon(@(x) krigprediction(x,KrigNewInfo,acquifunc),Xrand(I,:),[],[],[],[],KrigNewInfo.lb,KrigNewInfo.ub,[],intopts); % Fine tune the acquistion function
        elseif probtype == 2 % For constrained acquisition function
            % Compute the probability of feasibility for each constraint
            for jj = 1:ncon
                PoF(:,jj) = krigprediction(Xrand,KrigNewConInfo{jj},feasfunc); % Compute probability of feasibility
            end
            conacquifuncval = acquifuncval.*prod(PoF,2);  % Compute acquisition function with constraint.
            [C,I] = min(conacquifuncval); % Extract the index of the best solution from sampling
            I = I(1); % If there is more than one solution
            [xnext, fnext] = fmincon(@(x) constrainedacqfun(x,KrigNewInfo,KrigNewConInfo,acquifunc,feasfunc),Xrand(I,:),[],[],[],[],KrigNewInfo.lb,KrigNewInfo.ub,[],intopts); % Fine tune the  acquisition function with constraint.
        end  
    case 'sampling+cmaes'
        nmcs = 2e5; % Random sampling using Monte Carlo sampling
        Xrand = variabletransf(rand(nmcs,KrigNewInfo.nvar),[KrigNewInfo.lb;KrigNewInfo.ub]'); % Create random sampling
        acquifuncval = krigprediction(Xrand,KrigNewInfo,acquifunc); % Evaluate the acquisition function
        intopts = cmaes;
        intopts.LBounds = KrigNewInfo.lb'; intopts.UBounds = KrigNewInfo.ub'; intopts.LogModulo = 0; intopts.SaveVariables = 0;  intopts.DispFinal = 'off'; intopts.DispModulo = inf;% Do not show CMA-ES output
        if probtype == 1 % For unconstrained acquisition function
            [~,I] = min(acquifuncval); % Find the minimum of acquisition function from the sampling
            [xnext, fnext]=cmaes(@(x) krigprediction(x',KrigNewInfo,acquifunc),Xrand(I,:),[],intopts); xnext = xnext';
        elseif probtype == 2 % For constrained acquisition function
            % Compute the probability of feasibility for each constraint
            for jj = 1:ncon
                PoF(:,jj) = krigprediction(Xrand,KrigNewConInfo{jj},feasfunc); % Compute probability of feasibility
            end 
            conacquifuncval = acquifuncval.*prod(PoF,2); % Compute acquisition function with constraint.
            [C,I] = min(conacquifuncval); % Extract the index of the best solution from sampling
            I = I(1); % If there is more than one solution
           
            [xnext, fnext] = cmaes(@(x) constrainedacqfun(x',KrigNewInfo,KrigNewConInfo,acquifunc,feasfunc),Xrand(I,:),[],intopts); xnext = xnext';     
        end
    case 'cmaes'
        intopts = cmaes;
        intopts.LBounds = KrigNewInfo.lb'; intopts.UBounds = KrigNewInfo.ub'; intopts.LogModulo = 0; intopts.SaveVariables = 0;  intopts.DispFinal = 'off'; intopts.DispModulo = inf;% Do not show CMA-ES output
        Xrand = variabletransf(rand(BayesInfo.nrestart,KrigNewInfo.nvar),[KrigNewInfo.lb;KrigNewInfo.ub]'); % Create random sampling
        xnextcand = zeros(BayesInfo.nrestart,KrigNewInfo.nvar); fnextcand = zeros(BayesInfo.nrestart,1);
        for im = 1:BayesInfo.nrestart
            if probtype == 1 % For unconstrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) krigprediction(x',KrigNewInfo,acquifunc),Xrand(im,:),[],intopts);
            elseif probtype == 2 % For constrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=cmaes(@(x) constrainedacqfun(x',KrigNewInfo,KrigNewConInfo,acquifunc,feasfunc),Xrand(im,:),[],intopts);
            end
        end
        [~,I] = min(fnextcand); % Find the best acquisition function among the candidates.
        xnext = xnextcand(I,:); % Extract the solution with the best acquisition function.
        fnext = fnextcand(I); % Extract the best acquisition function value
        
    case 'fmincon'
        intopts.Display = 'off'; % Turn off the report
        Xrand = variabletransf(rand(BayesInfo.nrestart,KrigNewInfo.nvar),[KrigNewInfo.lb;KrigNewInfo.ub]'); % Create random sampling
        for im = 1:BayesInfo.nrestart
            if probtype == 1 % For unconstrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=fmincon(@(x) krigprediction(x,KrigNewInfo,acquifunc),Xrand(im,:),[],[],[],[],KrigNewInfo.lb,KrigNewInfo.ub,[],intopts); % Fine tune the acquistion function
            elseif probtype == 2 % For constrained acquisition function
                [xnextcand(im,:) fnextcand(im)]=fmincon(@(x) constrainedacqfun(x,KrigNewInfo,KrigNewConInfo,acquifunc,feasfunc),Xrand(im,:),[],[],[],[],KrigNewInfo.lb,KrigNewInfo.ub,[],intopts); % Fine tune the acquistion function
            end
        end
        
        [~,I] = min(fnextcand); % Find the best acquisition function among the candidates.
        xnext = xnextcand(I,:); % Extract the solution with the best acquisition function.
        fnext = fnextcand(I); % Extract the best acquisition function value
end