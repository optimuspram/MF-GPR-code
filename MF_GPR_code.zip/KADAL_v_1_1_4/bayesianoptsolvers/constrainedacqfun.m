function  conacquifuncval=constrainedacqfun(XP,KrigNewInfo,KrigNewConInfo, acquifunc, feasfunc)

% Calculate unconstrained acquisition function
acquifuncval=krigprediction(XP,KrigNewInfo,acquifunc);

% Calculate probability of feasibility for each constraint
ncon =length(KrigNewConInfo);
PoF  = zeros(1,ncon);

for ii=1:ncon
    PoF(1,ii)=krigprediction(XP,KrigNewConInfo{ii},feasfunc);
end

% Calculate acquisition function with constraint
conacquifuncval = acquifuncval*prod(PoF,2);
