function [xbest, ybest, outputhist, KrigNewInfo, BayesNewInfo] = singleobjbayesianoptunc(BayesInfo,KrigInfoBayes)
%
% Perform unconstrained single-objective Bayesian optimization
%
% Inputs:
%   BayesInfo - Structure containing necessary information for Bayesian optimization.
%   KrigInfoBayes - Structure containing information of the constructed initial Kriging of the objective function.
%
% Outputs:
%   xbest - Best solution observed after optimization.
%   ybest - Best response after optimization.
%   outputhist - history of the optimization process
%   KrigNewInfo - Structure containing information of final Kriging after optimization.
%   BayesNewInfo - New updated info of Bayesian optimization

nsamp = KrigInfoBayes.nsamp; % Number of samples.

% Setting up
bayes_single_setup

%% Run Bayesian optimization
nup = 1;
KrigNewInfo = KrigInfoBayes; % Initialize Kriging model
ybesthist(1,1) = min(KrigNewInfo.Y);
istall = 0; % Counter for stall iteration.
if BayesInfo.display == 1
    disp('Begin Bayesian optimization process.')
    disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewInfo.X,1)),', Best f(x): ',num2str(ybesthist(nup)),', Stall counter: ',num2str(istall)]);
end

total_simulation_time = tic;
while nup <= BayesInfo.nup
    simulation_time = tic;
    
    % Perform one iteration of single-objective Bayesian optimization
    xnext = run_acquifun_opt(BayesInfo, KrigNewInfo); % Find the next sample to evaluate
    
    % If automatic update is not set, directly output xnext instead of xbest
    if BayesInfo.autoupdate == 0
        xbest = xnext;
        return
    end
    % Evaluate the new sample
    ynext = feval(BayesInfo.problem,xnext);
    
    % Enrich the experimental design
    KrigNewInfo.X = [KrigNewInfo.X;xnext];
    KrigNewInfo.Y = [KrigNewInfo.Y;ynext];
    % Re-create Kriging model
    KrigNewInfo = train_Kriging(KrigNewInfo);
    
    % Compute simulation time
    simulation_time_end(nsamp+nup,1) = toc(simulation_time);
    total_simulation_time_end(nsamp+nup,1) = toc(total_simulation_time);
    
    nup = nup+1;
    ybesthist(nup,1) = min(KrigNewInfo.Y);
    
    % Check the stall iteration
    if ybesthist(nup) == ybesthist(nup-1)
        istall = istall + 1;
        if istall == BayesInfo.stalliteration
            break % Break from the while loop
        end
    else
        istall = 0; % Restart the counter of stall iteration
    end
    
    
    % Show the optimization progress.
    if BayesInfo.display == 1
        disp(['Iteration: ',num2str(nup-1),', F-count: ',num2str(size(KrigNewInfo.X,1)),', f(x): ',num2str(ynext),', Best f(x): ',num2str(ybesthist(nup)),', Stall counter: ',num2str(istall)]);
    end
    
    % Save the results
    [~,I] = min(KrigNewInfo.Y);
    xbest = KrigNewInfo.X(I,:); % Best sampling point
    ybest = KrigNewInfo.Y(I,:); % Best value
    save(BayesInfo.filename,'xbest','ybest','KrigNewInfo');
end

if BayesInfo.display == 1
    disp('Optimization finished, now creating the final outputs.')
end

%% Set the outputs
[~,I] = min(KrigNewInfo.Y);
xbest = KrigNewInfo.X(I,:); % Best sampling point
ybest = KrigNewInfo.Y(I,:); % Best value

% Create outputhist
outputhist.Y = [KrigNewInfo.Y];
outputhist.ybesthist = [repmat(ybesthist(1),nsamp-1,1) ; ybesthist];
outputhist.X = KrigNewInfo.X
outputhist.simulation_time_end = simulation_time_end;
outputhist.total_simulation_time_end = total_simulation_time_end;

% Output the new updated BayesInfo
BayesNewInfo = BayesInfo;

