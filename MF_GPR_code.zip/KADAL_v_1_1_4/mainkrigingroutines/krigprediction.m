function [output, SSqr, y_hat, trend]= krigprediction(XP, KrigInfo, predictiontype)
% Calculates the requested output, SSqr, Kriging prediction, and trend function
%
% Information: This function is a modification from "Forrester, A., Sobetaster, A., & Keane, A. (2008). Engineering design via surrogate modelling:  a practical guide. John Wiley & Sons."
%
% Inputs:
%   XP - Prediction site 
%   KrigInfo - A structure containing necessary information of a constructed Kriging model
%   predictiontype - The output as defined by the user
%       'pred' - for Kriging prediction.
%       'SSqr' - for Kriging prediction error.
%       'trend' - for computed trend function.
%       'EI' - for expected improvement.
%
% Information used in KrigInfo for krigprediction
%	KrigInfo.Xnorm - (nsamp x nvar) matrix of normalized experimental design.
%	KrigInfo.Ynorm - (nsamp x 1) vector of normalized responses.
%   KrigInfo.F - (nsamp x nind) matrix of regression function.
%   KrigInfo.TrendFunction - trend function.
%   KrigInfo.kernel - Type of kernel function.
%   KrigInfo.wgkf - (1 x nkrnl) vector of weights for kernel functions.
%   KrigInfo.U - Choleski factorisation of correlation matrix.
%   KrigInfo.xparam - Hyperparameters of the Kriging model.
%   KrigInfo.beta - Coefficients of regression function
%   KrigInfo.SigmaSqr - SigmaSqr (Kriging variance) of the Kriging model
%
% Outputs:
%   output - The output as defined by the user (see 'predictiontype').
%   SSqr - Kriging prediction error at the prediction site.
%   y_hat - Kriging prediction.
%   trend - Kriging trend function.
%
% Information:
%  - Note that the output can beta vectorized.
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)
%  modified by Lucia Parussini (lparussini@units.it)
%
%%
if (isfield(KrigInfo,'Xnorm') == 0)
   error('This Kriging model is not yet trained and cannot beta used for prediction.'); 
end
Xnorm = KrigInfo.Xnorm; % Experimental design, normalized
Y = KrigInfo.Ynorm; % Responses of experimental design, normalized 
XPnorm = doNormalize(XP,KrigInfo.meanX,KrigInfo.stdX);
nvar = KrigInfo.nvar; % Number of variables.
nsamp = KrigInfo.nsamp; % Number of samples.
npred = size(XPnorm,1); % Number of prediction sites.

F = KrigInfo.F;  % Matrix of regression function
kernel = KrigInfo.kernel; % Type of Kernel function
wgkf   = KrigInfo.wgkf; % Weight for Kernel function

U = KrigInfo.U; % Choleski factorisation of correlation matrix
theta = KrigInfo.lengthscale.value(1:nvar); % Lengthscales
beta = KrigInfo.beta.value; % Coefficients of regression functions
SigmaSqr = KrigInfo.kernvar.value; % Sigma squared of Kriging

% Build single/composite correlation function for prediction
psiComp = zeros(nsamp,npred,nvar);
for ii = 1:length(kernel)
    % Call the function to construct Psi matrix
    psiComp(:,:,ii) = wgkf(ii)*callkernel(Xnorm,XPnorm,theta,kernel{ii},nvar);
end
% Construct the correlation vector for prediction
psi = sum(psiComp,3);

if KrigInfo.noisefree ==0
    psi = SigmaSqr * psi;
end

% Construct regression matrix for prediction
for i=1:npred
    f(i,:) = KrigInfo.TrendFunction(XPnorm(i,:));
end

% Compute prediction
trend = f*beta; % Compute the Kriging trend function prediction.
y_hat = trend + psi'*(U\(U'\(Y-F*beta))); % Compute Kriging prediction

% Compute sigma-squared error
if KrigInfo.noisefree ==1
    term1 = (1-sum(psi'.*(U\(U'\psi))',2));
    ux = (F'*(U\(U'\psi)))-f';
    term2 =  sum((ux.*((F'*(U\(U'\F)))\ux))',2);
    SSqr = SigmaSqr*(term1+term2); % Compute Kriging prediction error at the prediction site
end
if KrigInfo.noisefree ==0
    term1 = (SigmaSqr-sum(psi'.*(U\(U'\psi))',2));
    ux = (F'*(U\(U'\psi)))-f';
    term2 =  sum((ux.*((F'*(U\(U'\F)))\ux))',2);
    SSqr = term1+term2; % Compute Kriging prediction error at the prediction site
end

trend = undoNormalize(trend,KrigInfo.meanY,KrigInfo.stdY);
y_hat = undoNormalize(y_hat,KrigInfo.meanY,KrigInfo.stdY);
SSqr = undoNormalize(SSqr,0.*KrigInfo.meanY,KrigInfo.stdY.^2);

%% Prediction
switch predictiontype
    case 'pred' % Kriging prediction (this can also be used as acquisition function)
        output = y_hat;
    case 'SSqr' % Kriging sigma-squared error
        output = SSqr;
    case 'trend' % Trend function
        output = trend;
    % below are the available acquisition functions
    case 'EI' % Expected improvement acquisition function
        % Compute the EI (note that we use normalized X for the computation of EI)
        if isfield(KrigInfo,'probtype')==0 KrigInfo.probtype = 1; end 
        if KrigInfo.probtype == 1 % Unconstrained
            y_min = min(KrigInfo.Y); % Minimum of the experimental design
        elseif KrigInfo.probtype == 2 % Constrained
            y_min = KrigInfo.ybest; % Use the minimum feasible solution
        end
        erfun = erf((1/sqrt(2))*((y_min-y_hat)./sqrt(abs(SSqr))));
        if SSqr == 0
            ExpImp = 0;
        else
            ei_termone =(y_min-y_hat).*(0.5+0.5.*erfun);
            ei_termtwo = sqrt(abs(SSqr)).*(1./sqrt(2*pi)).*exp(-(1/2).*((y_min-y_hat).^2./(SSqr)));
            ExpImp = (ei_termone + ei_termtwo + realmin);
        end
        output = -ExpImp; % Compute the minus of expected improvement
    case 'LCB' % Lower confidence bound acquisition function
        output = y_hat-KrigInfo.sigmalcb*sqrt(SSqr);
    case 'PoI' % Probability of improvement
        ProbImp = 0.5+0.5.*erf((1./sqrt(2)).*((min(Y)-y_hat)./sqrt(abs(SSqr))));
        output = -ProbImp; % Compute the minus of expected improvement
    case 'Ebeta' % Error based exploration, note that this acquisition function is typically used for surrogate model refinement
        output = -SSqr;
    case 'WB2' % Watson and Barnes 2, prediction + EI
        pred = y_hat; % Calculate prediction
        % Compute the EI 
        if KrigInfo.probtype == 1 % Unconstrained
            y_min = min(KrigInfo.Y); % Minimum of the experimental design
        elseif KrigInfo.probtype == 2 % Constrained
            y_min = KrigInfo.ybest; % Use the minimum feasible solution
        end
        erfun = erf((1/sqrt(2))*((y_min-y_hat)./sqrt(abs(SSqr))));
        if SSqr == 0
            ExpImp = 0;
        else
            ei_termone =(y_min-y_hat).*(0.5+0.5.*erfun);
            ei_termtwo = sqrt(abs(SSqr)).*(1./sqrt(2*pi)).*exp(-(1/2).*((y_min-y_hat).^2./(SSqr)));
            ExpImp = (ei_termone + ei_termtwo + realmin);
        end
        output = -(-pred + ExpImp);
    case 'PoF' % Probability of feasibility
        ProbFeas = 0.5+0.5.*erf((1./sqrt(2)).*((KrigInfo.limit-(y_hat))./sqrt(abs(SSqr))));
        output = ProbFeas;
    case 'SOCU' % Modified probability of feasibility
        ProbFeas = 0.5+0.5.*erf((1./sqrt(2)).*((KrigInfo.limit-(y_hat))./sqrt(abs(SSqr))));
        output = min([ProbFeas*2, ones(size(ProbFeas))],[],2); 
end

