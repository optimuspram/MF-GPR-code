function [NegLnLike, Psi, U, beta, SigmaSqr, F, wgkf, noisevar, theta]=likelihood_fun_computation(hyperparam,KrigInfo)
%
% Calculates the negative of the concentrated ln-likelihood
%
% Information: This function is a modification from "Forrester, A., Sobetaster, A., & Keane, A. (2008). Engineering design via surrogate modelling:  a practical guide. John Wiley & Sons."

% Inputs:
%	hyperparam - Matrix of hyperparameters, consisting of log10 of [theta, regfac], where theta and regfac are lengthscales and regression factor,
%	respectively.
%   options.kernel - Type(s) of kernel function
%   options.wgkf - Weight of kernel functions

% Global variables used:
%	KrigInfo.Xnorm - nsamp x k matrix of sample locations
%	KrigInfo.Y - nsamp x 1 vector of observed data
%   KrigInfo.F - Matrix of regression function
%
% Outputs:
%	NegLnLike - concentrated log-likelihood *-1 for minimising
%	Psi - correlation matrix
%	U - Choleski factorisation of correlation matrix
%   beta - Coefficients of regression functions
%   SigmaSqr - Sigma squared of Kriging
%   F - Matrix of regression function
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)
%  modified by: Lucia Parussini (lparussini@units.it)
%
%%

Xnorm = KrigInfo.Xnorm; % Experimental design (normalized)
Ynorm = KrigInfo.Ynorm; % Outputs of experimental design
F = KrigInfo.F; % Matrix of regression function
kernel = KrigInfo.kernel; % Type of Kernel function
nkrnl = KrigInfo.nkrnl;
nsamp= KrigInfo.nsamp; % Sample size
nvar = KrigInfo.nvar; % Number of variables
nTrendCoeff = KrigInfo.nTrendCoeff; % Number of beta coefficients of trend function
if isfield(KrigInfo,'nRegrCoeff') == 1
    nRegrCoeff = KrigInfo.nRegrCoeff; % Number of beta coefficients of regression function
else
    nRegrCoeff = 0;
end

n = 0;
if isfield(KrigInfo,'lengthscale') == 1 && isfield(KrigInfo.lengthscale,'tuned') == 1
    if KrigInfo.lengthscale.tuned == 1
        theta = 10.^hyperparam(n+1:n+nvar);
        n = n + nvar;
    else
        theta = KrigInfo.lengthscale.value;
    end
end
if isfield(KrigInfo,'kernvar') == 1 && isfield(KrigInfo.kernvar,'tuned') == 1
    if KrigInfo.kernvar.tuned == 1
        SigmaSqr = 10.^hyperparam(n+1);
        n = n + 1;
    else
        SigmaSqr = KrigInfo.kernvar.value;
    end
end
if  KrigInfo.noisevar.tuned == 1
    noisevar = 10.^hyperparam(n+1);
    n = n+1;
else
    noisevar = KrigInfo.noisevar.value;
end
if isfield(KrigInfo,'beta') == 1 && isfield(KrigInfo.beta,'tuned') == 1
    if KrigInfo.beta.tuned == 1
        beta = 10.^hyperparam(n+1:n+nRegrCoeff+nTrendCoeff);
        n = n + nRegrCoeff+nTrendCoeff;
    else
        beta = KrigInfo.beta.value;
    end
    beta = beta';
end
if KrigInfo.nkrnl > 1
    wgkf = (hyperparam(n+1:n+nkrnl))/sum(hyperparam(n+1:n+nkrnl));
    n = n + nkrnl;
else
    wgkf = 1;
end

% Build single/composite covariance function
PsiComp = zeros(nsamp,nsamp,nvar);

for ii = 1:nkrnl
    % Call the function to construct Psi matrix
    PsiComp(:,:,ii) = wgkf(ii)*callkernel(Xnorm,Xnorm,theta,kernel{ii},nvar);
end

% Construct the covariance function
Psi = sum(PsiComp,3);

if  isfield(KrigInfo,'nested') == 0 || (isfield(KrigInfo,'nested') == 1 && KrigInfo.nested == 1) % KRIGING OR NESTED LEVEL
    
    if KrigInfo.noisefree == 1 % FREE NOISE
        % Add White Noise to improve matrix conditioning
        Psi = Psi + eye(nsamp).*noisevar;
        
        % % Add autoregressive parte for not nested designs
        % if KrigInfo.nested==0
        %     Psi=Psi+ARPsi;
        % end
        
        % Cholesky factorisation
        [U,p]=chol(Psi);
        
        % Use penalty if ill-conditioned
        if p>0 %| sum(Psi,'All') < nsamp + 1e-3 | sum(Psi,'All') > nsamp^2 - 6
            NegLnLike=1e4;
        else

            % Compute the coefficients of regression function
           if isfield(KrigInfo,'beta') == 0 || (isfield(KrigInfo,'beta') == 1 && isfield(KrigInfo.beta,'userdefined_value') == 0)
               beta  = (F'*(U\(U'\F)))\(F'*(U\(U'\Ynorm)));
           end
           
           % Compute kernel variance
           if isfield(KrigInfo,'kernvar') == 0 || (isfield(KrigInfo,'kernvar') == 1 && isfield(KrigInfo.kernvar,'userdefined_value') == 0)
               SigmaSqr=((Ynorm-F*beta)'*(U\(U'\(Ynorm-F*beta))))/nsamp;
           end
            
            % Compute negative log likelihood
            NegLnLike= 0.5*nsamp*log(SigmaSqr) + sum(log(abs(diag(U)))) + 0.5*nsamp*log(2*pi);            
        end
    else % NOISY
        
        Psi = SigmaSqr * Psi + eye(nsamp).*noisevar;

        % Cholesky factorisation
        [U,p]=chol(Psi);
        
        % Use penalty if ill-conditioned
        if p>0 %| sum(Psi,'All') < nsamp + 1e-3 | sum(Psi,'All') > nsamp^2 - 6
            NegLnLike=1e4;
        else
            % Compute the coefficients of regression function
           if isfield(KrigInfo,'beta') == 0 || (isfield(KrigInfo,'beta') == 1 && isfield(KrigInfo.beta,'userdefined_value') == 0)
                beta  = (F'*(U\(U'\F)))\(F'*(U\(U'\Ynorm)));
            end
            % Compute negative log likelihood            
            NegLnLike= ((Ynorm-F*beta)'*(U\(U'\(Ynorm-F*beta)))) + 2*sum(log(abs(diag(U))));
        end
        
    end
    
else % NOT NESTED LEVEL
    ARPsi = (F(1:nsamp,1:nRegrCoeff)*beta(1:nRegrCoeff,1)).*KrigInfo.S2prednorm;
    ARPsi = ARPsi*ARPsi';
    
    if KrigInfo.noisefree == 1 % FREE NOISE
        % Add White Noise to improve matrix conditioning
        Psi = Psi + eye(nsamp).*noisevar;
    else % NOISY
        Psi = SigmaSqr * Psi + eye(nsamp).*noisevar;
    end
    
    % Add autoregressive part for not nested designs
    Psi=Psi+ARPsi;
    
    % Cholesky factorisation
    [U,p]=chol(Psi);
 
    % Use penalty if ill-conditioned
    if p>0 %| sum(Psi,'All') < nsamp + 1e-3 | sum(Psi,'All') > nsamp^2 - 6
        NegLnLike=1e4;
    else
        % Compute negative log likelihood       
        NegLnLike= ((Ynorm-F*beta)'*(U\(U'\(Ynorm-F*beta)))) + 2*sum(log(abs(diag(U))));
    end
    
end

% if isnan(NegLnLike)
%     NegLnLike=1e4;
% end
