function [LOOCVerror, LOOCVpred, LOOCVSSqr, LOOCVMSLL] = krigloocv(KrigInfo,LOOCVtype);
%
% Compute leave-one-out cross validation (LOOCV) error
%
% Reference: "Dubrule, O. (1983). Cross validation of kriging in a unique neighborhood.
% Journal of the International Association for Mathematical Geology, 15(6), 687-699."
%
% Input :
%      Krig Info
%
% Outputs:
%      LOOCVerror - LOOCV error
%      LOOCVpred    - LOOCV prediction at sampling points.
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)
%
%%

% Take necessary information from KrigInfo
F = KrigInfo.F;
Psi = KrigInfo.Psi;
SigmaSqr= KrigInfo.kernvar.value;
nsamp = KrigInfo.nsamp;
Y = KrigInfo.Ynorm;
noisevar = KrigInfo.noisevar.value;

% Create B matrix
sl = size([SigmaSqr*Psi F],2)-size(F',2);
if KrigInfo.noisefree == 1
    B = inv([SigmaSqr*Psi F;F' zeros(size(F',1),size(F,2))]);
else
    B = inv([Psi F;F' zeros(size(F',1),size(F,2))]);
end
LOOCVpred = zeros(1,nsamp); % Initialize LOOCVpred
for i = 1:nsamp
    LOOCVpred(i) = 0;
    for j = 1:nsamp
        LOOCVpred(i) = LOOCVpred(i) + (B(i,j)/B(i,i))*Y(j);
    end
    LOOCVpred(i) = -LOOCVpred(i) + Y(i);
end

diagB = diag(B);
LOOCVSSqr = 1./diagB(1:nsamp); % LOOCV SigmaSqr at sampling points
LOOCVpred = LOOCVpred'; % LOOCV prediction at sampling points
LOOCVerror = errperf(Y,LOOCVpred,LOOCVtype); % Compute LOOCV error

if KrigInfo.noisefree == 1
    LOOCVMSLL = mean(0.5.*log(2*pi*(noisevar+LOOCVSSqr))+((Y-LOOCVpred).^2./(2*(noisevar+LOOCVSSqr))));% Compute mean-standardized log loss
else
    LOOCVMSLL = mean(0.5.*log(2*pi*(LOOCVSSqr))+((Y-LOOCVpred).^2./(2*(LOOCVSSqr))));% Compute mean-standardized log loss
end


