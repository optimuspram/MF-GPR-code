function Psi = callkernel(XN,XM,theta,kerneltype,nvar)
%
% Construct a Psi matrix from a defined kernel function
% Available kernels are 'gaussian', 'exponential', 'matern32', 'matern52', 'cubic1',and 'cubic2'
%
% Inputs:
%    XN - First set of sampling points
%    XM - Second set of sampling points
%    theta - Vector of lengthscale (1 x nvar)
%    kerneltype - Type of kernel function
%    nvar - Number of variables
%
% Output:
%    Psi - Covariance matrix
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

mdist = zeros(size(XN,1),size(XM,1),nvar);  % Initialize matrix for computation of Psi
switch kerneltype
    case 'gaussian'
        for ii = 1:nvar
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))).^2)/((1*theta(ii)).^2);
        end
        Psi = exp(-0.5*sum(mdist,3));
    case 'exponential'
        for ii = 1:nvar
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))))/(theta(ii));
        end
        Psi = exp(-sum(mdist,3));
    case 'matern32'
        for ii = 1:nvar
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))))/(theta(ii));
        end
        m3f = prod(1+sqrt(3).*mdist,3);
        m3s = exp(-sqrt(3)*sum(mdist,3));
        Psi = m3f.*m3s;
    case 'matern52'
        for ii = 1:nvar
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))))/(theta(ii));
        end
        m5f = prod(1+sqrt(5).*mdist+(5/3).*mdist.^2,3);
        m5s = exp(-sqrt(5)*sum(mdist,3));
        Psi = m5f.*m5s;
    case 'cubic1'
        theta = theta*3;
        for ii = 1:nvar
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))));
            mat1= (mdist(:,:,ii).^1)./(theta(ii).^1);
            mat2 = (mdist(:,:,ii).^2)./(theta(ii).^2);
            mat3 = (mdist(:,:,ii).^3)./(theta(ii).^3);
            term1 = 1-6.*mat2+6*mat3;
            term2 = 2.*(1-mat1).^3;
            term3 = zeros(size(term2));
            [I1] = find(mdist(:,:,ii)<=(theta(ii)/2));
            [I2] = find((theta(ii)/2) < mdist(:,:,ii) & mdist(:,:,ii) <= theta(ii) );
            [I3] = find(theta(ii)<mdist(:,:,ii));
            mak = mdist(:,:,ii);
            
            mak(I1) = term1(I1);
            mak(I2)  = term2(I2);
            mak(I3) = term3(I3);
            mdist(:,:,ii) = mak;
        end
        Psi = prod(mdist,3);
    case 'cubic2' 
        for ii = 1:nvar
            SF = 1;
            mdist(:,:,ii) = ((pdist2(XN(:,ii),XM(:,ii))));
            mat1= (mdist(:,:,ii).^1)./(SF*theta(ii).^1);
            mat2 = (mdist(:,:,ii).^2)./(SF*theta(ii).^2);
            mat3 = (mdist(:,:,ii).^3)./(SF*theta(ii).^3);
            term1 = 1-6.*mat2+6*mat3;
            term2 = 2.*(1-mat1).^3;
            term3 = zeros(size(term2));
            CM = mdist(:,:,ii)./(theta(ii));
            [I1] = find(0<=CM & CM<=0.5);
            [I2] = find(0.5<=CM & CM<=1);
            [I3] = find(CM>=1);
            mak = mdist(:,:,ii);
            
            mak(I1) = term1(I1);
            mak(I2)  = term2(I2);
            mak(I3) = term3(I3);
            mdist(:,:,ii) = mak;
        end
        Psi = prod(mdist,3);    
end