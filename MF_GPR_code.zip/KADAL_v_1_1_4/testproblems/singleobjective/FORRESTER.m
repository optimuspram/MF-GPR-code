function Y = FORRESTER_HF(X)
% FORRESTER function (one variable).
% high fidelity version
% Alexander I.J Forrester Andr�s S�bester Andy J Keane. 
% Multi-fidelity optimization via surrogate modelling.
% 463. Proceedings of the Royal Society A: Mathematical, Physical and
% Engineering Science.
% http://doi.org/10.1098/rspa.2007.1900
%
% Input
%   X - (nsamp x nvar) matrix of experimental design.
%
% Output
%   Y - (nsamp x 1) vector of responses.

Y = (6*X-2).^2.*sin(12*X-4);

