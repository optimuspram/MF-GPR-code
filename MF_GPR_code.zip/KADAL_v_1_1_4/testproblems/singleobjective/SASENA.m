function Y = SASENA(X)
% SASENA function (two variables).
%
% Input
%   X - (nsamp x nvar) matrix of experimental design.
%
% Output
%   Y - (nsamp x 1) vector of responses.
Y = zeros(size(X,1),0);

for ii = 1:size(X,1)
    x = X(ii,:);
    x1 = x(1);
    x2 = x(2);
    
    Y(ii,1) = 2 + 0.01*(x2-x1^2)^2 + (1-x1)^2 + 2*(2-x2)^2 + 7*sin(0.5*x1)*sin(0.7*x1*x2);
end