function [Y, G] =BRANINmodcon(X)
% BRANIN function (two variables).
%
% The constraint limit for the first constraint is G > 0.2
% Input
%   X - (nsamp x nvar) matrix of experimental design.
%
% Output
%   Y - (nsamp x 1) vector of responses.
Y = zeros(size(X,1),1);


for ii = 1:size(X,1)
    X1 = 15*X(ii,1)-5;
    X2 = 15*X(ii,2);
    a = 1;
    b = 5.1/(4*pi^2);
    c = 5/pi;
    d = 6;
    e = 10;
    ff = 1/(8*pi);
    Y(ii,1) = (a*( X2 - b*X1^2 + c*X1 - d )^2 + e*(1-ff)*cos(X1) + 1)+(5*X1+25)/15;
     G(ii,1) = X(ii,1)*X(ii,2);
end
G = -G;

