function fitness = schaffer(X)
% Generalized Schaffer problem
% Reference: "Emmerich, M. T., & Deutz, A. H. (2007, March). Test problems
% based on Lamé superspheres. In International Conference on Evolutionary 
% Multi-Criterion Optimization (pp. 922-936). Springer, Berlin, Heidelberg."
%
% Inputs：
%   X:  Vector of decision variables
%   r:  Describes the shape of the Pareto front
%
% Output:
%   fitness:    fitness function value
%
% Written by Kaifeng Yang, 20/1/2016
r = 1;
a = 1/(2*r);
    [m,n]   = size(X);
    fitness = zeros(m,2);
    for i=1:m       
        fitness(i,1)    = (1/(n^a))*sum(X(i,:).^2)^a;
        fitness(i,2)    = (1/(n^a))*sum((1-X(i,:)).^2)^a;
    end
end