function [Y, G] = SRN(X)
% SRN function for constrained multi-objective problem
Y = zeros(size(X,1),1);
G = zeros(size(X,1),2);

for ii = 1:size(X,1)
    X1 = X(ii,1);
    X2 = X(ii,2);
    Y(ii,1) = (X1-2)^2+(X2-2)^2+2;
    Y(ii,2) = 9*X1 - (X2-1)^2;
    G(ii,1) = X1^2+X2^2-225;
    G(ii,2) = X1-3*X2+10;
end

