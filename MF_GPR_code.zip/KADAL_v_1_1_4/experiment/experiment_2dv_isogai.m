clc
clear all
close all

addpath(genpath(pwd)); % Add the MATLAB path

HIGH = csvread('300_FLUTTERS.csv',1); % High-fidelity data
LOW = csvread('300_LFM(1).csv',1); % Low-fidelity data
LONEW = [];

% pre-processing, adjust the rows
for ii = 1:300
    HI = HIGH(ii,1:2);
    [C, IA, IB] = intersect(HI,LOW(:,1:2),'rows');
    LONEW(ii,:) = LOW(IB,:);
end

X = HIGH(:,1:2); % Input variables
yh = HIGH(:,3); % High-fidelity output
yl = LONEW(:,3); % Low-fidelity output

% Setting up
nsamph = 40; % High-fidelity sample size
nsampl = 120; % Low-fidelity sample size
CR = 12; % Cost ratio
nsampsf = round(nsamph+(nsampl/CR)); % Equivalent cost
nvar = 2; % Number of variables
nlev = 2; % Number of fidelity levels
DI = 1;  % Output column

% Perform the experiment
for LOOP = 1:40
    IDM = randperm(size(X,1),size(X,1));
    X1 = X(IDM,:);
    yh1 = yh(IDM,:);
    yl1 = yl(IDM,:);
    
    IDX(LOOP,:) = IDM;
    %% Set CoKriging Info
    % Except nlev, the other parameters, when they are set, will be assigned to
    % those levels for which they are not specifically set
    CoKrigInfo.nlev    = nlev; % Set the number of levels.
    CoKrigInfo.nvar    = nvar; % Set the number of variables. (REQUIRED PARAMETER)
    CoKrigInfo.lb      = min(X); % Lower bounds, size 1 X nvar. (REQUIRED PARAMETER)
    CoKrigInfo.ub      = max(X); % Upper bounds, size 1 x nvar. (REQUIRED PARAMETER)
    CoKrigInfo.nrestart = 1; % Number of restart for hyperparameters optimization (using CMA-ES by default).
    CoKrigInfo.display = 0; % Run the program in the silet mode
    CoKrigInfo.nested = 0; % 1 Nested samples 0 Non-nested samples
    CoKrigInfo.optimizer = 'ga';
    
    %% Set CoKriging.level Info
    % low fidelity
    CoKrigInfo.level{1}.X = X1(1:nsampl,:); % Set the experimental design.
    CoKrigInfo.level{1}.Y = yl1(1:nsampl,DI); % Evaluate the experimental design.
    CoKrigInfo.level{1}.nsamp   = nsampl; % Set the number of initial samples. (REQUIRED PARAMETER)
    
    CoKrigInfo.level{2}.X = X1(1:nsamph,:); % Set the experimental design.
    CoKrigInfo.level{2}.Y = yh1(1:nsamph,DI); % Evaluate the experimental design.
    CoKrigInfo.level{2}.nsamp   = nsamph; % Set the number of initial samples. (REQUIRED PARAMETER)
    CoKrigInfo.nested = 1;
    
    %% Validation samples
    Xpred = X1(nsamph+1:end,:);
    YpredH = yh1(nsamph+1:end,DI);
    YpredL = yl1(nsamph+1:end,DI);
    
    %% Same kernel for low- and high, and full CKL
    KERNEL = {{'gaussian'},{'matern32'},{'matern52'},{'cubic2'},{'gaussian','matern32','matern52','cubic2'}}
    myCoKriging1 = CoKrigInfo;
    for KLOOP = 1:length(KERNEL)
        myCoKriging1.kernel  = KERNEL{KLOOP};
        myCoKriging1.level{1}.kernel = myCoKriging1.kernel;
        myCoKriging1.level{2}.kernel = myCoKriging1.kernel;
        
        myCoKrigingTrain{KLOOP} = train_CoKriging(myCoKriging1); % train the CoKriging model.
        
        [Ypred1, SSqr1] = cokrigprediction(Xpred, myCoKrigingTrain{KLOOP},'pred'); % prediction
        ERROR.rmse.CKL(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmse')/iqr(yh(:,DI));
        ERROR.mare.CKL(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'mare')/iqr(yh(:,DI));
        ERROR.rmsre.CKL(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmsre')/iqr(yh(:,DI));
        ERROR.r2.CKL(LOOP,KLOOP) = rsquarefun(Ypred1{2},YpredH);
        
        ERROR.rmself.CKL(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmse')/iqr(yl(:,DI));
        ERROR.marelf.CKL(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'mare')/iqr(yl(:,DI));
        ERROR.rmsrelf.CKL(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmsre')/iqr(yl(:,DI));
        ERROR.r2lf.CKL(LOOP,KLOOP) = rsquarefun(Ypred1{1},YpredL);
        
        ERROR.weight{LOOP}.low{KLOOP} = myCoKrigingTrain{1}.level{1}.wgkf
        ERROR.weight{LOOP}.high{KLOOP} =  myCoKrigingTrain{1}.level{2}.wgkf;
        
        
        LOOER(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.LOOCVerror;
        NEGER(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.NegLnLike;
        LOOER_LF(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{1}.LOOCVerror;
    end
    
    %% Partial CKL, CKL applied on high-level only
    for KLOOP = 1:length(KERNEL)-1
        myCoKriging1.kernel  = KERNEL{KLOOP};
        myCoKriging1.level{1}.kernel = KERNEL{KLOOP};
        myCoKriging1.level{2}.kernel = KERNEL{5};
        
        myCoKrigingTrain{KLOOP} = train_CoKriging(myCoKriging1); % train the CoKriging model.
        
        [Ypred1, SSqr1] = cokrigprediction(Xpred, myCoKrigingTrain{KLOOP},'pred'); % prediction
        ERROR.rmse.CKL2(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmse')/iqr(yh(:,DI));
        ERROR.mare.CKL2(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'mare')/iqr(yh(:,DI));
        ERROR.rmsre.CKL2(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmsre')/iqr(yh(:,DI));
        ERROR.r2.CKL2(LOOP,KLOOP) = rsquarefun(Ypred1{2},YpredH);
        
        ERROR.rmself.CKL2(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmse')/iqr(yl(:,DI));
        ERROR.marelf.CKL2(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'mare')/iqr(yl(:,DI));
        ERROR.rmsrelf.CKL2(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmsre')/iqr(yl(:,DI));
        ERROR.r2lf.CKL2(LOOP,KLOOP) = rsquarefun(Ypred1{1},YpredL);
        
        ERROR.weight{LOOP}.low2{KLOOP} = myCoKrigingTrain{1}.level{1}.wgkf
        ERROR.weight{LOOP}.high2{KLOOP} =  myCoKrigingTrain{1}.level{2}.wgkf;
        LOOER2(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.LOOCVerror;
        NEGER2(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.NegLnLike;
        LOOER_LF2(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{1}.LOOCVerror;
    end
    
    %% Partial CKL, CKL applied on low-level only
    for KLOOP = 1:length(KERNEL)-1
        myCoKriging1.kernel  = KERNEL{KLOOP};
        myCoKriging1.level{1}.kernel = KERNEL{5};
        myCoKriging1.level{2}.kernel = KERNEL{KLOOP};
        
        myCoKrigingTrain{KLOOP} = train_CoKriging(myCoKriging1); % train the CoKriging model.
        
        [Ypred1, SSqr1] = cokrigprediction(Xpred, myCoKrigingTrain{KLOOP},'pred'); % prediction
        ERROR.rmse.CKL3(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmse')/iqr(yh(:,DI));
        ERROR.mare.CKL3(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'mare')/iqr(yh(:,DI));
        ERROR.rmsre.CKL3(LOOP,KLOOP) = errperf(Ypred1{2},YpredH,'rmsre')/iqr(yh(:,DI));
        ERROR.r2.CKL3(LOOP,KLOOP) = rsquarefun(Ypred1{2},YpredH);
        
        ERROR.rmself.CKL3(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmse')/iqr(yl(:,DI));
        ERROR.marelf.CKL3(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'mare')/iqr(yl(:,DI));
        ERROR.rmsrelf.CKL3(LOOP,KLOOP) = errperf(Ypred1{1},YpredL,'rmsre')/iqr(yl(:,DI));
        ERROR.r2lf.CKL3(LOOP,KLOOP) = rsquarefun(Ypred1{1},YpredL);
        
        ERROR.weight{LOOP}.low3{KLOOP} = myCoKrigingTrain{1}.level{1}.wgkf
        ERROR.weight{LOOP}.high3{KLOOP} =  myCoKrigingTrain{1}.level{2}.wgkf;
        LOOER3(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.LOOCVerror;
        NEGER3(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{2}.NegLnLike;
        LOOER_LF3(LOOP,KLOOP) = myCoKrigingTrain{KLOOP}.level{1}.LOOCVerror;
    end
    
    %% Single-fidelity GPR
    KrigInfo.nvar    = nvar; % Set the number of variables.
    KrigInfo.nsamp   = round(nsamph+(nsampl/CR)); % Set the number of initial samples.
    KrigInfo.lb      =  CoKrigInfo.lb ; % Lower bounds, size 1 X nvar.
    KrigInfo.ub      =  CoKrigInfo.ub ; % Upper bounds, size 1 x nvar.
    KrigInfo.nrestart = 5; % Number of restart for hyperparameters optimization (using CMA-ES by default).
    KrigInfo.display = 0; % Run the program in the silent mode
    KrigInfo.optimizer = 'ga';

    KrigInfo.X       = X1(1:KrigInfo.nsamp ,:); % Set the experimental design.
    KrigInfo.Y       = yh1(1:KrigInfo.nsamp ,DI); % Evaluate the experimental design.
    KrigInfo.kernel  = KERNEL{5}; % single kernel function.
    
    myKriging2 = train_Kriging(KrigInfo); % Construct the Kriging model.
    
    Ypredh = krigprediction(Xpred,myKriging2,'pred'); % single kernel prediction
    ERROR.rmse.SFE(LOOP,1) = errperf(Ypredh,YpredH,'rmse')/iqr(yh(:,DI));
    ERROR.mare.SFE(LOOP,1) = errperf(Ypredh,YpredH,'mare')/iqr(yh(:,DI));
    ERROR.rmsre.SFE(LOOP,1) = errperf(Ypredh,YpredH,'rmsre')/iqr(yh(:,DI));
    ERROR.r2.SFE(LOOP,1) = rsquarefun(Ypredh,YpredH);
    ERROR.weight{1}.SFE(LOOP,:) =  myKriging2.wgkf;
 
end
