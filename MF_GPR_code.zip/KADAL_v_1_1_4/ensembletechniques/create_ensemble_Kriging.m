function [EnsKrigInfo] = create_ensemble_Kriging(indiv_Kriging, ensmethod)
% Create the ensemble of Kriging structure
%
% Inputs:
%   indiv_Kriging - Structure of individual Kriging models.
%   ensmethod - Type of ensemble method.
%
% Output:
%   EnsKrigInfo - Structure of the constructed ensemble of Kriging.

nmod = length(indiv_Kriging); % Number of individual Kriging models
Y = indiv_Kriging{1}.Y;

% Compute the weights
for ii = 1:nmod
    LOOCVpredM(:,ii) = indiv_Kriging{ii}.LOOCVpred; % LOOCV prediction, only for GCV-based ensemble
    LOOCVSSqrM(:,ii) = indiv_Kriging{ii}.LOOCVSSqr;
    regfacM(ii) = 10.^indiv_Kriging{ii}.regfac;
    NegLnLikeidv(ii,1) = indiv_Kriging{ii}.NegLnLike; % Negative Log-likelihood of Kriging, only for AIC-based ensemble
    nvf(ii,1) = length(indiv_Kriging{ii}.lengthscale)+length(indiv_Kriging{ii}.BE)+2; % Number of free variables, only for AIC-based ensemble
    switch indiv_Kriging{ii}.regfacparam
        case 'fixed'
            % Do nothing, regression factor is not a free variable
        case 'tuned'
            nvf(ii,1) = nvf(ii,1)+1; % Regression factor is counted as free variable
    end
    
end

switch ensmethod
    case 'AIC'
        [wgth] = AICensemble(NegLnLikeidv,nvf,Y);
        EnsKrigInfo.nvf = nvf; % Number of free variables
    case 'GCV'
        [wgth] = GCVensemble(LOOCVpredM,Y);
    case 'MSLL'
        [wgth] = MSLLensemble(LOOCVpredM,LOOCVSSqrM,regfacM,Y);
case 'MSLL2'
        [wgth] = MSLLensemble2(LOOCVpredM,LOOCVSSqrM,regfacM,Y);
end

% Create the ensemble of Kriging structure
EnsKrigInfo.indiv_Kriging = indiv_Kriging; % Structures of individual Kriging
EnsKrigInfo.wgth = wgth; % Weights as computed from the defined method
EnsKrigInfo.ensmethod = ensmethod; % Type of ensemble method

end

% Compute the weights using AIC-based ensemble
function [wgaic] = AICensemble(NegLnLikeidv,nfv,Y)
AIC = -2.*(-NegLnLikeidv) + (2.*nfv.*(nfv+1))./(size(Y,1)-nfv-1); % Compute the AIC of each individual model
minAIC = min(AIC); % Lowest AIC as the reference value
wgaic = exp(-0.5.*(AIC-minAIC))./sum(exp(-0.5.*(AIC-minAIC))); % Compute AIC weights
end

% Compute the weights using global cross validation(GCV)-based ensemble
function [wgglo] = GCVensemble(LOOCVpredM,Y)
nmod = size(LOOCVpredM,2); % Number of individual models
AD = abs(LOOCVpredM-repmat(Y,1,nmod));
CM = (AD'*AD)/size(Y,1); % Matrix of vectors of cross-validation errors
CM = diag(diag(CM)); % Take only the diagonal of the original CM matrix to ensure positive weight
wgglo = (CM\ones(nmod,1))./(ones(1,nmod)*(CM\ones(nmod,1))); % Compute the weights
end

% Compute the weights using MSLL-based ensemble
function [wgglo] = MSLLensemble(LOOCVpredM,LOOCVSSqrM,regfacM,Y)
nmod = size(LOOCVpredM,2); % Number of individual models
nsamp = size(LOOCVpredM,1); % Size of sampling points
AD = (0.5.*log(2*pi*(repmat(regfacM,nsamp,1)+LOOCVSSqrM)) + ((repmat(Y,1,nmod)-LOOCVpredM).^2./(2*(repmat(regfacM,nsamp,1)+LOOCVSSqrM))));
% AD = abs(LOOCVpredM-repmat(Y,1,nmod));
% AD = abs(
% AD = ((repmat(Y,1,nmod)-LOOCVpredM).^2./(2*(repmat(regfacM,nsamp,1)+LOOCVSSqrM)));
AD = 1./((repmat(Y,1,nmod)-LOOCVpredM).^1./(1*sqrt(repmat(regfacM,nsamp,1)+LOOCVSSqrM)));
AD = abs(AD);
% MAK = mean(AD)
% % AD = AD-min(AD')';
% % % AD = AD-min(AD(:))
% AD = abs(AD-max(AD')');
% save bow AD
CM = (AD'*AD)/size(Y,1); % Matrix of vectors of cross-validation errors
CM = diag(diag(CM)); % Take only the diagonal of the original CM matrix to ensure positive weight
wgglo = (CM\ones(nmod,1))./(ones(1,nmod)*(CM\ones(nmod,1))); % Compute the weights
% wgglo = (MAK+max(MAK))/sum(MAK+max(MAK));wgglo = wgglo';
% ML = exp(MAK(end,:));
% alpha = 0;
% beta = -2;
% EAVG = mean(ML);
% WW = (ML+EAVG).^(beta);
% wgglo = WW./sum(WW);
% wgglo = wgglo';
end

% Compute the weights using MSLL-based ensemble
function [wgglo] = MSLLensemble2(LOOCVpredM,LOOCVSSqrM,regfacM,Y)
nmod = size(LOOCVpredM,2); % Number of individual models
nsamp = size(LOOCVpredM,1); % Size of sampling points
AD = (0.5.*log(2*pi*(repmat(regfacM,nsamp,1)+LOOCVSSqrM)) + ((repmat(Y,1,nmod)-LOOCVpredM).^2./(2*(repmat(regfacM,nsamp,1)+LOOCVSSqrM))));
AD = abs(LOOCVpredM-repmat(Y,1,nmod)) + sqrt(repmat(regfacM,nsamp,1))+sqrt(LOOCVSSqrM);
% AD = abs(
% % AD = ((repmat(Y,1,nmod)-LOOCVpredM).^2./(2*(repmat(regfacM,nsamp,1)+LOOCVSSqrM)));
% AD = 1./((repmat(Y,1,nmod)-LOOCVpredM).^1./(1*sqrt(repmat(regfacM,nsamp,1)+LOOCVSSqrM)));
% AD = abs(AD);
% MAK = mean(AD)
% % AD = AD-min(AD')';
% % % AD = AD-min(AD(:))
% AD = abs(AD-max(AD')');
save bow AD
CM = (AD'*AD)/size(Y,1); % Matrix of vectors of cross-validation errors
CM = diag(diag(CM)); % Take only the diagonal of the original CM matrix to ensure positive weight
wgglo = (CM\ones(nmod,1))./(ones(1,nmod)*(CM\ones(nmod,1))); % Compute the weights
% wgglo = (MAK+max(MAK))/sum(MAK+max(MAK));wgglo = wgglo';
% ML = exp(MAK(end,:));
% alpha = 0;
% beta = -2;
% EAVG = mean(ML);
% WW = (ML+EAVG).^(beta);
% wgglo = WW./sum(WW);
% wgglo = wgglo';
end



