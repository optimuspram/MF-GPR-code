function [output,ypredc,SSqrc] = enskrigprediction(XP, myEnsKrig,predictiontype)
% Calculates the output (i.e., prediction or mean-squared error) from the ensemble of Kriging models.
%
% Inputs:
%   XP - Prediction site.
%   myEnsKrig - A structure containing information of the constructed ensemble of Kriging.
%   predictiontype - The output as defined by the user.
%
% Outputs:
%   output - Prediction or mean-squared error from the ensemble of Kriging models
%   ypredidv - predicted responses from individual models (nsamp X nmod)
%   SSqridv - mean-squared error from individual models (nsamp X nmod)
nmod = length(myEnsKrig.indiv_Kriging);
npred = size(XP,1);
wgth = myEnsKrig.wgth; % Weights as computed from the specified technique.

ypredidv = zeros(npred, nmod); % Initialize individual Kriging prediction.
SSqridv = zeros(npred, nmod); % Initialize individual Kriging mean-squared error.
for ii = 1:nmod
    ypredidv(:,ii) = krigprediction(XP,myEnsKrig.indiv_Kriging{ii},'pred');
    SSqridv(:,ii) = krigprediction(XP,myEnsKrig.indiv_Kriging{ii},'SSqr');
end

ypredc = (sum((wgth'.*ypredidv)'))'; % Compute the combined prediction
SSqrc  = (sum((wgth'.*SSqridv.^2)'))' + sum(wgth.*(ypredidv-repmat(ypredc,1,nmod))'.^2)'; % Compute the combined mean-squared error

switch predictiontype
    case 'pred'
        output = ypredc;
    case 'SSqr'   
        output = SSqrc;
end



