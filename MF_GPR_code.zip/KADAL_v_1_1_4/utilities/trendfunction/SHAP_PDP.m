function SHAP_PDP(SHAP,XSAMPLE,ID1,ID2,mySobol)


if nargin > 4
    seci = mySobol.Results.AllOrders{2};
    idxsec = mySobol.Results.VarIdx{2};
    
    [I,~] = find(sum(idxsec == ID1,2) == 1);
    [C2,I2] = max(seci(I));
    idx = idxsec(I(I2),:);
    ID2 = idx(idx~=ID1);
end

scatter(XSAMPLE(:,ID1),SHAP(:,ID1),[],XSAMPLE(:,ID2),'filled'); box on;

texts = strcat(['$x_{',num2str(ID1),'}$']);
xlabel(texts,'interpreter','latex','FontSize',12);;

texts = strcat(['$\phi_{',num2str(ID1),'}$']);
ylabel(texts,'interpreter','latex','FontSize',12);

set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
texts = strcat(['Colored by $x_{',num2str(ID2),'}$']);
title(texts,'FontSize',14,'interpreter','latex','FontSize',12)
grid on
box on
colorbar('Ticks',[min(XSAMPLE(:,ID2)), max(XSAMPLE(:,ID2))],'TickLabels',{'Low','High'});
set(gca,'TickLabelInterpreter','latex','FontSize',14);
% set(gca,'xtick',[0:1/4:1])