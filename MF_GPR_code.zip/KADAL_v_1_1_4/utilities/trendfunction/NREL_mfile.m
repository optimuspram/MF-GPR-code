clc
clear all
close all

uqlab

load NREL_DATA X Y
nsamp = 2000; % Number of samples


XSAMPT = X(1:nsamp,:);
YALL = Y(1:nsamp,:);

nvar = 5;
lb = min(XSAMPT);
ub = max(XSAMPT);



%% Marginal distributions definition
for i=1:nvar
    InputOpts.Marginals(i).Type = 'Uniform';
    InputOpts.Marginals(i).Parameters = [-1,1];
    PolyTpes{i} = 'Legendre';
end
PolyTypes{3} = 'Arbitrary';
InputOpts.Marginals(3).Type = 'KS';
InputOpts.Marginals(3).Parameters = X(:,3);

PolyTypes{5} = 'Arbitrary';
InputOpts.Marginals(5).Type = 'KS';
InputOpts.Marginals(5).Parameters = X(:,5);

myInput = uq_createInput(InputOpts);
% 
% for im=1:jt
%     PolyTypes{im} = 'Arbitrary'; % Stieltjes-based PCE
%     InputOptsN.Marginals(im).Type = 'KS'; % Kernel density estimation
%     InputOptsN.Marginals(im).Parameters = MetaOpts.ExpDesign.X(:,jt) ; % Samples for density estimation
%     %InputOptsN.Marginals(im).Parameters = XVALNtrans(:,jt); % use 1000 samples for KDE
% end
% myInputN = uq_createInput(InputOptsN);
% MetaOpts.PolyTypes = PolyTypes;
% 
% % iOpts.Inference.Data = X; iOpts.Copula.Type = 'Independent';
% % myInput = uq_createInput(iOpts)

%% Loop over different methods

for LOOP = 1:7
    YSAMP = YALL(:,LOOP);
    
    PCEOpts.Type = 'Metamodel';
    PCEOpts.MetaType = 'PCE';
    PCEOpts.Input = myInput;
    ModelOpts.mFile = 'evalkrig';
    myModel = uq_createModel(ModelOpts);
    PCEOpts.FullModel = myModel;
    PCEOpts.Degree = [1:13];
    PCEOpts.ExpDesign.X = XSAMPT; % Define sampling points X
    PCEOpts.ExpDesign.Y = YSAMP; % Define sampling points Y
    % PCEOpts.Method = 'OLS';
    myPCED{LOOP} = uq_createModel(PCEOpts);
    SobolSensOpts.Type = 'Sensitivity';
    SobolSensOpts.Sobol.Order = 3;
    SobolSensOpts.Method = 'Sobol';
    SobolAnalysis = uq_createAnalysis(SobolSensOpts);
    SobTest{LOOP} = SobolAnalysis;
end

% yall = uq_evalModel(myPCE,XSAMPLE);
close 4
figure(4);
for ii = 1:20
     scatter((SHAPR(:,ii)),ones(1,size(SHAPR,1))*ii,[],XSAMPLER(:,ii),'filled');
%     scatter((SHAP(:,ii)),ones(1,size(SHAP,1))*ii,[],XSAMPLE(:,ii),'filled');
    hold on
end
%%
[SHAP, XSAMPLE] = SHAP_additive_analytical_faster(myPCED{3},myInput,1e5);
ID = 1; ID2=1;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;
ID = 3; ID2=3;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;
ID = 2; ID2=2;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;


[C I] = find(XSAMPLE(:,3) > -1)
XSAMPLE = XSAMPLE(C,:); SHAP = SHAP(C,:);
[C I] = find(XSAMPLE(:,3) < 1);
XSAMPLE = XSAMPLE(C,:); SHAP = SHAP(C,:);
figure(1)
ID = 3; ID2=1;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;
xlabel('$x_{3}$','interpreter','latex','FontSize',12);
ylabel('$\phi_{3}$','interpreter','latex','FontSize',12);
set(gcf,'color','w');
set(gca,'TickLabelInterpreter','latex','FontSize',12)
colorbar('Ticks',[min(XSAMPLE(1:1e4,ID2)) max(XSAMPLE(1:1e4,ID2))],'TickLabels',{'Low','High'});

figure(3)
ID = 1; ID2=3;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;
xlabel('$x_{1}$','interpreter','latex','FontSize',12);
ylabel('$\phi_{1}$','interpreter','latex','FontSize',12);
set(gcf,'color','w');
set(gca,'TickLabelInterpreter','latex','FontSize',12)
colorbar('Ticks',[min(XSAMPLE(1:1e4,ID2)) max(XSAMPLE(1:1e4,ID2))],'TickLabels',{'Low','High'});

figure(1)
ID = 2; ID2=3;scatter(XSAMPLE(1:1e4,ID),SHAP(1:1e4,ID),[],XSAMPLE(1:1e4,ID2),'filled'); box on;
xlabel('$x_{2}$','interpreter','latex','FontSize',12);
ylabel('$\phi_{2}$','interpreter','latex','FontSize',12);
set(gcf,'color','w');
set(gca,'TickLabelInterpreter','latex','FontSize',12)
colorbar('Ticks',[min(XSAMPLE(1:1e4,ID2)) max(XSAMPLE(1:1e4,ID2))],'TickLabels',{'Low','High'});
