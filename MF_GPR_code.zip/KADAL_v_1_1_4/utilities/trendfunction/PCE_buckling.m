clc; clear all; close all

uqlab
ModelOpts.mFile = 'platebucling';

myModel = uq_createModel(ModelOpts);

nvar = 6;
nsamp = 120;

CV = [0.028, 0.044, 0.1235, 0.076, 0.05, 0.07];
MEAN = [23.808, 0.525, 44.2, 28623, 0.35, 5.25];
STD = MEAN.*CV;
for ii = 1:6
    InputOpts.Marginals(ii).Type = 'Gaussian';
    InputOpts.Marginals(ii).Parameters = [MEAN(ii), STD(ii)];  % (m/yr)
    if (ii == 2) || (ii==3)
        InputOpts.Marginals(ii).Type = 'Lognormal';
        m = MEAN(ii); v = STD(ii)^2;
        MU = log((m^2)/sqrt(v+m^2));
        SIGMA  = sqrt(log(v/(m^2)+1));
        InputOpts.Marginals(ii).Parameters = [MU, SIGMA];  % (m/yr)
    end
end

myInput = uq_createInput(InputOpts);
X = uq_getSample(nsamp,'Sobol');

Y = platebucling(X);


PCEOpts.Type = 'Metamodel';
PCEOpts.MetaType = 'PCE';
PCEOpts.FullModel = myModel;
PCEOpts.Degree = [1:6];
PCEOpts.ExpDesign.X = X;
PCEOpts.ExpDesign.Y = Y;

myPCE = uq_createModel(PCEOpts);
SobolOpts.Type = 'Sensitivity';
SobolOpts.Method = 'Sobol';

SobolOpts.Sobol.Order = 3;

SobolAnalysis = uq_createAnalysis(SobolOpts);

GLOOP = 1;
SOBOTrue.TOT{GLOOP}(:,1) = SobolAnalysis.Results.Total;
SOBOTrue.FIR{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{1};
SOBOTrue.SEC{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{2};
SOBOTrue.THI{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{3};
SHAPVALUEtrue{GLOOP}(:,1) = SHAPPCE(myPCE);

%% SHAP

NSAMP = logspace(4,7,4)
for ii = 1:length(NSAMP);
      [phi1(ii,:),lphi1(ii,:),uphi1(ii,:)] = SHAPMCS_PCE_sample(myPCE,NSAMP(ii),nvar);
end

for ii = 1:length(NSAMP);
%     XMC = uq_getSample(NSAMP(ii));
%     YMC = 
      [phi1mc(ii,:),lphi1mc(ii,:),uphi1mc(ii,:)] = SHAPMCS_sample(ModelOpts.mFile,NSAMP(ii),nvar);
      ii
end


%%

close all
figure(1);
ID = 3;
plot(NSAMP,phi1(:,ID),'bo-'); hold on;
plot(NSAMP,repmat(SHAPVALUEtrue{1}(ID),1,length(NSAMP)),'m-')
% plot(NSAMP,repmat(SHAPE(ID),1,length(NSAMP)),'k-.')
plot(NSAMP,lphi1(:,ID),'bo--');
plot(NSAMP,uphi1(:,ID),'bo--');
xlabel('$n_{mcs}$','interpreter','latex','FontSize',15);
ylabel('$\phi_{2}$','interpreter','latex','FontSize',15);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
box on
grid on
set(gcf,'position',[200 300 450 350]);
legend({'MCS-PCE','Exact-PCE','Exact-Analytical','95\% CI, MCS-PCE'},'interpreter','latex');
set(gca,'xscale','log')
saveas(gcf,'shapley_ISHIGAMI_1000samples_var2_50samp.eps','eps2c');
hgsave('shapley_ISHIGAMI_1000samples_var2_50samp')