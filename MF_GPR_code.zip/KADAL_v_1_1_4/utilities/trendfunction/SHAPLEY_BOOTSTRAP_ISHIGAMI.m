clc
clear all
close all

% uqlab

uqlab
ModelOpts.mFile = 'baka';

myModel = uq_createModel(ModelOpts);

nvar = 3;
NSAMP = [50:25:250];
nsamp = 50;

for ii = 1:nvar
    InputOpts.Marginals(ii).Type = 'Uniform';
    InputOpts.Marginals(ii).Parameters = [0 1];  % (m/yr)
end


myInputS = uq_createInput(InputOpts);

%%
for GLOOP = 1:length(NSAMP)
    nsamp = NSAMP(GLOOP);
    XSAMPT = uq_getSample(nsamp,'Sobol')
    
    YSAMP =  ISHIGAMI_NORM(XSAMPT);
    
    XVAL =  uq_getSample(5e4);
    YVAL = ISHIGAMI_NORM(XVAL);
    %% Loop over different methods
    
    
    PCEOpts.Type = 'Metamodel';
    PCEOpts.MetaType = 'PCE';
    PCEOpts.Input = myInputS;
    ModelOpts.mFile = 'evalkrig';
    myModel = uq_createModel(ModelOpts);
    PCEOpts.FullModel = myModel;
    PCEOpts.Degree = [14];
    PCEOpts.ExpDesign.X  = XSAMPT;
    PCEOpts.ExpDesign.Y  = YSAMP;
    myPCE = uq_createModel(PCEOpts);
    SobolSensOpts.Type = 'Sensitivity';
    SobolSensOpts.Sobol.Order = 3;
    SobolSensOpts.Method = 'Sobol';
    SobolAnalysis = uq_createAnalysis(SobolSensOpts);
    SobTest = SobolAnalysis;
    
    YPRED = uq_evalModel(myPCE,XVAL);
    
    SOBOTrue.TOT{GLOOP}(:,1) = SobolAnalysis.Results.Total;
    SOBOTrue.FIR{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{1};
    SOBOTrue.SEC{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{2};
    SOBOTrue.THI{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{3};
    SHAPVALUEtrue{GLOOP}(:,1) = SHAPPCE(myPCE);
    
    R2(GLOOP,1) = rsquarefun(YPRED,YVAL);
    RMSE(GLOOP,1) = errperf(YPRED,YVAL,'rmse');
    ERRLOOCV(GLOOP,1) = myPCE.Error.LOO;
    ERRMODLOOCV(GLOOP,1) = myPCE.Error.ModifiedLOO;
    
    for BOOT = 1:500
        [~,idx] = datasample([1:nsamp],nsamp); I = unique(idx);
        XBOOT = XSAMPT(I,:);
        YBOOT = YSAMP(I,:);
        
        nsamp = size(XSAMPT,1);
        
        %% Marginal distributions definition
        myInput = myInputS;
        %% Loop over different methods
        % Kriging model definition
        
        
        %% PCE
        PCEOpts.Type = 'Metamodel';
        PCEOpts.MetaType = 'PCE';
        PCEOpts.Input = myInput;
        myModel = uq_createModel(ModelOpts);
        PCEOpts.FullModel = myModel;
        PCEOpts.Degree = [14];
        PCEOpts.ExpDesign.X  = XBOOT;
        PCEOpts.ExpDesign.Y  = YBOOT;
        myPCE = uq_createModel(PCEOpts);
        SobolSensOpts.Type = 'Sensitivity';
        SobolSensOpts.Sobol.Order = 3;
        SobolSensOpts.Method = 'Sobol';
        
        SobolAnalysis = uq_createAnalysis(SobolSensOpts);
        
        SOBOT.TOT{GLOOP}(:,BOOT) = SobolAnalysis.Results.Total;
        SOBOT.FIR{GLOOP}(:,BOOT) = SobolAnalysis.Results.AllOrders{1};
        SOBOT.SEC{GLOOP}(:,BOOT) = SobolAnalysis.Results.AllOrders{2};
        SOBOT.THI{GLOOP}(:,BOOT) = SobolAnalysis.Results.AllOrders{3};
        SHAPVALUE{GLOOP}(:,BOOT) = SHAPPCE(myPCE);
        
        YPRED = uq_evalModel(myPCE,XVAL);
        
        ERROR.LOO(GLOOP,BOOT) = myPCE.Error.LOO;
        ERROR.MODLOO(GLOOP,BOOT) = myPCE.Error.ModifiedLOO;
    end
    save ISHIGAMI_bootstrap_PCE
end

close all
ID = 1;
for ii = 1:9
   ys(ii) = SHAPVALUEtrue{ii}(ID);
   lbx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.025);
   ubx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.995);
end
plot(NSAMP,ys,'bo-'); hold on
plot(NSAMP,repmat(ys(end),1,9),'m-'); hold on
plot(NSAMP,lbx,'bo--'); hold on
plot(NSAMP,ubx,'bo--'); hold on
% axis([0.5 8.5 0 0.5]);
legend({'Exact-PCE','Exact-Analytical','95\% CI, Exact-PCE'},'interpreter','latex');
xlabel('$n$','interpreter','latex','FontSize',20);
ylabel('$\phi_{1}$','interpreter','latex','FontSize',20);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
grid on
set(gca,'TickLabelInterpreter','latex','FontSize',15)
saveas(gcf,'shapley_ishigami_var1.eps','eps2c');
hgsave('shapley_ishigami_var1');

close all
ID = 2;
for ii = 1:9
   ys(ii) = SHAPVALUEtrue{ii}(ID);
   lbx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.025);
   ubx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.975);
end
plot(NSAMP,ys,'bo-'); hold on
plot(NSAMP,repmat(ys(end),1,9),'m-'); hold on
plot(NSAMP,lbx,'bo--'); hold on
plot(NSAMP,ubx,'bo--'); hold on
axis([0.5 8.5 0 0.5]);
legend({'Exact-PCE','Exact-Analytical','95\% CI, Exact-PCE'},'interpreter','latex');
xlabel('$n$','interpreter','latex','FontSize',20);
ylabel('$\phi_{2}$','interpreter','latex','FontSize',20);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
grid on
set(gca,'TickLabelInterpreter','latex','FontSize',15)
saveas(gcf,'shapley_ishigami_var2.eps','eps2c');
hgsave('shapley_ishigami_var2');

close all
ID = 3;
for ii = 1:9
   ys(ii) = SHAPVALUEtrue{ii}(ID);
   lbx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.025);
   ubx(ii) =  quantile(SHAPVALUE{ii}(ID,:)',0.975);
end
plot(NSAMP,ys,'bo-'); hold on
plot(NSAMP,repmat(ys(end),1,9),'m-'); hold on
plot(NSAMP,lbx,'bo--'); hold on
plot(NSAMP,ubx,'bo--'); hold on
% axis([0.5 8.5 0 0.5]);
legend({'Exact-PCE','Exact-Analytical','95\% CI, Exact-PCE'},'interpreter','latex');
xlabel('$n$','interpreter','latex','FontSize',20);
ylabel('$\phi_{3}$','interpreter','latex','FontSize',20);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
grid on
set(gca,'TickLabelInterpreter','latex','FontSize',15)
saveas(gcf,'shapley_ishigami_var3.eps','eps2c');
hgsave('shapley_ishigami_var3');
%%