function [SHAPC,TOT] = bootstrapGSA(myPCE,nboot)
X = myPCE.ExpDesign.X;
Y = myPCE.ExpDesign.Y;
nsamp = length(Y);

for II = 1:nboot
    IC = datasample([1:nsamp],nsamp);
    IC = unique(IC);
    XB = X(IC,:);
    YB = Y(IC,:);
%     size(XB)
    SobolOpts.Type = 'Sensitivity';
    SobolOpts.Method = 'Sobol';
    
    SobolOpts.Sobol.Order = 3;
    
    PCEOpts.Type = 'Metamodel';
    PCEOpts.MetaType = 'PCE';
%     PCEOpts.FullModel = myModel;
    PCEOpts.Degree = 3;
    PCEOpts.ExpDesign.X = XB;
    PCEOpts.ExpDesign.Y = YB;
    
    myPCE = uq_createModel(PCEOpts);
    mySobolAnalysisPCE = uq_createAnalysis(SobolOpts);
    SHAPC(:,II) =SHAPPCE(myPCE);
    TOT(:,II) = mySobolAnalysisPCE.Results.Total;
end