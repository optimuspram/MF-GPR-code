function SHAP_interaction_plot(ID1,ID2,myPCE)

cofall = myPCE.PCE.Coefficients;
idxall = full(myPCE.PCE.Basis.Indices);
MaxInt = myPCE.PCE.Basis.MaxInteractions;
Var = myPCE.PCE.Moments.Var;
nvar = size(idxall,2);

il = zeros(1,nvar);il([ID1 ID2]) = 1;
im = (idxall~=0);
po = sum(il == im,2);
[C I] = find(po == nvar);
idi = idxall(C,:);
cos = 1/(sum(il)).*cofall(C,:);

% Create PCe
MetaOpts.Input = myInput;
MetaOpts.Type = 'Metamodel';
MetaOpts.MetaType = 'PCE';
MetaOpts.Method = 'Custom';
for jj=1:nvar
    MetaOpts.PCE.Basis.PolyTypes{jj} = myPCE.PCE.Basis.PolyTypes{jj};
end
MetaOpts.PCE.Basis.Indices = idi;
MetaOpts.PCE.Coefficients = cos;
myPCExs= uq_createModel(MetaOpts);
SHAPI = uq_evalModel(myPCExs,XSAMPLE);
% scatter(XSAMPLE(1:1000,ID),SHAPI(1:1000),[],XSAMPLE(1:1000,ID2),'filled'); box on;
%%
[XX,YY] = meshgrid([0:0.025:1],[0:0.025:1]);
ZZ = zeros(size(XX));
for ii = 1:size(XX,1)
    for jj =1:size(XX,2)
        zz = zeros(1,nvar); zz(ID1) = XX(ii,jj); zz(ID2) = YY(ii,jj);
        ZZ(ii,jj) = uq_evalModel(myPCExs,zz);
    end
end
[C,h] = contourf(XX,YY,ZZ,100); set(h,'LineColor','none')
set(gcf,'position',[200 300 400 350]);

%%
scatter(XSAMPLE(:,ID1),SHAPI,[],XSAMPLE(:,ID2),'filled'); box on;

texts = strcat(['$x_{',num2str(ID1),'}$']);
xlabel(texts,'interpreter','latex','FontSize',12);

texts = strcat(['$\phi_{',num2str(ID1),'}$']);
ylabel(texts,'interpreter','latex','FontSize',12);

set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
texts = strcat(['Colored by $x_{',num2str(ID2),'}$']);
title(texts,'FontSize',14,'interpreter','latex','FontSize',12)
grid on
box on
colorbar('Ticks',[min(XSAMPLE(:,ID2)), max(XSAMPLE(:,ID2))],'TickLabels',{'Low','High'});
set(gca,'TickLabelInterpreter','latex','FontSize',14);
set(gca,'xtick',[0:1/4:1])
