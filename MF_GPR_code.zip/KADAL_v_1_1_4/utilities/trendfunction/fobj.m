function f= fobj(x);

load KINF X y kernelc

f = RBFCS(x,X,y,kernelc);