function  [LOOWC, K, condn,alpha,w]  = RBFCS(dv,X,y,KERNEL)

w = dv(1:end-1) / sum(dv(1:end-1));

sig = dv(end);
n = size(X,1);

K = zeros(n,n);

for ii =1:length(KERNEL)
    K = K+(w(ii)*createRBF(X,X,sig,KERNEL{ii}));
end
% K = (w(1)*K1+w(2)*K2+w(3)*K3+w(4)*K4);

alpha = K\y;
Kdiag = diag(inv(K));
LOOWC = mean((abs(alpha./Kdiag).^1));

if (sum(isnan(K(:)))>0)
    condn = nan;
elseif (sum(isnan(K(:)))>0)
    condn = nan;
else
    condn = cond(K);
end

% %%
% sig = [0.01:0.05:10];
% for jj = 1:size(XP,1);
%     k1 = createRBF(XP(jj,:),X,sig,'wendlandC0');
%     k2 = createRBF(XP(jj,:),X,sig,'wendlandC2');
%     k3 = createRBF(XP(jj,:),X,sig,'wendlandC4');
%     k4 = createRBF(XP(jj,:),X,sig,'wendlandC6');
%     k = (w(1)*k1+w(2)*k2+w(3)*k3+w(4)*k4)/3;
%     yp(jj,1) = sum(k1.*alpha');
% end
% mean(abs(yp-yt))
