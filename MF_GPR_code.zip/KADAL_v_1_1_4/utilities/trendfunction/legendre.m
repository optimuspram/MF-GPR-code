function Le = legendre(n,lb,ub)
% legendre: Compute the legendre polynomials 
%
% Inputs:
%   n - Order of Legendre polynomials.
%   lb - lower bounds for Legendre polynomials
%   ub - Upper bounds for Legendre polynomials
%
% Output:
%   Le - Coefficients of Legendre polynomials

% check n
if( n<0 ), error('The order of legendre polynomial must be greater than or equal to 0.'); end

% again check n is an integer
if( 0~=n-fix(n) ), error('The order of legendre polynomial must be an integer.'); end

% call the legendre recursive function.
L0 = 1;
L1 = [1 -((ub+lb)/2)];

if n == 0
    Le = L0;
    return
elseif n  == 1
    Le = L1;
    return
end
        
% Perform Gram Schmidt orthogonalization
for i = 1:n-1
    if i==1;K = L0;L=L1;end
    
    a = (polyval(polyint(conv([1 0],conv(L,L))),ub)-polyval(polyint(conv([1 0],conv(L,L))),lb)) / (polyval(polyint(conv(L,L)),ub)- polyval(polyint(conv(L,L)),lb));  
    h1 = conv(polymin([1 0],a),L);
    
    b = (polyval(polyint(conv(L,L)),ub)-polyval(polyint(conv(L,L)),lb))/(polyval(polyint(conv(K,K)),ub)-polyval(polyint(conv(K,K)),lb));
    h2 = conv(b,K);
    
    Le = polymin(h1,h2);
    
    K = L;
    L = Le;  
end

%Perform normalization if needed
cons = 1/polyval(Le,1);
Le = Le*cons;



