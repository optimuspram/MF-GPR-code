function [c,ceq]= fcon(x);

load KINF X y kernelc

[c,ceq] = RBFCon(x,X,y,kernelc);