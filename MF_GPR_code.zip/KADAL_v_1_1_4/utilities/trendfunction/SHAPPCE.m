function SHAPC = SHAPPCE(myPCE)

cofall = myPCE.PCE.Coefficients;
idxall = full(myPCE.PCE.Basis.Indices);
MaxInt = myPCE.PCE.Basis.MaxInteractions;
Var = myPCE.PCE.Moments.Var;
for ii = 1: size(myPCE.ExpDesign.X,2)
    SHAPC(ii,1) = 0;
    for jj = 1:MaxInt % Loop over all possible interactions
        nzidx = (idxall ~= 0); % Find non-zero index
        [I1,~] = find(sum((nzidx),2)==jj);  % Find all jj-interactions terms
        [I2,~] = find(nzidx(:,ii) == 1); % Find that contrains variable ii
        IALL = intersect(I1,I2);
        SHAPC(ii,1) = SHAPC(ii,1) + (sum(cofall(IALL).^2)/Var)/jj;
    end
end
