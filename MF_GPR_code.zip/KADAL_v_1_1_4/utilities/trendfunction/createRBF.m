function K = RBFkernel(XA,XB,sigma,type)

n1 = size(XA,1);
n2 = size(XB,1);
K = zeros(n1,n2); % Initialize K

switch type
    case 'Gaussian'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = exp((-r^2)/(2*sigma^2));
            end
        end
    case 'multiquadric'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (r^2 + sigma^2)^0.5;
            end
        end
    case 'imultiquadric'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (r^2 + sigma^2)^(-0.5);
                K(ii,jj) = 1/(sqrt(1+(sigma*r)^2));
            end
        end
    case 'wendlandC0'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (1-sigma*r)^2;
            end
        end
        
    case 'wendlandC2'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (1-sigma*r)^4 * (4*sigma*r+1);
            end
        end
    case 'wendlandC4'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (1-sigma*r)^6 * ((35/3)*(sigma*r)^2+6*sigma*r+1);
            end
        end
    case 'wendlandC6'
        for ii = 1:n1
            for jj = 1:n2
                r = pdist([XA(ii,:);XB(jj,:)],'euclidean');
                K(ii,jj) = (1-sigma*r)^8 * (32*(sigma*r)^3+25*(sigma*r)^2+8*(sigma*r)+1);
            end
        end
end
