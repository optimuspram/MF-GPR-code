function Y = platebucling(X);

n = size(X,1);
Y = zeros(n,1);
for ii = 1:n
    x = X(ii,:);
    x1 = x(1); x2 = x(2); x3= x(3); x4 = x(4); x5 = x(5); x6 = x(6);
    lambda = (x1/x2)*sqrt(x3/x4);
    Y(ii) = ((2.1/lambda)-(0.9/(lambda^2)))*(1-((0.75*x5)/lambda))*(1-((2*x2*x6)/x1));
end