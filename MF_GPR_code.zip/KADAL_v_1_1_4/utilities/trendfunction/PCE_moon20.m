clc; clear all; close all

uqlab
ModelOpts.mFile = 'baka';

myModel = uq_createModel(ModelOpts);

nvar = 20;
nsamp = 1000;

for ii = 1:nvar
    InputOpts.Marginals(ii).Type = 'Uniform';
    InputOpts.Marginals(ii).Parameters = [0 1];  % (m/yr)
end

myInput = uq_createInput(InputOpts);
X = uq_getSample(nsamp);

Y = moon10hd(X);

SobolOpts.Type = 'Sensitivity';
SobolOpts.Method = 'Sobol';

SobolOpts.Sobol.Order = 3;

PCEOpts.Type = 'Metamodel';
PCEOpts.MetaType = 'PCE';
PCEOpts.FullModel = myModel;
PCEOpts.Degree = 3;
PCEOpts.ExpDesign.X = X;
PCEOpts.ExpDesign.Y = Y;

myPCE = uq_createModel(PCEOpts);
mySobolAnalysisPCE = uq_createAnalysis(SobolOpts);

%% SHAP
n = 1e6; % sample size
d = nvar; % dimension
x = uq_getSample(n); % Monte Carlo samples for x
y = uq_getSample(n);% Monte Carlo samples for y
[~, pm] = sort(rand(n,d),2); % random permutation matrix
% func = @(x,a)prod((abs(4.*x-2)+a)./(1+a),2); % Sobol g function
% a = (0:d-1);
z = x;
% fz1 = func(z,a);
fz1 =  moon10hd(z);
fx = fz1;
phi1 = zeros(1,d); % initialization
phi2 = zeros(1,d); % initialization
for j=1:d
    ind = bsxfun(@eq,pm(:,j),1:d); % compare j-th column with 1:d
    z(ind) = y(ind);
%     fz2 = func(z,a);
    fz2 =  moon10hd(z);
    fmarg = ((fx-fz1/2-fz2/2).*(fz1-fz2))';
    phi1 = phi1 + fmarg*ind/n;
    phi2 = phi2 + fmarg.^2*ind/n;
    fz1 = fz2;
end
clear x y z fz1 fz2 fx
s_all = sum(phi1); % variance of function
phi2 = (phi2-phi1.^2)./(n-1); % variance of Shapley estimates
disp(phi1); % Shapley estimates
disp(phi1-1.96*sqrt(phi2)); % lower confidence limit
disp(phi1+1.96*sqrt(phi2)); % upper confidence lim
SHAP = phi1./sum(phi1);

SHAPC =SHAPPCE(myPCE);
[SHAPBC,TOTBC] = bootstrapGSA(myPCE,500)