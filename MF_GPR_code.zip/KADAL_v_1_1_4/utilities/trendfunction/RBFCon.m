function [ycon,ceq] = RBFCon(dv,X,y,KERNEL,condref)
% function [ycon,ceq] = RBFCon(dv)
% global conds
% conds
% pause
% if conds == nan
%     ycon = inf;
% else
%     ycon = condn-1.8281e+04;
% end
% ceq = [];
w = dv(1:end-1) / sum(dv(1:end-1));

sig = dv(end);
n = size(X,1);

K = zeros(n,n);

for ii =1:length(KERNEL)
    K = K+(w(ii)*createRBF(X,X,sig,KERNEL{ii}));
end

if (sum(isnan(K(:)))>0)
    condn = nan;
    ycon = inf;
elseif (sum(isnan(K(:)))>0)
    condn = nan;
    ycon = inf;
else

    condn = cond(K);
    ycon = condn-condref;
end
    
    ceq = [];