function Y = testgan(X,beta)

Y = zeros(size(X,1),1);
Y = Y + beta(1);
for ii =2:4
    Y = Y + beta(ii)*X(:,ii-1);
end
Y = Y+beta(5)*(X(:,1).*X(:,2)) + beta(6)*(X(:,2).*X(:,3));
% Y = beta(1)+beta(2)*X(:,1)+beta(3)*X(:,2)+beta(4)*X(:,3);