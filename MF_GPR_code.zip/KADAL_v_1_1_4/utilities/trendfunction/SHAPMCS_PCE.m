function [phi1sc,lphi1sc,uphi1sc] = SHAPMCS_PCE(myPCE,n,d)

%% SHAP
% n = 5e6; % sample size
% d = 3; % dimension
x = rand(n,d); % Monte Carlo samples for x
y = rand(n,d); % Monte Carlo samples for y
[~, pm] = sort(rand(n,d),2); % random permutation matrix

z = x;
% fz1 = func(z,a);
if size(z,1) <= 1e6
    fz1 =  uq_evalModel(myPCE,z);
else
    fz1 = zeros(n,1);
    nfold = ceil(n/1e6);
    I = ceil(rand(n,1)*nfold);
    for jj = 1:nfold
        [I1,~] = find(I==jj);
        fz1(I1,:) = uq_evalModel(myPCE,z(I1,:));
    end
end
fx = fz1;
phi1 = zeros(1,d); % initialization
phi2 = zeros(1,d); % initialization
for j=1:d
    ind = bsxfun(@eq,pm(:,j),1:d); % compare j-th column with 1:d
    z(ind) = y(ind);
    %     fz2 = func(z,a);
    if n <= 1e6
        fz2 =  uq_evalModel(myPCE,z);
    else
        fz2 = zeros(n,1);
        nfold = ceil(n/1e6);
        I = ceil(rand(n,1)*nfold);
        for jj = 1:nfold
            [I1,~] = find(I==jj);
            fz2(I1,:) = uq_evalModel(myPCE,z(I1,:));
        end
%          disp('hola')
    end
    fmarg = ((fx-fz1/2-fz2/2).*(fz1-fz2))';
    phi1 = phi1 + fmarg*ind/n;
    phi2 = phi2 + fmarg.^2*ind/n;
    fz1 = fz2;
   
end
s_all = sum(phi1); % variance of function
phi2 = (phi2-phi1.^2)./(n-1); % variance of Shapley estimates
lphi1 = phi1-1.96*sqrt(phi2)
uphi1 = phi1+1.96*sqrt(phi2)
sc = (sum(phi1));
phi1sc = phi1/sc;
phi2sc = (1/sc)^2*phi2 % Scaled variance
% lphi1 = lphi1/(sum(lphi1));
% uphi1 = uphi1/(sum(uphi1));
lphi1sc = phi1sc-1.96*sqrt(phi2sc);
uphi1sc = phi1sc+1.96*sqrt(phi2sc);

