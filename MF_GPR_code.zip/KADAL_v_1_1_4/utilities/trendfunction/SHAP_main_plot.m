function SHAP_main_plot(SHAP, XSAMPLE,vlab,nsamp,ep)

% figure(1);
[C I] = sort(mean(abs(SHAP)),'ascend');
nf = 1e5;
SHAPR = SHAP(1:nf,I); XSAMPLER = XSAMPLE(1:nf,I);
nvar = size(SHAPR,2);

for ii = 1:nvar
    DAT = sign(SHAPR(1:nsamp,ii)).*abs(SHAPR(1:nsamp,ii).^ep);
    scatter(DAT,ones(1,nsamp)*ii,[],XSAMPLER(1:nsamp,ii),'filled');
    hold on
end
if ep == 1
    xlabel('$\phi$','interpreter','latex','FontSize',12);
elseif ep == 2
    xlabel('Sgn$(\phi)\times\phi^{2}$','interpreter','latex','FontSize',12);
end

ylabel('Variable','interpreter','latex','FontSize',12);
set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
title('Colored by input values','FontSize',14)
grid on
box on
set(gca,'ytick',[1:nvar])
set(gca,'yticklabels',vlab(I))
colorbar('Ticks',[min(XSAMPLER(1:nsamp)), max(XSAMPLER(1:nsamp))],'TickLabels',{'Low','High'});
set(gca,'TickLabelInterpreter','latex','FontSize',14);
hold off

figure(2)
barh(mean(abs(SHAPR.^ep)));
if ep == 1
    xlabel('Avg. $(\phi)$','interpreter','latex','FontSize',12);
elseif ep == 2
    xlabel('Avg. $(\phi^{2})$','interpreter','latex','FontSize',12);
end
ylabel('Variable','interpreter','latex','FontSize',12);
set(gcf,'color','w');
set(gcf,'position',[200 300 450 350]);
grid on
box on
set(gca,'ytick',[1:nvar])
set(gca,'yticklabels',vlab(I))
set(gca,'TickLabelInterpreter','latex','FontSize',14);