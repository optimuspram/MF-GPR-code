function [LOO, K, condn,alpha] = RBFHO(sig,X,y,kern)

K = createRBF(X,X,sig,kern);
save cap K
alpha = inv(K)*y;
Kdiag = diag(inv(K));
LOO = mean((abs(alpha./Kdiag).^1));
if (sum(isnan(K(:)))>0)
    condn = nan;
elseif (sum(isnan(K(:)))>0)
    condn = nan;
else
    condn = cond(K);
end
% %%
% sig = [0.01:0.05:10];
% for jj = 1:size(XP,1);
%     k1 = createRBF(XP(jj,:),X,sig,'wendlandC0');
%     k2 = createRBF(XP(jj,:),X,sig,'wendlandC2');
%     k3 = createRBF(XP(jj,:),X,sig,'wendlandC4');
%     k4 = createRBF(XP(jj,:),X,sig,'wendlandC6');
%     k = (w(1)*k1+w(2)*k2+w(3)*k3+w(4)*k4)/3;
%     yp(jj,1) = sum(k1.*alpha');
% end
% mean(abs(yp-yt))
