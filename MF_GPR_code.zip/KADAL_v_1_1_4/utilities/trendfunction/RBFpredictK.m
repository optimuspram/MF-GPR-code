function [yp] = RBFpredictK(XP,X,dv,alpha,KERNEL)

w = dv(1:end-1) / sum(dv(1:end-1));

sig = dv(end);
n = size(X,1);
for jj = 1:size(XP,1);
    k = zeros(1,n);

    for ii =1:length(KERNEL)
        k = k+(w(ii)*createRBF(XP(jj,:),X,sig,KERNEL{ii}));
    end
%     k1 = createRBF(XP(jj,:),X,sig,'wendlandC0');
%     k2 = createRBF(XP(jj,:),X,sig,'wendlandC2');
%     k3 = createRBF(XP(jj,:),X,sig,'wendlandC4');
%     k4 = createRBF(XP(jj,:),X,sig,'wendlandC6');
%     k = (w(1)*k1+w(2)*k2+w(3)*k3+w(4)*k4)/3;
    yp(jj,1) = sum(k.*alpha');
end