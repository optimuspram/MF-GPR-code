function idx = polytruncation(nix,nvar,q)
%
% Generate polynomial indices for the trend function by using total-order
% truncation or hyperbolic truncation (the former is if q = 1 and the latter is if q < 1)

% inputs:
%   nix - Maximum polynomial order
%   nvar - number of variables
%   q - hyperbolic truncation parameter

% output:
%   idx - Indices of polynomial bases
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

% Generate index for polynomial chaos expansion
idx = [];
for i = nix:-1:0
    idx = [idx;MonCof(i,nvar)];
end
idx = flipud(idx);

% Now truncate further (if q = 1, this equals to total-order expansion)
if q < 1
    idp = sum((idx.^q)')'.^(1/q);
    idx = idx(idp <=(nix+0.000001),:);
end
