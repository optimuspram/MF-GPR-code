clc;
clear all
close all;

XP = rand(1e3,2);
yt = FRANKE(XP);

for LOOP = 28:100
    X = rlh(25,2);
    clear y
    % for ii = 1:size(X,1);y(ii,1) = X(ii,1)^2 + X(ii,2)^2;end
    
    y = FRANKE(X);
    
    
    %%
    lbs = [0];
    ubs = [10];
    intopts = optimoptions('ga','MaxGenerations',50,'PopulationSize',10,'Display','iter')
    KERNEL = {'Gaussian','imultiquadric','multiquadric','wendlandC0','wendlandC2','wendlandC4','wendlandC6'}
    for ii = 1:length(KERNEL)
        [xopt(ii),fopt(ii)]=feval('ga', @(dv) RBFHO(dv,X,y,KERNEL{ii}), 1,[],[],[],[],lbs,ubs,[],[],intopts);
        [LOO(LOOP,ii), KMAT{ii}, condn(LOOP,ii),alpha{ii}] = RBFHO(xopt(ii),X,y,KERNEL{ii});
    end

    %% Calculate error
    for ii = 1:length(KERNEL)
        for jj = 1:size(XP,1);
            k1 = createRBF(XP(jj,:),X,xopt(ii),KERNEL{ii});
            yp(jj,1) = sum(k1.*alpha{ii}');
        end
        MAE(LOOP,ii)= mean(abs(yp-yt));
    end
    
    %% MULTIPLE
    [C I] = min(LOO(LOOP,[5 6]));
    condref = condn(LOOP,I);
    save cos condref
    
    kernelc = {'wendlandC2','wendlandC4'}
    %     kernelc = {'wendlandC0','wendlandC2','wendlandC4','wendlandC6'}
    lbs = [zeros(1,length(kernelc)) 0];
    ubs = [ones(1,length(kernelc)) 10];
    clear intopts
    initpop = [eye(2,2) xopt([5 6])']
    intopts = optimoptions('ga','MaxGenerations',150,'PopulationSize',50,'Display','iter','InitialPopulationMatrix',initpop,'NonlinearConstraintAlgorithm','penalty')
    [xc,fc]=feval('ga', @(dv) RBFCS(dv,X,y,kernelc), length(kernelc)+1,[],[],[],[],lbs,ubs,@(dv) RBFCon(dv,X,y,kernelc,condref),[],intopts);
    xcarc1(LOOP,:) = xc;
    warc1(LOOP,:) = xc(1:end-1)/sum(xc(1:end-1));
    [LOOC(LOOP,1), KMATC, condnc(LOOP,1),alphac] = RBFCS(xc,X,y,kernelc);
    

    for jj = 1:size(XP,1);
        yp(jj,1) = RBFpredictK(XP(jj,:),X,xc,alphac,kernelc);
    end
    MAEC(LOOP,1)= mean(abs(yp-yt));

    %% MULTIPLE 2
    [C I] = min(LOO(LOOP,4:end));
    condref = condn(LOOP,I+3);
    save cos condref
    
    kernelc = {'wendlandC0','wendlandC2','wendlandC4','wendlandC6'}
    lbs = [zeros(1,length(kernelc)) 0];
    ubs = [ones(1,length(kernelc)) 10];
    clear intopts
    initpop = [eye(4,4) xopt(4:end)']
    intopts = optimoptions('ga','MaxGenerations',150,'PopulationSize',50,'Display','iter','InitialPopulationMatrix',initpop,'NonlinearConstraintAlgorithm','penalty')
    
    [xc,fc]=feval('ga', @(dv) RBFCS(dv,X,y,kernelc), length(kernelc)+1,[],[],[],[],lbs,ubs,@(dv) RBFCon(dv,X,y,kernelc,condref),[],intopts);
    [LOOC(LOOP,2), KMATC, condnc(LOOP,2),alphac] = RBFCS(xc,X,y,kernelc);
    xcarc2(LOOP,:) = xc;
    warc2(LOOP,:) = xc(1:end-1)/sum(xc(1:end-1));
    %% Calculate error
    
    for jj = 1:size(XP,1);
        %     k1 =
        yp(jj,1) = RBFpredictK(XP(jj,:),X,xc,alphac,kernelc);
    end
    MAEC(LOOP,2)= mean(abs(yp-yt));
    
    save hasilsfra
end

%
% sig = [0.01:0.05:10];
% w1 = 0.7
% w2 = 0.2
% w3 = 0.1
for ii = 1:60
    K1 = createRBF(X,X,sig(ii),'wendlandC2');
    K2 = createRBF(X,X,sig(ii),'wendlandC4');
    K3 = createRBF(X,X,sig(ii),'wendlandC6');
    K = (w1*K1+w2*K2+w3*K3);
    alpha = inv(K)*y;
    Kdiag = diag(inv(K));
    LOOWC(ii) = mean((abs(alpha./Kdiag).^1));
    for jj = 1:size(XP,1);
        k1 = createRBF(XP(jj,:),X,sig(ii),'wendlandC2');
        k2 = createRBF(XP(jj,:),X,sig(ii),'wendlandC4');
        k3 = createRBF(XP(jj,:),X,sig(ii),'wendlandC6');
        k = (w1*k1+w2*k2+w3*k3)/3;
        yp(jj,1) = sum(k1.*alpha');
    end
    MAEWC(ii) = mean(abs(yp-yt));
    ii
    save hasils
end

scatter3(X(:,1),X(:,2),y,'bo','filled')

xlabel('$x_{1}$','interpreter','latex','FontSize',20);
ylabel('$x_{2}$','interpreter','latex','FontSize',20);
set(gcf,'color','w');

XM1 = [0:0.01:1];
XM2 = XM1;

[XG,YG] = meshgrid(XM1,XM2);
ZG = zeros(size(XG,1),size(XG,2));
ZT = ZG;
for ii = 1:12
    ZBAS{ii} = ZG;
end
for ii = 1:size(XG,1)
    for jj = 1:size(XG,1)
        %         k1 = createRBF([XG(ii,jj) YG(ii,jj)],X,0.3,'Gaussian');
        %         ZG(ii,jj) = sum(k1.*alpha');
        ZT(ii,jj) = XG(ii,jj)^2 + YG(ii,jj)^2;
        ZT(ii,jj) = BRANIN([XG(ii,jj) YG(ii,jj)]);
        %         ak =  (k1.*alpha');
        %         for kk = 1:12
        %             ZBAS{kk}(ii,jj) = ak(kk);
        %         end
    end
end

close all
IC = 12;
scatter3(X(IC,1),X(IC,2),y(1),'bo','filled')
contour3(XG,YG,ZBAS{IC},100)
xlabel('$x_{1}$','interpreter','latex','FontSize',20);
ylabel('$x_{2}$','interpreter','latex','FontSize',20);
zlabel('$y$','interpreter','latex','FontSize',20);
set(gcf,'color','w');
box off
axis([0 1 0 1 0 2])
axis([0 1 0 1 -1.8 0])
set(gcf,'position',[200 300 450 350]);

