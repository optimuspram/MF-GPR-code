function F = polynomial_chaos_regression(order,lb,ub,X)

nvar = size(X,2);
idx = polytruncation(order, nvar,1); % Generate polynomial basis for the trend function
Xnorm   = scalevar(X,[lb;ub]'); % Normalize experimental design to [-1,1]
F = compute_regression_matrix(idx,Xnorm,[-ones(1,nvar);ones(1,nvar)]',ones(1,nvar)); % Create the regression matrix

