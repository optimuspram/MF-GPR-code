clc
clear all
close all

% uqlab

uqlab
ModelOpts.mFile = 'ISHIGAMI_NORM';

myModel = uq_createModel(ModelOpts);

nvar = 3;
NSAMP = [1000];
nsamp = 1000;

for ii = 1:nvar
    InputOpts.Marginals(ii).Type = 'Uniform';
    InputOpts.Marginals(ii).Parameters = [0 1];  % (m/yr)
end

myInputS = uq_createInput(InputOpts);

% XSAMPT = uq_getSample(nsamp,'Sobol')

% YSAMP =  ISHIGAMI_NORM(XSAMPT);

XVAL =  uq_getSample(nsamp,'Sobol');
YVAL = ISHIGAMI_NORM(XVAL);

%% MCS

NSAMP = [1e4:1e4:1e6];
NSAMP = logspace(4,7,4)
shapmcs = zeros(length(NSAMP),nvar);
for ii = 1:length(NSAMP);
      [phi1(ii,:),lphi1(ii,:),uphi1(ii,:)] = SHAPMCS_PCE(myPCE,NSAMP(ii),3);
      ii
end
% load ISHIGAMI_MCS_SHAPLEY phi1 lphi1 uphi1

%% Loop over different methods

PCEOpts.Type = 'Metamodel';
PCEOpts.MetaType = 'PCE';
PCEOpts.Input = myInputS;
ModelOpts.mFile = 'ISHIGAMI_NORM';
myModel = uq_createModel(ModelOpts);
PCEOpts.FullModel = myModel;
PCEOpts.Degree = [14];
PCEOpts.ExpDesign.X = XVAL;
PCEOpts.ExpDesign.Y = YVAL;
PCEOpts.Method = 'LARS';
myPCE = uq_createModel(PCEOpts);
SobolSensOpts.Type = 'Sensitivity';
SobolSensOpts.Sobol.Order = 3;
SobolSensOpts.Method = 'Sobol';
SobolAnalysis = uq_createAnalysis(SobolSensOpts);
SobTest = SobolAnalysis;



GLOOP = 1;
SOBOTrue.TOT{GLOOP}(:,1) = SobolAnalysis.Results.Total;
SOBOTrue.FIR{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{1};
SOBOTrue.SEC{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{2};
SOBOTrue.THI{GLOOP}(:,1) = SobolAnalysis.Results.AllOrders{3};
SHAPVALUEtrue{GLOOP}(:,1) = SHAPPCE(myPCE);

%% Analytical
a = 7; b = 0.1;
S1 = 0.5*(1+((pi^4*b)/5))^2
S2 = (a^2)/8
s3 = 0;

ST1 = S1 + (8*pi^8*b^2)/225

T1 = S1+ (4*pi^8*b^2)/225
T2 = S2;
T3 = (4*pi^8*b^2)/225
SHAPE = [T1 T2 T3]/sum([T1 T2 T3]);

close all
figure(1);
ID = 2;
plot(NSAMP,phi1(:,ID),'bo-'); hold on;
plot(NSAMP,repmat(SHAPVALUEtrue{1}(ID),1,length(NSAMP)),'m-')
plot(NSAMP,repmat(SHAPE(ID),1,length(NSAMP)),'k-.')
plot(NSAMP,lphi1(:,ID),'bo--');
plot(NSAMP,uphi1(:,ID),'bo--');
xlabel('$n_{mcs}$','interpreter','latex','FontSize',15);
ylabel('$\phi_{2}$','interpreter','latex','FontSize',15);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
box on
grid on
set(gcf,'position',[200 300 450 350]);
legend({'MCS-PCE','Exact-PCE','Exact-Analytical','95\% CI, MCS-PCE'},'interpreter','latex');
set(gca,'xscale','log')
saveas(gcf,'shapley_ISHIGAMI_1000samples_var2_50samp.eps','eps2c');
hgsave('shapley_ISHIGAMI_1000samples_var2_50samp')

close all
figure(1);
ID = 1;
plot(NSAMP,phi1(:,ID),'bo-'); hold on;
plot(NSAMP,repmat(SHAPVALUEtrue{1}(ID),1,length(NSAMP)),'m-')
plot(NSAMP,repmat(SHAPE(ID),1,length(NSAMP)),'k-.')
plot(NSAMP,lphi1(:,ID),'bo--');
plot(NSAMP,uphi1(:,ID),'bo--');
xlabel('$n_{mcs}$','interpreter','latex','FontSize',15);
ylabel('$\phi_{1}$','interpreter','latex','FontSize',15);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
box on
grid on
set(gcf,'position',[200 300 450 350]);
legend({'MCS-PCE','Exact-PCE','Exact-Analytical','95\% CI, MCS-PCE'},'interpreter','latex');
set(gca,'xscale','log')
saveas(gcf,'shapley_ISHIGAMI_1000samples_var1_50samp.eps','eps2c');
hgsave('shapley_ISHIGAMI_1000samples_var1_50samp')


close all
figure(2);
ID = 3;
plot(NSAMP,phi1(:,ID),'bo-'); hold on;
plot(NSAMP,repmat(SHAPVALUEtrue{1}(ID),1,length(NSAMP)),'m-')
plot(NSAMP,repmat(SHAPE(ID),1,length(NSAMP)),'k-.')
plot(NSAMP,lphi1(:,ID),'bo--');
plot(NSAMP,uphi1(:,ID),'bo--');
xlabel('$n_{mcs}$','interpreter','latex','FontSize',15);
ylabel('$\phi_{3}$','interpreter','latex','FontSize',15);
set(gca,'TickLabelInterpreter','latex','FontSize',15)
set(gcf,'color','w');
box on
grid on
set(gcf,'position',[200 300 450 350]);
legend({'MCS-PCE','Exact-PCE','Exact-Analytical','95\% CI, MCS-PCE'},'interpreter','latex');
set(gca,'xscale','log')
saveas(gcf,'shapley_ISHIGAMI_1000samples_var3_50samp.eps','eps2c');
hgsave('shapley_ISHIGAMI_1000samples_var3_50samp')