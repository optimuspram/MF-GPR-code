function [V,DD]= PCE_active_sub(myPCE)

% Construct C matrix
nmcs = 1e4;
nvar = size(myPCE.ExpDesign.X,2);
XRAND = uq_getSample(nmcs);


grd = zeros(size(XRAND,1),nvar);
dd = (0.001);
for jj = 1:size(XRAND,1)
    x = XRAND(jj,:);
    xl = repmat(x,17,1);
    xu = repmat(x,17,1);
    for kk = 1:nvar
        xl(kk,kk) = x(kk)-dd;
        xu(kk,kk) = x(kk)+dd;
    end
    resu = uq_evalModel(myPCE,[xu]);
    resl = uq_evalModel(myPCE,[xl]);
    grd(jj,:) =(resu-resl)'./(2*dd)   ;
end

C = (grd'*grd)/nmcs;
[V D] = eig(C);
DD = flipud(diag(D));
V = fliplr(V);
DFG = DD/sum(DD);
cums = cumsum(DFG);
% % Find dimension that exceed threshold
% [I] = find(cums > 0.995)
%
% NR = 1;
% VT = V(:,1:NR)
%
% xnew = VT'*XALL'; xnew = xnew';