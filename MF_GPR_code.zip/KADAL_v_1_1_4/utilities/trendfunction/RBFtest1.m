clc;
clear all
close all;

XP = rand(1e3,2);

X = rlh(20,2);
clear y
% for ii = 1:size(X,1);y(ii,1) = X(ii,1)^2 + X(ii,2)^2;end
 
y = BRANIN(X);
yt = BRANIN(XP);
% for ii = 1:size(X,1);y(ii,1) = 0.5*((1-(2*X(ii,1)-1)^2)+(1-(2*X(ii,1)-1)^2));end
 
% for ii = 1:size(XP,1);yt(ii,1) = XP(ii,1)^2+2*1/exp(XP(ii,1));end

% for ii = 1:size(XP,1);yt(ii,1) =  1/(2*((1-(2*XP(ii,1)-1)^2)+(1-(2*XP(ii,1)-1)^2));end

% yn = y+randn(12,1)*0.1
KERNEL = {'Gaussian','multiquadric','imultiquadric','wendlandC0','wendlandC2','wendlandC4','wendlandC6'}
sig = [0.01:0.05:10];
for KK = 1:length(KERNEL)
    for ii = 1:60
        K = createRBF(X,X,sig(ii),KERNEL{KK});
        alpha = inv(K)*y;
        Kdiag = diag(inv(K));
        LOO{KK}(ii) = mean((abs(alpha./Kdiag).^1));
        for jj = 1:size(XP,1);
            k1 = createRBF(XP(jj,:),X,sig(ii),KERNEL{KK});
            yp(jj,1) = sum(k1.*alpha');
        end
        MAE{KK}(ii) = mean(abs(yp-yt));
        ii
    end
end
scatter3(X(:,1),X(:,2),y,'bo','filled')

xlabel('$x_{1}$','interpreter','latex','FontSize',20);
ylabel('$x_{2}$','interpreter','latex','FontSize',20);
set(gcf,'color','w');

XM1 = [0:0.01:1];
XM2 = XM1;

[XG,YG] = meshgrid(XM1,XM2);
ZG = zeros(size(XG,1),size(XG,2));
ZT = ZG;
for ii = 1:12
   ZBAS{ii} = ZG; 
end
for ii = 1:size(XG,1)
    for jj = 1:size(XG,1)
%         k1 = createRBF([XG(ii,jj) YG(ii,jj)],X,0.3,'Gaussian');
%         ZG(ii,jj) = sum(k1.*alpha');
        ZT(ii,jj) = XG(ii,jj)^2 + YG(ii,jj)^2;
        ZT(ii,jj) = BRANIN([XG(ii,jj) YG(ii,jj)]);
%         ak =  (k1.*alpha');
%         for kk = 1:12
%             ZBAS{kk}(ii,jj) = ak(kk);
%         end
    end
end

close all
IC = 12;
scatter3(X(IC,1),X(IC,2),y(1),'bo','filled')
contour3(XG,YG,ZBAS{IC},100)
xlabel('$x_{1}$','interpreter','latex','FontSize',20);
ylabel('$x_{2}$','interpreter','latex','FontSize',20);
zlabel('$y$','interpreter','latex','FontSize',20);
set(gcf,'color','w');
box off
axis([0 1 0 1 0 2])
axis([0 1 0 1 -1.8 0])
 set(gcf,'position',[200 300 450 350]);