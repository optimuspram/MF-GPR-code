function F = compute_regression_matrix(idx,X,bounds,polytype)
%
% Create regression matrix using polynomial chaos expansion for Kriging
%
% Inputs
%   idx - Indices of polynomial basis.
%   X - Experimental design
%   bounds - Bounds of the experimental design (note that in create_Kriging.m the X is already normalized to [-1,1])
%   polytpe - Type of polynomial (a 1 x nvar vector). Use 1 for Legendre polynomial (uniform distribution), 2 = Hermite polynomial (normal distribution)

% Output
%   F - Regression matrix
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)
nsamp = size(X,1); % Number of samples
nvar = size(X,2); % Number of variables
F = ones(size(X,1),size(idx,1)); % Initialize regression matrix

for po = 1:nvar
    if polytype(po) == 1
        N{po}.Na = 2*((X(:,po)-repmat(bounds(po,1),nsamp,1))./(repmat(bounds(po,2),nsamp,1)-repmat(bounds(po,1),nsamp,1)))-1;
    elseif polytype(po) == 2
        N{po}.Na = (X(:,po)-repmat(bounds(po,1),nsamp,1))./(sqrt(2*repmat(bounds(po,2),nsamp,1).^2));
    end
end

for ii = 1:size(idx,1) % Loop over PCE index
    h1 = ones(nsamp,1);
    ids = idx(ii,:);
    for jo = 1:length(ids) % Loop over number of index 2
        if polytype(jo) == 1 % Legendre polynomial
            h1 = h1.* polyval(legendre(ids(jo),-1,1),N{jo}.Na)/sqrt(1/(2*ids(jo)+1));
        elseif polytype(jo) == 2 % Hermite polynomial
            h1 = h1.* ((1/((2)^(ids(jo)/2)))*hermite(ids(jo),N{jo}.Na)/sqrt(factorial(ids(jo))));
        end
    end
     F(:,ii) = h1;
end

 