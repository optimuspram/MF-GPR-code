clc; clear all; close all

uqlab
ModelOpts.mFile = 'baka';

myModel = uq_createModel(ModelOpts);

nvar = 3;
nsamp = 1000;
for ii = 1:3
   % InputOpts.Marginals(8).Name = 'Kw';  % Borehole hydraulic conductivity
    InputOpts.Marginals(ii).Type = 'Uniform';
    InputOpts.Marginals(ii).Parameters = [0 1];  % (m/yr)
end
X = rand(nsamp,nvar);
myInput = uq_createInput(InputOpts);
beta = [1, 0.25, 1, 0.25, 5, 5];
Y = ISHIGAMI(X);

SobolOpts.Type = 'Sensitivity';
SobolOpts.Method = 'Sobol';

SobolOpts.Sobol.Order = 3;

PCEOpts.Type = 'Metamodel';
PCEOpts.MetaType = 'PCE';
PCEOpts.FullModel = myModel;
PCEOpts.Degree = 10;
PCEOpts.ExpDesign.X = X;
PCEOpts.ExpDesign.Y = Y;

myPCE = uq_createModel(PCEOpts);
mySobolAnalysisPCE = uq_createAnalysis(SobolOpts);

%% SHAP
n = 1e6; % sample size
d = 3; % dimension
x = rand(n,d); % Monte Carlo samples for x
y = rand(n,d); % Monte Carlo samples for y
[~, pm] = sort(rand(n,d),2); % random permutation matrix
% func = @(x,a)prod((abs(4.*x-2)+a)./(1+a),2); % Sobol g function
% a = (0:d-1);
z = x;
% fz1 = func(z,a);
fz1 =  ISHIGAMI(z);
fx = fz1;
phi1 = zeros(1,d); % initialization
phi2 = zeros(1,d); % initialization
for j=1:d
    ind = bsxfun(@eq,pm(:,j),1:d); % compare j-th column with 1:d
    z(ind) = y(ind);
%     fz2 = func(z,a);
    fz2 =  ISHIGAMI(z);
    fmarg = ((fx-fz1/2-fz2/2).*(fz1-fz2))';
    phi1 = phi1 + fmarg*ind/n;
    phi2 = phi2 + fmarg.^2*ind/n;
    fz1 = fz2;
end
s_all = sum(phi1); % variance of function
phi2 = (phi2-phi1.^2)./(n-1); % variance of Shapley estimates
disp(phi1); % Shapley estimates
disp(phi1-1.96*sqrt(phi2)); % lower confidence limit
disp(phi1+1.96*sqrt(phi2)); % upper confidence lim
SHAP = phi1./sum(phi1)

%% 
cofall = myPCE.PCE.Coefficients;
idxall = full(myPCE.PCE.Basis.Indices);
MaxInt = myPCE.PCE.Basis.MaxInteractions;
Var = myPCE.PCE.Moments.Var
for ii = 1:nvar
    SHAPC(ii,1) = 0;
    for jj = 1:MaxInt % Loop over all possible interactions
        nzidx = (idxall ~= 0); % Find non-zero index
        [I1,~] = find(sum((nzidx),2)==jj);  % Find all jj-interactions terms
        [I2,~] = find(nzidx(:,ii) == 1); % Find that contrains variable ii
        IALL = intersect(I1,I2);
        SHAPC(ii,1) = SHAPC(ii,1) + (sum(cofall(IALL).^2)/Var)/jj;
    end
end

% for ii = 1:SobolOpts.Sobol.Order
%    idxall = [idxall; mySobolAnalysisPCE.Results.VarIdx{ii}
%    cofall = [cofall; mySobolAnalysisPCE.Results.AllOrders{ii};
% end