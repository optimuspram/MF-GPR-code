function Xnew = scalevar(X,range)
%
% Normalize the experimental design to [-1,1]

% Inputs:
%  X - Initial experimental design to be normalized 
% Output:
%  Xnew - Normalized X
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

% Normalize to [0,1]
for i = 1:size(X,2)
   Xnew(:,i) = (X(:,i)-(range(i,1))) ./ (range(i,2)-(range(i,1))); 
end

% Normalize to [-1,1]
Xnew = (Xnew-0.5)*2;





