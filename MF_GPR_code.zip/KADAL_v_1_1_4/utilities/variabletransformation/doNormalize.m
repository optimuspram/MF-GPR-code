function Xnew = doNormalize(X,meanX,stdX)
%
% Normalize the experimental design to [-1,1]

% Inputs:
%  X - Initial experimental design to be normalized 
% Output:
%  Xnew - Normalized X
%
%  Author: Lucia Parussini (lparussini@units.it)
% meanX=0;stdX=1;
Xnew = (X-meanX)./stdX;
