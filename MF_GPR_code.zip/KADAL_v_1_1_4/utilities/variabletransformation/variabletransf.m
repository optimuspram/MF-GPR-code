function Xreal = variabletransf(X,r)
% Convert the experimental design into real values of variables
%
% Inputs
%   X - Experimental design to normalize (in the range of [0-1])
%   r - Combined lower and upper bounds of the experimental design.
%
% Output
%   Xreal - Converted experimental design.
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

q = (X-0.5)*2; 
nr = r(:,2)-r(:,1);

for i = 1:size(X,2)
        Xreal(:,i) = X(:,i)*nr(i);
        Xreal(:,i) = Xreal(:,i)+r(i,1);
end