function [Xtrain, ytrain, Xtest, ytest] = datasplitting(X,y,ftrain)
%
% Split the data into training and test data set
%
% Inputs:
%    X - original input data set
%    y - original output data set
%    ftrain - fraction of data set used as training data set
%
% Output:
%    Xtrain - input training data set
%    ytrain - output training data set
%    Xtest - input test data set
%    ytest - output test data set
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

ndata = size(X,1); % Size of the original data set
idx = randperm(ndata,ndata);  % Generate random index from random permutation
nsamp = ceil(ftrain*ndata);

Xtrain = X(idx(1:nsamp),:); % input training data set
ytrain = y(idx(1:nsamp)); % output training data set

Xtest = X(idx(nsamp+1:end),:); % input test data set
ytest = y(idx(nsamp+1:end)); % output test data set