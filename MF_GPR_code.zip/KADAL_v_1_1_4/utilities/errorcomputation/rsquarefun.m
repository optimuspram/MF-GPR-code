function r2 = rsquarefun(ytrue,ypred)
%
% Compute r^2 correlation

% Inputs:
%   ytrue - true responses.
%   ypred - predicted responses.

% Output
%   r2 - r^2 correlation
%
%  Author: Pramudita Satria Palar(pramsatriapalar@gmail.com, pramsp@ftmd.itb.ac.id)

nume = sum((ytrue-mean(ytrue)).*(ypred-mean(ypred)));
deno = sqrt(sum(((ytrue-mean(ytrue)).^2))).*sqrt(sum(((ypred-mean(ypred)).^2)));
r2 = (nume/deno)^2;
