function YN = paregopre(Yall);
% Pre-processing solutions for ParEGO
%
% Input: 
%   Yall - Original responses
%
% Output
%   YN - Scalarized responses with random weights

NF = 11; % Number of weight vectors for ParEGO
WGA = [0:1/(NF-1):1]'; WGA(:,2) = [1-WGA]; % Generate weight vectors for ParEGO.
IDR = randperm(length(WGA),1); % Draw a random index for the weight vector.
WG = WGA(IDR,:); % Draw the weight vector.
FFN = scale(Yall,0,[min(Yall);max(Yall)]); % Scale to o-1
rho = 0.05;

YN = zeros(size(FFN,1),1);
for IH = 1:size(FFN,1)
    YN(IH,:) = max(WG.*(FFN(IH,:))) + rho*sum((WG.*(FFN(IH,:))));
end