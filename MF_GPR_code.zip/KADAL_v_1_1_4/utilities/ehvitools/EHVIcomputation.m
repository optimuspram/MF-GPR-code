function [HV pred SSqr]=EHVIcomputation(x,Ypar,BayesMultiInfo,KrigNewMultiInfo)

% ModelInfoKR{i} = Model Information of objective i 
% ObjectiveInfoKR{i} = Objective Information of objective i 

% Input : PFFN = Current Pareto front
% RefP  : Reference point for hypervolume calculation

nobj = length(KrigNewMultiInfo);
RefP = BayesMultiInfo.refpoint;

% prediction of each objective
pred = zeros(1,nobj); SSqr = zeros(1,nobj);
for ii = 1:nobj
    KrigNewInfo = KrigNewMultiInfo{ii};
    [pred(1,ii), SSqr(1,ii)] = krigprediction(x,KrigNewInfo,'pred');
end

% Compute (negative of) hypervolume
HV = -exi2d(Ypar,RefP,pred,SSqr);

