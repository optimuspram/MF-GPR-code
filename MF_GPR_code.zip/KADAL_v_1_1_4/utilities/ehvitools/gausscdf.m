function x=gausscdf(x)
  x=0.5*(1+erf(x/sqrt(2)));